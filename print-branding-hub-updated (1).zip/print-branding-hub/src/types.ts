export interface CompanyProfile {
  fullName: string;
  companyName: string;
  jobTitle: string;
  field: string;
  commercialReg: string;
  taxCard: string;
  phone1: string;
  phone2: string;
  email: string;
  website: string;
  address: string;
  city: string;
  slogan: string;
  logoUrl?: string;
  logoIconId?: string;
  stampTextLine1: string;
  stampTextLine2: string;
  stampTextLine3: string;
  stampDate: string;
  trophyTribute: string;
}

export type ProductCategory =
  | 'youadv_exclusive'
  | 'stamps'
  | 'cards'
  | 'desk_signs'
  | 'badges'
  | 'trophies'
  | 'invoices_flyers'
  | 'flags_bags';

export interface StampOptions {
  modelType: 'traxx_small' | 'traxx_medium' | 'traxx_large' | 'traxx_big_machine' | 'pocket_small' | 'pocket_large' | 'round_seal' | 'traditional_wood';
  inkColor: 'blue' | 'black' | 'red';
  shape: 'rectangle' | 'oval' | 'round';
  borderStyle: 'double' | 'single' | 'ornament' | 'none';
  showDate: boolean;
  showEmblem: boolean;
  emblemType: 'eagle' | 'star' | 'balance' | 'caduceus' | 'gear' | 'crown' | 'custom_logo';
}

export interface CardOptions {
  style: 'luxury_navy' | 'gold_minimal' | 'modern_dark' | 'mint_creative' | 'acrylic_transparent' | 'kraft_vintage';
  finish: 'digital_standard' | 'matte_lamination' | 'glossy_lamination' | 'gold_foil' | 'spot_uv' | 'embossed';
  corners: 'sharp' | 'rounded';
  cardCount: number;
  showQr: boolean;
  doubleSided: boolean;
}

export interface DeskSignOptions {
  baseType: 'wood_small_pen' | 'wood_luxury_large' | 'crystal_prism' | 'brass_door_plate' | 'acrylic_glass_plate' | 'leather_set_small' | 'leather_set_large';
  plateColor: 'gold_brass' | 'silver_chrome' | 'matte_black' | 'clear_glass';
  fontStyle: 'classic_thuluth' | 'modern_kufic' | 'geometric_cairo';
  includePenHolder: boolean;
}

export interface BadgeOptions {
  material: 'magnetic_brass' | 'magnetic_silver' | 'magnetic_acrylic' | 'pin_fiber';
  layout: 'badge_with_logo' | 'badge_text_only' | 'badge_with_flag';
  quantity: number;
}

export interface TrophyOptions {
  size: 'crystal_small' | 'crystal_medium' | 'crystal_large_royal' | 'wood_shield_brass' | 'medal_gold' | 'medal_silver' | 'medal_bronze';
  boxColor: 'navy_blue_velvet' | 'bordeaux_red_velvet' | 'emerald_green_velvet';
  engravingTone: 'gold_leaf' | 'silver_frost' | 'color_print';
}

export interface InvoiceFlyerOptions {
  type: 'invoice_quarter_20' | 'invoice_half_10' | 'flyer_half_1000' | 'flyer_quarter_2000' | 'bags_cloth_100';
  copyStyle: 'original_only' | 'original_and_carbon_copy' | 'cmyk_full_color' | 'black_white';
  paperWeight: '80g' | '150g_glossy' | '300g_heavy';
}

export interface ProductCatalogItem {
  id: string;
  category: ProductCategory;
  title: string;
  arabicSubtitle: string;
  basePrice: number;
  priceFormatted: string;
  dimensions: string;
  deliveryTime: string;
  popular?: boolean;
  tag?: string;
  description: string;
  features: string[];
  imagePlaceholderId: string;
  isYouAdvBrand?: boolean;
  buy2Get1Free?: boolean;
  brandTag?: string;
}

export interface CartItem {
  id: string;
  productId: string;
  title: string;
  category: ProductCategory;
  unitPrice: number;
  quantity: number;
  totalPrice: number;
  optionsSummary: string;
  customizationDetails: Record<string, any>;
  buy2Get1Free?: boolean;
}

export type OrderStatus =
  | 'received'
  | 'designing'
  | 'engraving'
  | 'quality_check'
  | 'out_for_delivery'
  | 'delivered';

export interface ProductionStage {
  id: string;
  stageKey: OrderStatus;
  title: string;
  description: string;
  statusText: string;
  completed: boolean;
  current: boolean;
  updatedAt: string;
  photoUrl?: string;
  photoCaption?: string;
}

export interface CustomerOrder {
  id: string;
  orderNumber: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  companyName?: string;
  jobTitle?: string;
  address: string;
  governorate: string;
  shippingMethod: 'pickup' | 'cairo_express' | 'governorates';
  status: OrderStatus;
  statusArabic: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  grandTotal: number;
  customerNotes?: string;
  adminNotes?: string;
  stages: ProductionStage[];
  customProofImage?: string;
}

export interface OrderHistoryRecord {
  id: string;
  orderNumber: string;
  date: string;
  items: CartItem[];
  totalAmount: number;
  shippingMethod: 'pickup' | 'cairo_express' | 'governorates';
  governorate?: string;
}

