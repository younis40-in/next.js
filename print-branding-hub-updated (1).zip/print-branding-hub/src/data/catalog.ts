export interface CatalogProduct {
  id: string;
  title: string;
  category: string;
  price: string;
  priceNum: number;
  size: string;
  minQty?: string;
  description: string;
}

export const finalCatalog: CatalogProduct[] = [
  { id: "STAMP-TRAXX-LG", title: "ختم تراكس / ماكينة كبير (5.6 × 2.3 سم)", category: "أختام", price: "215 ج.م", priceNum: 215, size: "5.6 × 2.3 سم", description: "ختم ماكينة ذاتي التحبير مع حفر ليزر دقيق." },
  { id: "STAMP-PKT-MD", title: "ختم بوكيت ترودات وسط (2 × 5 سم)", category: "أختام", price: "300 ج.م", priceNum: 300, size: "2 × 5 سم", description: "ختم جيبي محمول للأطباء والمهندسين والشركات." },
  { id: "STAMP-PKT-SM", title: "ختم بوكيت ترودات صغير (1.5 × 4 سم)", category: "أختام", price: "250 ج.م", priceNum: 250, size: "1.5 × 4 سم", description: "ختم جيبي صغير خفيف وسهل الحمل." },
  { id: "STAMP-OVAL", title: "ختم بيضاوي رسمي معتمد (3.5 × 4.5 سم)", category: "أختام", price: "300 ج.م", priceNum: 300, size: "3.5 × 4.5 سم", description: "ختم بيضاوي كلاسيكي للمؤسسات والشركات." },
  { id: "STAMP-RND-LOGO", title: "ختم مدور نوع لوجو (قطر 4 سم)", category: "أختام", price: "275 ج.م", priceNum: 275, size: "قطر 4 سم", description: "ختم دائري للعلامات التجارية والشعارات." },
  { id: "CARD-DIG-300", title: "كروت شخصية ديجيتال فاخرة (300 كارت)", category: "كروت شخصية", price: "350 ج.م", priceNum: 350, size: "300 كارت", description: "طباعة ديجيتال فورية بجودة ألوان فائقة وسيلوفان فاخر." },
  { id: "CARD-DIG-500", title: "كروت شخصية ديجيتال وجهين (500 كارت)", category: "كروت شخصية", price: "450 ج.م", priceNum: 450, size: "500 كارت", description: "كروت أعمال كوشيه 350 جرام مع سيلوفان مط أو لامع." },
  { id: "BOOK-HALF", title: "دفاتر فواتير نص A4 (أصل + صورة)", category: "دفاتر فواتير", price: "600 ج.م", priceNum: 600, size: "10 دفاتر", description: "دفاتر محاسبية مكربنة مرقمة ومخرمة بدقة." },
  { id: "FLYER-HALF", title: "فلاير إعلاني نص A4 (1000 إعلان)", category: "فلايرات", price: "450 ج.م", priceNum: 450, size: "1000 قطعة", description: "كوشيه فاخر للانتشار السريع وتسيير الأعمال اليومية." },
  { id: "TAG-METAL", title: "نيم تاج معدن فاخر سبليميشن نحاس", category: "نيم تاج", price: "90 ج.م", priceNum: 90, size: "مغناطيس", description: "مظهر معدني ذهبي أو فضي فخم للشخصيات الإدارية." },
  { id: "AWARD-LG", title: "درع كريستال تذكاري كبير + علبة قطيفة", category: "دروع تكريم", price: "375 ج.م", priceNum: 375, size: "كبير", description: "شامل العلبة القطيفة الفاخرة وحفر الاسم والشعار بالليزر." }
];
