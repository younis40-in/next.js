import { CustomerOrder, OrderStatus, ProductionStage } from '../types';

export const ORDERS_STORAGE_KEY = 'youadv_customer_orders_v2';

export const INITIAL_PRODUCTION_STAGES = (orderDate: string): ProductionStage[] => [
  {
    id: 'stage_1',
    stageKey: 'received',
    title: 'استلام الطلب وتأكيد البيانات',
    description: 'تم تسجيل تفاصيل الطلب والمقايسة بنجاح ومطابقة بيانات السجل والبطاقة الضريبية.',
    statusText: 'مكتمل ومعتمد',
    completed: true,
    current: false,
    updatedAt: orderDate,
    photoUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=600&q=80',
    photoCaption: 'مراجعة ملف الطلب وبيانات الاعتماد الرسمية',
  },
  {
    id: 'stage_2',
    stageKey: 'designing',
    title: 'إعداد وتجهيز البروفة الرقمية',
    description: 'يقوم مهندس التصميم بضبط الخطوط العربية وتفريغ الشعار بدقة متناهية للحفر.',
    statusText: 'تم اعتماد البروفة',
    completed: true,
    current: false,
    updatedAt: 'اليوم • 09:30 ص',
    photoUrl: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=600&q=80',
    photoCaption: 'بروفة التصميم المتجهي (Vector Vector Proof) بدقة الليزر',
  },
  {
    id: 'stage_3',
    stageKey: 'engraving',
    title: 'الحفر بالليزر والطباعة المباشرة',
    description: 'حفر المطاط المعالج أو النحاس بماكينات الليزر الألمانية وتثبيت وسادة الحبر الأصلية.',
    statusText: 'قيد التنفيذ بالمطبعة',
    completed: true,
    current: true,
    updatedAt: 'اليوم • 01:15 م',
    photoUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80',
    photoCaption: 'صورة من ماكينة الحفر بالليزر عالية الدقة بورشة الموسكي',
  },
  {
    id: 'stage_4',
    stageKey: 'quality_check',
    title: 'فحص الجودة وتجربة البصمة',
    description: 'اختبار وضوح الختم وتطابق درجات الحبر وتجميع الهيكل الخارجي المقاوم للصدمات.',
    statusText: 'في انتظار الفحص النهائي',
    completed: false,
    current: false,
    updatedAt: 'متبقي ساعة',
    photoUrl: 'https://images.unsplash.com/photo-1607344645866-009c320b5ab8?auto=format&fit=crop&w=600&q=80',
    photoCaption: 'محطة اختبار بصمة الختم وجودة الورنيش والمطاط',
  },
  {
    id: 'stage_5',
    stageKey: 'out_for_delivery',
    title: 'التغليف الفاخر والشحن للتسليم',
    description: 'تجهيز الطلب في علبة You Adv الفاخرة مع بطاقة الضمان والتسليم لمندوب التوصيل.',
    statusText: 'بانتظار اكتمال الفحص',
    completed: false,
    current: false,
    updatedAt: 'اليوم • قبل 06:00 م',
    photoUrl: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=600&q=80',
    photoCaption: 'تغليف الهدايا والمطبوعات داخل علب You Adv الفاخرة',
  },
];

export const SEED_ORDERS: CustomerOrder[] = [
  {
    id: 'ord_youadv_101',
    orderNumber: 'YOU-ORD-2026-9214',
    createdAt: 'اليوم • 08:30 ص',
    customerName: 'د. يونس أحمد محمود',
    customerPhone: '01141350759',
    customerEmail: 'younis262002@gmail.com',
    companyName: 'مجموعة يونس الاستشارية للهندسة والمقاولات',
    jobTitle: 'رئيس مجلس الإدارة',
    address: 'شارع محمد علي، أمام قسم الموسكي',
    governorate: 'القاهرة',
    shippingMethod: 'cairo_express',
    status: 'engraving',
    statusArabic: 'قيد الحفر بالليزر والتشطيب',
    subtotal: 750,
    discount: 205,
    shippingFee: 0,
    grandTotal: 545,
    customerNotes: 'برجاء التأكيد على وضوح رقم القيد الهندسي والتاريخ بأسفل الختم',
    adminNotes: 'تم اعتماد البروفة صباحاً بواسطة العميل عبر واتساب، جاري الحفر بماكينة تراكْس 9011',
    items: [
      {
        id: 'seed_item_1',
        productId: 'youadv_stamp_signature',
        title: 'ختم You Adv Signature Master (ماكينة أصلية)',
        category: 'youadv_exclusive',
        unitPrice: 290,
        quantity: 1,
        totalPrice: 290,
        optionsSummary: 'لون الحبر: أزرق كحلي رسمي | مقاس 2.5×5.5 سم | إطار مزدوج رسمي',
        customizationDetails: {
          stampLine1: 'مجموعة يونس الاستشارية للهندسة',
          stampLine2: 'د. يونس أحمد محمود - استشاري',
          stampLine3: 'س.ت: 89432 • ب.ض: 432-890-112',
          inkColor: 'أزرق كحلي رسمي',
        },
        buy2Get1Free: true,
      },
      {
        id: 'seed_item_2',
        productId: 'youadv_desk_set_royal',
        title: 'طقم مكتب You Adv Executive الملكي الفاخر',
        category: 'youadv_exclusive',
        unitPrice: 490,
        quantity: 1,
        totalPrice: 490,
        optionsSummary: 'خشب أرو مصمت نخب أول | شريحة نحاس محفورة بالليزر | خط ثلث ملكي',
        customizationDetails: {
          plateName: 'د. يونس أحمد محمود',
          plateTitle: 'رئيس مجلس الإدارة والمدير التنفيذي',
        },
        buy2Get1Free: true,
      },
    ],
    stages: INITIAL_PRODUCTION_STAGES('اليوم • 08:30 ص'),
  },
  {
    id: 'ord_youadv_102',
    orderNumber: 'YOU-ORD-2026-8830',
    createdAt: 'أمس • 02:45 م',
    customerName: 'م. سارة المهدي',
    customerPhone: '01123456789',
    customerEmail: 'sara.elmahdy@design.eg',
    companyName: 'ستوديو آرت ديكو للتصميم المعماري',
    jobTitle: 'المدير التنفيذي',
    address: 'شارع التسعين الشمالي، التجمع الخامس',
    governorate: 'القاهرة',
    shippingMethod: 'cairo_express',
    status: 'quality_check',
    statusArabic: 'فحص الجودة والتجميع',
    subtotal: 940,
    discount: 0,
    shippingFee: 50,
    grandTotal: 990,
    customerNotes: 'مطلوب حبر أسود خاص مع الختم وتغليف هدايا',
    adminNotes: 'تم الانتهاء من حفر الأكريليك والختم، جاري اختبار البصمة',
    items: [
      {
        id: 'seed_item_3',
        productId: 'card_luxury_matte',
        title: '1000 كارت شخصي بيزنس فاخر (سلوفان مط دبل فيس)',
        category: 'cards',
        unitPrice: 320,
        quantity: 1,
        totalPrice: 320,
        optionsSummary: 'كوشيه 350 جرام فاخر | سليفان مط وجهين | QR ذكي',
        customizationDetails: {},
      },
      {
        id: 'seed_item_4',
        productId: 'traxx_large',
        title: 'ختم تراكْس 9012 كبير (2.3 × 5.6 سم)',
        category: 'stamps',
        unitPrice: 265,
        quantity: 1,
        totalPrice: 265,
        optionsSummary: 'لون الحبر: أسود فحمي (+50 ج.م) | Traxx 9012',
        customizationDetails: {
          inkColor: 'أسود فحمي (+50 ج.م)',
          extraInkFee: 50,
        },
      },
    ],
    stages: [
      {
        id: 's1',
        stageKey: 'received',
        title: 'استلام الطلب وتأكيد البيانات',
        description: 'تم تسجيل وتأكيد الطلب وتحديد مواصفات الحبر الأسود الخاص.',
        statusText: 'مكتمل',
        completed: true,
        current: false,
        updatedAt: 'أمس • 02:45 م',
        photoUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=600&q=80',
      },
      {
        id: 's2',
        stageKey: 'designing',
        title: 'إعداد وتجهيز البروفة الرقمية',
        description: 'تم إرسال بروفة الكارت والختم واعتمادها عبر واتساب.',
        statusText: 'معتمد',
        completed: true,
        current: false,
        updatedAt: 'أمس • 04:20 م',
        photoUrl: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=600&q=80',
      },
      {
        id: 's3',
        stageKey: 'engraving',
        title: 'الحفر بالليزر والطباعة المباشرة',
        description: 'تم حفر مطاط الختم وطباعة الكروت كوشيه 350 جم.',
        statusText: 'مكتمل',
        completed: true,
        current: false,
        updatedAt: 'اليوم • 10:00 ص',
        photoUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80',
      },
      {
        id: 's4',
        stageKey: 'quality_check',
        title: 'فحص الجودة وتجربة البصمة',
        description: 'جاري فحص نقاء حبر الختم الأسود ودقة قص حواف الكروت.',
        statusText: 'قيد الفحص النهائي',
        completed: true,
        current: true,
        updatedAt: 'اليوم • 01:45 م',
        photoUrl: 'https://images.unsplash.com/photo-1607344645866-009c320b5ab8?auto=format&fit=crop&w=600&q=80',
      },
      {
        id: 's5',
        stageKey: 'out_for_delivery',
        title: 'التغليف الفاخر والشحن للتسليم',
        description: 'تجهيز الشحنة مع مندوب التجمع الخامس للتسليم اليوم.',
        statusText: 'مجدول للشحن',
        completed: false,
        current: false,
        updatedAt: 'اليوم • 04:30 م',
        photoUrl: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=600&q=80',
      },
    ],
  },
];

export const getStoredOrders = (): CustomerOrder[] => {
  try {
    const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to parse orders from localStorage', e);
  }

  // Seed default orders
  localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(SEED_ORDERS));
  return SEED_ORDERS;
};

export const saveStoredOrders = (orders: CustomerOrder[]) => {
  try {
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  } catch (e) {
    console.error('Failed to save orders to localStorage', e);
  }
};

export const updateOrderStatus = (
  orderId: string,
  newStatus: OrderStatus,
  adminNote?: string,
  stagePhotoUrl?: string
): CustomerOrder[] => {
  const currentOrders = getStoredOrders();
  const statusLabels: Record<OrderStatus, string> = {
    received: 'تم استلام الطلب وتأكيد البيانات',
    designing: 'قيد إعداد واعتماد البروفة الرقمية',
    engraving: 'قيد الحفر بالليزر والطباعة',
    quality_check: 'فحص الجودة وتجربة البصمة',
    out_for_delivery: 'جاهز للشحن ومع مندوب التوصيل',
    delivered: 'تم التسليم بنجاح للعميل',
  };

  const statusOrder: OrderStatus[] = [
    'received',
    'designing',
    'engraving',
    'quality_check',
    'out_for_delivery',
    'delivered',
  ];

  const targetIndex = statusOrder.indexOf(newStatus);

  const updatedOrders = currentOrders.map((ord) => {
    if (ord.id === orderId || ord.orderNumber === orderId) {
      const updatedStages = ord.stages.map((stage, idx) => {
        const stageIdx = statusOrder.indexOf(stage.stageKey);
        const isCompleted = stageIdx < targetIndex || (stageIdx === targetIndex && targetIndex === statusOrder.length - 1);
        const isCurrent = stageIdx === targetIndex && targetIndex < statusOrder.length - 1;

        let photoUrl = stage.photoUrl;
        if (stage.stageKey === newStatus && stagePhotoUrl) {
          photoUrl = stagePhotoUrl;
        }

        return {
          ...stage,
          completed: isCompleted,
          current: isCurrent,
          updatedAt: isCurrent || isCompleted ? `اليوم • ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}` : stage.updatedAt,
          photoUrl,
        };
      });

      return {
        ...ord,
        status: newStatus,
        statusArabic: statusLabels[newStatus] || newStatus,
        adminNotes: adminNote !== undefined ? adminNote : ord.adminNotes,
        stages: updatedStages,
      };
    }
    return ord;
  });

  saveStoredOrders(updatedOrders);
  return updatedOrders;
};
