export const brandKit = {
  brandName: "يونس للإعلان",
  calligraphyName: "يُونُسْ لِلإعْلاَن",
  englishName: "YouAdv",
  slogan: "YOU WILL CUSTOMIZE THE WORLD",
  signature: "By Mohamed Hosny",
  contacts: {
    phone1: "01141350759",
    phone2: "01131450759",
    email: "hosny5701@gmail.com",
    headquarters: "157 شارع محمد علي، أمام قسم الموسكي، العتبة، القاهرة",
    showroom: "171 شارع سعد زغلول - ميدان الجيزة - الجيزة",
  }
};
