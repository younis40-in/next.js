import React, { useState, useEffect } from 'react';
import { Clock, Zap, Sparkles, Flame, ShieldAlert } from 'lucide-react';

interface OfferCountdownTimerProps {
  compact?: boolean;
  onExploreOffer?: () => void;
}

export const OfferCountdownTimer: React.FC<OfferCountdownTimerProps> = ({
  compact = false,
  onExploreOffer,
}) => {
  // Target time: Persistent countdown target saved in localStorage, or defaults to 18 hours 45 mins from now
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({
    days: 1,
    hours: 14,
    minutes: 38,
    seconds: 45,
  });

  const [claimedPercent, setClaimedPercent] = useState(86);

  useEffect(() => {
    const STORAGE_KEY = 'youadv_promo_deadline_2026';
    let targetTime: number;

    const savedTarget = localStorage.getItem(STORAGE_KEY);
    if (savedTarget && !isNaN(Number(savedTarget)) && Number(savedTarget) > Date.now()) {
      targetTime = Number(savedTarget);
    } else {
      // 36 hours from now for a high-urgency realistic promo window
      targetTime = Date.now() + 36 * 60 * 60 * 1000 + 42 * 60 * 1000 + 15 * 1000;
      localStorage.setItem(STORAGE_KEY, targetTime.toString());
    }

    const updateTimer = () => {
      const difference = targetTime - Date.now();

      if (difference <= 0) {
        // Reset a new cycle if it hits 0
        const newTarget = Date.now() + 24 * 60 * 60 * 1000;
        localStorage.setItem(STORAGE_KEY, newTarget.toString());
        targetTime = newTarget;
      }

      const d = Math.floor(difference / (1000 * 60 * 60 * 24));
      const h = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const m = Math.floor((difference / 1000 / 60) % 60);
      const s = Math.floor((difference / 1000) % 60);

      setTimeLeft({
        days: d,
        hours: h,
        minutes: m,
        seconds: s,
      });
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatNumber = (num: number) => String(num).padStart(2, '0');

  if (compact) {
    return (
      <div className="inline-flex items-center gap-2 bg-amber-950/80 backdrop-blur-xs text-amber-200 border border-amber-500/40 px-3 py-1.5 rounded-xl shadow-xs">
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
        </span>
        <Clock className="w-3.5 h-3.5 text-amber-300" />
        <span className="text-[11px] font-bold text-amber-100">ينتهي عرض 2+1 مجاناً خلال:</span>
        <div className="flex items-center gap-1 font-mono font-black text-xs text-white dir-ltr">
          <span className="bg-black/50 px-1.5 py-0.5 rounded text-amber-300">
            {formatNumber(timeLeft.hours + (timeLeft.days * 24))}h
          </span>
          :
          <span className="bg-black/50 px-1.5 py-0.5 rounded text-amber-300">
            {formatNumber(timeLeft.minutes)}m
          </span>
          :
          <span className="bg-black/50 px-1.5 py-0.5 rounded text-amber-300 text-red-300 animate-pulse">
            {formatNumber(timeLeft.seconds)}s
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-950/90 text-white border border-amber-500/40 rounded-2xl p-4 sm:p-5 shadow-2xl relative overflow-hidden backdrop-blur-md">
      {/* Background Ambience */}
      <div className="absolute -top-10 -left-10 w-40 h-40 bg-amber-500/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-red-500/15 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-5">
        
        {/* Urgency Info */}
        <div className="space-y-1.5 text-center md:text-right w-full md:w-auto">
          <div className="inline-flex items-center gap-2 bg-red-500/20 text-red-300 border border-red-500/40 px-2.5 py-0.5 rounded-full text-[11px] font-black">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
            </span>
            <Flame className="w-3.5 h-3.5 text-red-400 fill-red-400" />
            <span>عرض حصري محدود الصلاحية (Flash Offer)</span>
          </div>

          <h4 className="text-base sm:text-lg font-black font-['Cairo'] text-white flex items-center justify-center md:justify-start gap-2">
            <span>العداد التنازلي لانتهاء عرض «اشتري 2 واحصل على 3 مجاناً»</span>
          </h4>

          <p className="text-xs text-slate-300 max-w-lg">
            العرض متاح للطلبات المؤكدة عبر التطبيق فقط ويتم تطبيق خصم القطعة المجانية تلقائياً بالسلة وعرض السعر.
          </p>

          {/* Claimed progress */}
          <div className="pt-1 flex items-center justify-center md:justify-start gap-3 text-[11px]">
            <div className="w-36 bg-slate-800 rounded-full h-2 overflow-hidden border border-slate-700">
              <div
                className="bg-gradient-to-r from-amber-400 to-red-500 h-full rounded-full"
                style={{ width: `${claimedPercent}%` }}
              ></div>
            </div>
            <span className="text-amber-300 font-bold">تم استهلاك {claimedPercent}% من حصة العرض</span>
          </div>
        </div>

        {/* Countdown Digits */}
        <div className="flex items-center gap-2 sm:gap-3 bg-black/60 p-2.5 sm:p-3.5 rounded-2xl border border-white/10 shadow-inner">
          
          {/* Days */}
          <div className="flex flex-col items-center min-w-[52px] sm:min-w-[62px]">
            <div className="w-full bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700/80 rounded-xl py-1.5 sm:py-2 text-center shadow-md">
              <span className="text-lg sm:text-2xl font-black font-mono text-amber-300 tracking-wider">
                {formatNumber(timeLeft.days)}
              </span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 mt-1">يوم</span>
          </div>

          <span className="text-lg sm:text-2xl font-black text-amber-400/80 font-mono -mt-4">:</span>

          {/* Hours */}
          <div className="flex flex-col items-center min-w-[52px] sm:min-w-[62px]">
            <div className="w-full bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700/80 rounded-xl py-1.5 sm:py-2 text-center shadow-md">
              <span className="text-lg sm:text-2xl font-black font-mono text-amber-300 tracking-wider">
                {formatNumber(timeLeft.hours)}
              </span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 mt-1">ساعة</span>
          </div>

          <span className="text-lg sm:text-2xl font-black text-amber-400/80 font-mono -mt-4">:</span>

          {/* Minutes */}
          <div className="flex flex-col items-center min-w-[52px] sm:min-w-[62px]">
            <div className="w-full bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700/80 rounded-xl py-1.5 sm:py-2 text-center shadow-md">
              <span className="text-lg sm:text-2xl font-black font-mono text-amber-300 tracking-wider">
                {formatNumber(timeLeft.minutes)}
              </span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 mt-1">دقيقة</span>
          </div>

          <span className="text-lg sm:text-2xl font-black text-red-400 font-mono -mt-4 animate-pulse">:</span>

          {/* Seconds */}
          <div className="flex flex-col items-center min-w-[52px] sm:min-w-[62px]">
            <div className="w-full bg-gradient-to-b from-red-950/80 to-slate-900 border border-red-500/50 rounded-xl py-1.5 sm:py-2 text-center shadow-md">
              <span className="text-lg sm:text-2xl font-black font-mono text-red-400 tracking-wider animate-pulse">
                {formatNumber(timeLeft.seconds)}
              </span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold text-red-300 mt-1">ثانية</span>
          </div>

        </div>

      </div>
    </div>
  );
};
