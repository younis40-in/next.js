"use client";

import React, { useState } from "react";
import { Stamp, CreditCard, Award, FileText, ShoppingBag, Send, AlertCircle, RotateCw, Sparkles, Circle, Square } from "lucide-react";
import OrderModal, { OrderDetails } from "@/components/OrderModal";
import Button3D from "@/components/Button3D";

export default function DesignStudio() {
  const [selectedProduct, setSelectedProduct] = useState("stamp-rect");
  const [rawText, setRawText] = useState(
`مكتب المستشار أحمد النجار
للمحاماة والاستشارات القانونية والتحكيم
العتبة - القاهرة • 01141350759 • قيد: 10452`
  );
  const [inkColor, setInkColor] = useState("#1e40af");
  const [inkColorName, setInkColorName] = useState("أزرق YouAdv (أساسي)");
  const [isTilted, setIsTilted] = useState(true);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<OrderDetails | null>(null);

  const lines = rawText.split("\n").filter((l) => l.trim().length > 0);
  const mainTitle = lines[0] || "يونس للإعلان والطباعة";
  const subtitle = lines[1] || "دعاية وإعلان • هويات بصرية";
  const contactInfo = lines.slice(2).join(" • ") || "العتبة - القاهرة • 01141350759";

  const handleSendToAdmin = () => {
    setCurrentOrder({
      title: `طلب تصميم مخصص: ${selectedProduct}`,
      customText: mainTitle,
      subtitleText: subtitle,
      inkColor: inkColorName,
      size: contactInfo,
      price: "حسب المقاس والكمية",
    });
    setIsModalOpen(true);
  };

  return (
    <div id="studio" className="bg-white text-brand-navy rounded-[36px] p-6 sm:p-10 border-2 border-brand-border shadow-[0_10px_0_0_#E2E8F5] relative scroll-mt-28">
      
      <div className="flex flex-col gap-2 pb-6 border-b border-brand-border text-right">
        <span className="text-brand-pink-dark text-xs font-black uppercase tracking-wider bg-brand-pink/40 px-3.5 py-1 rounded-full border border-brand-pink w-fit">
          استوديو المعاينة الحية ثلاثية الأبعاد
        </span>
        <h3 className="text-2xl sm:text-4xl font-black text-brand-navy mt-1">
          عاين تصميم ختمك أو كارتك أو درعك في ثوانٍ معدودة
        </h3>
      </div>

      <div className="grid lg:grid-cols-12 gap-8 mt-8 items-start">
        
        {/* Controls Form */}
        <div className="lg:col-span-5 space-y-6 bg-brand-surface-alt p-6 sm:p-7 rounded-3xl border border-brand-border text-right">
          <div>
            <label className="text-xs font-black text-brand-blue-dark block mb-2.5">1. اختر نوع ومجسم المنتج:</label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: "stamp-rect", label: "ختم مستطيل ▭" },
                { id: "stamp-circle", label: "ختم دائري ⭕" },
                { id: "card", label: "كارت شخصي 💳" },
                { id: "award", label: "درع تكريـم 🏆" },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedProduct(p.id)}
                  className={`p-2.5 rounded-xl border text-center font-bold transition ${
                    selectedProduct === p.id ? "bg-brand-blue/50 border-brand-blue-dark text-brand-blue-dark" : "bg-white border-brand-border text-brand-muted"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 pt-3 border-t border-brand-border">
            <label className="text-xs font-black text-brand-blue-dark block mb-1">2. اكتب بيانات التصميم كاملة:</label>
            <textarea
              rows={4}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full bg-white border border-brand-border rounded-2xl p-3.5 text-xs text-brand-navy outline-none focus:border-brand-blue-dark leading-relaxed resize-none"
            />
          </div>

          <div>
            <label className="text-xs text-brand-body block mb-1.5 font-semibold">لون الحبر / الطباعة:</label>
            <div className="flex gap-2">
              {[
                { color: "#1e40af", name: "أزرق YouAdv" },
                { color: "#0f172a", name: "أسود" },
                { color: "#b91c1c", name: "أحمر" },
                { color: "#f43f5e", name: "وردي نيون" },
              ].map((c) => (
                <button
                  key={c.color}
                  onClick={() => { setInkColor(c.color); setInkColorName(c.name); }}
                  style={{ backgroundColor: c.color }}
                  className={`w-7 h-7 rounded-full border-2 transition ${inkColor === c.color ? "border-brand-navy scale-125 shadow-lg" : "border-transparent opacity-60"}`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* 3D Preview Box */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-brand-surface-alt p-6 sm:p-8 rounded-3xl border-2 border-brand-border flex flex-col items-center justify-center min-h-[480px]">
            
            <div className="w-full flex justify-between items-center mb-6 text-xs border-b border-brand-border pb-3">
              <span className="font-bold text-brand-blue-dark font-mono">معاينة مجسمة 3D</span>
              <button onClick={() => setIsTilted(!isTilted)} className="text-[10px] text-brand-body hover:text-brand-navy bg-white px-3 py-1 rounded-full border border-brand-border flex items-center gap-1">
                <RotateCw className="w-3 h-3 text-brand-blue-dark" />
                <span>{isTilted ? "زاوية مجسمة" : "رؤية مسطحة"}</span>
              </button>
            </div>

            {selectedProduct.startsWith("stamp") && (
              <div 
                className="bg-[#faf9f6] text-slate-800 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.25)] p-8 sm:p-12 w-full max-w-[460px] flex flex-col justify-between border border-slate-300 transition-all"
                style={{ transform: isTilted ? "perspective(900px) rotateX(8deg) rotateY(-4deg)" : "none" }}
              >
                <div className="flex justify-between border-b pb-2 mb-6 opacity-60 text-[10px]">
                  <span>جمهورية مصر العربية</span>
                  <span>مستند رسمي معتمد</span>
                </div>

                <div className="my-auto self-center select-none" style={{ color: inkColor }}>
                  {selectedProduct === "stamp-rect" ? (
                    <div className="p-4 border-4 border-current rounded-xl text-center">
                      <div className="text-xs font-bold">❖ {subtitle} ❖</div>
                      <div className="text-2xl font-black my-2">{mainTitle}</div>
                      <div className="text-[11px] font-bold">{contactInfo}</div>
                    </div>
                  ) : (
                    <div className="w-48 h-48 border-4 border-dashed border-current rounded-full flex flex-col items-center justify-center text-center p-3">
                      <div className="text-[10px] font-bold">★ {subtitle} ★</div>
                      <div className="text-lg font-black my-1">{mainTitle}</div>
                      <div className="text-[9px] font-bold">{contactInfo}</div>
                    </div>
                  )}
                </div>

                <div className="mt-6 pt-3 border-t border-dashed flex justify-between text-[10px] text-slate-500">
                  <span>التوقيع والاعتماد: ...................</span>
                  <span>التاريخ: {new Date().toLocaleDateString("ar-EG")}</span>
                </div>
              </div>
            )}

            {selectedProduct === "card" && (
              <div 
                className="w-80 h-48 bg-white text-slate-900 rounded-2xl shadow-2xl p-6 flex flex-col justify-between relative border border-slate-200"
                style={{ transform: isTilted ? "perspective(800px) rotateY(-14deg)" : "none" }}
              >
                <div>
                  <h3 className="font-extrabold text-lg" style={{ color: inkColor }}>{mainTitle}</h3>
                  <p className="text-xs text-slate-500 font-medium">{subtitle}</p>
                </div>
                <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-600">
                  <p>📍 {contactInfo}</p>
                </div>
                <div className="absolute top-0 right-0 w-2.5 h-full rounded-r-2xl" style={{ backgroundColor: inkColor }} />
              </div>
            )}

            {selectedProduct === "award" && (
              <div 
                className="w-60 h-72 bg-gradient-to-b from-brand-navy to-brand-navy-dark rounded-3xl shadow-2xl border-2 border-brand-gold/60 p-6 flex flex-col items-center justify-between text-center"
                style={{ transform: isTilted ? "perspective(900px) rotateY(10deg)" : "none" }}
              >
                <div className="w-12 h-12 rounded-full bg-brand-gold/20 text-brand-gold flex items-center justify-center">
                  <Award className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-[10px] text-brand-gold font-bold uppercase">درع تكريم وتقدير</span>
                  <h3 className="font-black text-sm text-white mt-1">{mainTitle}</h3>
                  <p className="text-[10px] text-white/70 mt-1">{subtitle}</p>
                </div>
                <div className="w-full py-1.5 bg-brand-navy-dark rounded-lg border border-brand-gold/30 text-[9px] text-brand-gold font-mono">
                  {contactInfo}
                </div>
              </div>
            )}

          </div>

          <div className="flex items-start gap-2.5 p-3.5 rounded-2xl bg-brand-yellow/40 border border-brand-yellow text-brand-gold-dark">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-brand-gold-dark" />
            <p className="text-[11px] leading-relaxed">
              هذه معاينة تقريبية (أولية) لشكل التصميم وليست الملف النهائي. بعد تأكيد الحجز، يقوم فريقنا بإعداد وإرسال <strong className="text-brand-navy">التصميم النهائي</strong> إليك لاعتماده قبل الطباعة والتنفيذ.
            </p>
          </div>

          <div className="flex justify-end pt-2">
            <Button3D onClick={handleSendToAdmin} variant="navy" className="w-full sm:w-auto text-xs px-8 py-4">
              <Send className="w-4 h-4 -rotate-45" />
              <span>إرسال طلب التصميم للإدارة للمراجعة والطباعة</span>
            </Button3D>
          </div>

        </div>

      </div>

      <OrderModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} order={currentOrder} />
    </div>
  );
}
