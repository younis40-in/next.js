import React, { useState } from 'react';
import { CompanyProfile, CardOptions } from '../../types';
import { Rotate3d, Plus, Check, Sparkles, QrCode, Phone, Mail, MapPin, Globe, Shield, Download } from 'lucide-react';

interface BusinessCardMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

const CARD_STYLES = [
  { id: 'luxury_navy', name: 'كحلي وتنفيذي فاخر', tag: 'VIP كلاسيك' },
  { id: 'gold_minimal', name: 'أبيض لؤلؤي مينيمال', tag: 'راقي وهادئ' },
  { id: 'modern_dark', name: 'أسود مط أونيكس', tag: 'عصري فخم' },
  { id: 'mint_creative', name: 'هوية You Adv المنعشة', tag: 'إبداعي وحديث' },
  { id: 'acrylic_transparent', name: 'أكريليك شفاف زجاجي', tag: 'مميز ومبتكر' },
  { id: 'kraft_vintage', name: 'ورق كرافت بيئي', tag: 'طبيعي وفينتاج' },
];

const CARD_PACKAGES = [
  { id: 'digital_300', name: 'عرض 300 كارت ديجيتال سريع', count: 300, price: 350, finish: 'digital_standard', delivery: 'تسليم فوري خلال ساعات', tag: 'عرض الكتالوج' },
  { id: 'matte_1000', name: '1000 كارت سليفان مط فاخر', count: 1000, price: 550, finish: 'matte_lamination', delivery: 'توصيل 1-3 أيام' },
  { id: 'spot_uv_1000', name: '1000 كارت بصمة ذهب وسبوت UV', count: 1000, price: 950, finish: 'spot_uv', delivery: 'توصيل 2-4 أيام', tag: 'فئة كبار الشخصيات' },
  { id: 'acrylic_100', name: '100 كارت بلاستيك وأكريليك شفاف', count: 100, price: 450, finish: 'acrylic_transparent', delivery: 'توصيل 1-2 يوم' },
];

export const BusinessCardMockup: React.FC<BusinessCardMockupProps> = ({ profile, onAddToCart }) => {
  const [cardOptions, setCardOptions] = useState<CardOptions>({
    style: 'luxury_navy',
    finish: 'digital_standard',
    corners: 'rounded',
    cardCount: 300,
    showQr: true,
    doubleSided: true,
  });

  const [isFlipped, setIsFlipped] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState(CARD_PACKAGES[0]);

  const handleAddOrder = () => {
    onAddToCart({
      productId: selectedPackage.id,
      title: `كروت بزنس كارد (${selectedPackage.name})`,
      category: 'cards',
      unitPrice: selectedPackage.price,
      quantity: 1,
      optionsSummary: `الكمية: ${selectedPackage.count} كارت | النمط: ${CARD_STYLES.find((s) => s.id === cardOptions.style)?.name} | الزوايا: ${cardOptions.corners === 'rounded' ? 'دائرية' : 'قائمة'}`,
      customizationDetails: {
        package: selectedPackage.name,
        cardCount: selectedPackage.count,
        style: cardOptions.style,
        corners: cardOptions.corners,
        finish: selectedPackage.finish,
        showQr: cardOptions.showQr,
      },
    });
  };

  // Generate QR code data URI or SVG placeholder
  const qrString = `MECARD:N:${profile.fullName};ORG:${profile.companyName};TEL:${profile.phone1};EMAIL:${profile.email};ADR:${profile.address};;`;

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Price info */}
      <div className="bg-gradient-to-r from-sky-900 via-blue-900 to-indigo-950 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              تسعير 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              كروت شخصية وبزنس كارد - {selectedPackage.name}
            </h3>
          </div>
          <p className="text-xs text-sky-200 mt-1">
            طباعة كروت ديجيتال وأوفست فاخرة بجودة 2400 DPI مع إمكانية السليفان المط والبصمة الذهبية
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              {selectedPackage.price} <span className="text-xs font-bold text-white">ج.م</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">{selectedPackage.delivery}</div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>طلب الكروت</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: 3D Interactive Card Preview (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="flex items-center justify-between bg-slate-100 p-1.5 rounded-xl text-xs font-bold">
            <span className="text-slate-600 px-2">
              المعاينة الحية للكارت (انقر للقلب بين الوجه والخلفية)
            </span>
            <button
              onClick={() => setIsFlipped(!isFlipped)}
              className="flex items-center gap-1.5 bg-white hover:bg-sky-50 text-sky-800 px-3 py-1.5 rounded-lg border border-slate-200 shadow-xs transition-all cursor-pointer"
            >
              <Rotate3d className="w-4 h-4 text-sky-600" />
              <span>قلب الكارت ({isFlipped ? 'الظهر' : 'الوجه'})</span>
            </button>
          </div>

          {/* 3D Perspective Stage */}
          <div className="relative bg-gradient-to-b from-slate-200 via-stone-200 to-slate-300 rounded-2xl p-6 sm:p-12 flex items-center justify-center min-h-[380px] shadow-inner overflow-hidden">
            
            {/* Background Studio Lighting & Floor Reflection */}
            <div className="absolute inset-0 bg-radial from-white/40 via-transparent to-black/10"></div>

            {/* Card Container with 3D Flip */}
            <div
              onClick={() => setIsFlipped(!isFlipped)}
              className="relative w-full max-w-[420px] aspect-[1.75/1] cursor-pointer perspective-1000 group select-none"
            >
              
              {/* Card Body */}
              <div
                className={`w-full h-full relative transition-transform duration-700 transform-style-3d shadow-2xl ${
                  cardOptions.corners === 'rounded' ? 'rounded-2xl' : 'rounded-sm'
                } ${isFlipped ? 'rotate-y-180' : ''}`}
              >
                
                {/* ================= FRONT SIDE ================= */}
                <div
                  className={`absolute inset-0 backface-hidden p-6 flex flex-col justify-between overflow-hidden ${
                    cardOptions.corners === 'rounded' ? 'rounded-2xl' : 'rounded-sm'
                  } ${
                    cardOptions.style === 'luxury_navy'
                      ? 'bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white border-2 border-amber-400/40'
                      : cardOptions.style === 'gold_minimal'
                      ? 'bg-gradient-to-br from-white via-slate-50 to-stone-100 text-slate-900 border border-slate-300 shadow-md'
                      : cardOptions.style === 'modern_dark'
                      ? 'bg-gradient-to-br from-zinc-950 via-zinc-900 to-black text-white border border-zinc-800'
                      : cardOptions.style === 'mint_creative'
                      ? 'bg-gradient-to-br from-sky-900 via-cyan-900 to-slate-900 text-white border-2 border-cyan-400/60'
                      : cardOptions.style === 'acrylic_transparent'
                      ? 'bg-white/40 backdrop-blur-md text-slate-900 border-2 border-white/80 shadow-2xl'
                      : 'bg-[#f4ebe1] text-[#3e2c1c] border border-[#d5c3b2]'
                  }`}
                >
                  
                  {/* Subtle Card Texture / Foil accents */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-radial from-amber-400/10 via-transparent to-transparent pointer-events-none"></div>
                  
                  {/* Card Header: Company & Logo */}
                  <div className="flex items-start justify-between gap-3 relative z-10">
                    <div>
                      <h4 className="text-base sm:text-lg font-black tracking-tight leading-tight">
                        {profile.companyName || 'شركة يونس للإعلان'}
                      </h4>
                      <p className="text-[10px] sm:text-xs opacity-75 font-semibold mt-0.5">
                        {profile.field || 'حلول الطباعة والهوية البصرية'}
                      </p>
                    </div>

                    {/* Logo Emblem on Card */}
                    <div className="w-10 h-10 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center p-1 shrink-0 backdrop-blur-xs">
                      {profile.logoUrl ? (
                        <img src={profile.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" />
                      ) : (
                        <span className="text-xl">
                          {profile.logoIconId === 'balance' ? '⚖️' : profile.logoIconId === 'caduceus' ? '⚕️' : profile.logoIconId === 'gear' ? '⚙️' : '🦅'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Center/Bottom: Person Name & Title */}
                  <div className="relative z-10 my-auto py-2">
                    <div className="text-lg sm:text-xl font-black tracking-tight text-amber-300">
                      {profile.fullName || 'أحمد محمود سالم'}
                    </div>
                    <div className="text-xs sm:text-sm font-bold opacity-90 mt-0.5">
                      {profile.jobTitle || 'المدير العام والتنفيذي'}
                    </div>
                    <div className="h-0.5 w-16 bg-amber-400 mt-2"></div>
                  </div>

                  {/* Card Footer: Fast contact snippets */}
                  <div className="flex items-center justify-between text-[10px] font-bold opacity-80 pt-2 border-t border-current/20 relative z-10">
                    <span dir="ltr">{profile.phone1 || '01141350759'}</span>
                    <span className="truncate max-w-[180px]">{profile.email || 'info@youadv.com'}</span>
                  </div>

                </div>

                {/* ================= BACK SIDE ================= */}
                <div
                  className={`absolute inset-0 backface-hidden rotate-y-180 p-6 flex flex-col justify-between overflow-hidden ${
                    cardOptions.corners === 'rounded' ? 'rounded-2xl' : 'rounded-sm'
                  } ${
                    cardOptions.style === 'luxury_navy'
                      ? 'bg-gradient-to-bl from-slate-900 via-blue-950 to-slate-900 text-white border-2 border-amber-400/40'
                      : cardOptions.style === 'gold_minimal'
                      ? 'bg-gradient-to-bl from-white via-slate-50 to-stone-100 text-slate-900 border border-slate-300 shadow-md'
                      : cardOptions.style === 'modern_dark'
                      ? 'bg-gradient-to-bl from-zinc-950 via-zinc-900 to-black text-white border border-zinc-800'
                      : cardOptions.style === 'mint_creative'
                      ? 'bg-gradient-to-bl from-sky-900 via-cyan-900 to-slate-900 text-white border-2 border-cyan-400/60'
                      : cardOptions.style === 'acrylic_transparent'
                      ? 'bg-white/40 backdrop-blur-md text-slate-900 border-2 border-white/80 shadow-2xl'
                      : 'bg-[#f4ebe1] text-[#3e2c1c] border border-[#d5c3b2]'
                  }`}
                >
                  
                  {/* Slogan Top */}
                  <div className="text-center relative z-10">
                    <p className="text-[11px] font-bold text-amber-300 italic">
                      "{profile.slogan || 'الريادة والتميز في عالم الطباعة والإعلان'}"
                    </p>
                  </div>

                  {/* Middle Contacts & QR Code */}
                  <div className="flex items-center justify-between gap-4 my-auto relative z-10">
                    
                    {/* Contacts Details List */}
                    <div className="space-y-1.5 text-[10px] sm:text-[11px] font-medium flex-1 text-right">
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span dir="ltr">{profile.phone1} {profile.phone2 ? `| ${profile.phone2}` : ''}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span className="truncate">{profile.email || 'info@company.com'}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span className="truncate">{profile.address || 'القاهرة - مصر'}</span>
                      </div>
                      {profile.website && (
                        <div className="flex items-center gap-1.5">
                          <Globe className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span dir="ltr">{profile.website}</span>
                        </div>
                      )}
                    </div>

                    {/* QR Code */}
                    {cardOptions.showQr && (
                      <div className="w-18 h-18 bg-white p-1.5 rounded-xl shadow-md flex flex-col items-center justify-center shrink-0 border border-slate-200">
                        {/* Realistic Mock QR Code */}
                        <div className="w-full h-full bg-slate-900 rounded-lg p-1 flex flex-col justify-between">
                          <div className="flex justify-between">
                            <div className="w-3 h-3 bg-white rounded-xs p-0.5"><div className="w-full h-full bg-slate-900"></div></div>
                            <div className="w-3 h-3 bg-white rounded-xs p-0.5"><div className="w-full h-full bg-slate-900"></div></div>
                          </div>
                          <div className="flex justify-center items-center">
                            <div className="w-2 h-2 bg-amber-400 rounded-full"></div>
                          </div>
                          <div className="flex justify-start">
                            <div className="w-3 h-3 bg-white rounded-xs p-0.5"><div className="w-full h-full bg-slate-900"></div></div>
                          </div>
                        </div>
                        <span className="text-[7px] text-slate-700 font-bold mt-0.5">vCard Scan</span>
                      </div>
                    )}

                  </div>

                  {/* Card Bottom: Legal line */}
                  <div className="text-[9px] opacity-70 flex justify-between border-t border-current/20 pt-1.5">
                    <span>س.ت: {profile.commercialReg || '142857'}</span>
                    <span>ب.ض: {profile.taxCard || '419-883-210'}</span>
                  </div>

                </div>

              </div>

            </div>

          </div>

          <div className="text-center text-xs text-slate-500 font-medium">
            💡 مقاس الكارت القياسي: 9 × 5 سم | ورق كوشيه ألماني فاخر 350 جرام
          </div>
        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span>باقات وخامات كروت البزنس</span>
            <span className="text-xs text-sky-700 font-bold">تسعير You Adv 2026</span>
          </h3>

          {/* Package Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700">
              اختر الباقة والكمية:
            </label>
            {CARD_PACKAGES.map((pkg) => (
              <button
                key={pkg.id}
                type="button"
                onClick={() => {
                  setSelectedPackage(pkg);
                  setCardOptions((prev) => ({ ...prev, cardCount: pkg.count, finish: pkg.finish as any }));
                }}
                className={`w-full p-3 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedPackage.id === pkg.id
                    ? 'border-sky-500 bg-sky-50/80 ring-1 ring-sky-300 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">{pkg.name}</span>
                  <span className="text-sm font-black text-sky-700">{pkg.price} ج.م</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>{pkg.delivery}</span>
                  {pkg.tag && (
                    <span className="bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-bold">
                      {pkg.tag}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Design Themes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              نمط التصميم والهوية:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {CARD_STYLES.map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setCardOptions((prev) => ({ ...prev, style: st.id as any }))}
                  className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                    cardOptions.style === st.id
                      ? 'border-sky-600 bg-sky-100/60 font-bold text-sky-950 ring-1 ring-sky-300'
                      : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <div className="text-xs truncate">{st.name}</div>
                  <div className="text-[9px] text-slate-500">{st.tag}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                شكل الزوايا:
              </label>
              <select
                value={cardOptions.corners}
                onChange={(e) => setCardOptions((prev) => ({ ...prev, corners: e.target.value as any }))}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500"
              >
                <option value="rounded">زوايا دائرية مستديرة (مودرن)</option>
                <option value="sharp">زوايا قائمة كلاسيكية</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                رمز QR الذكي:
              </label>
              <select
                value={cardOptions.showQr ? 'yes' : 'no'}
                onChange={(e) => setCardOptions((prev) => ({ ...prev, showQr: e.target.value === 'yes' }))}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500"
              >
                <option value="yes">إظهار QR لحفظ جهة الاتصال</option>
                <option value="no">إخفاء الـ QR Code</option>
              </select>
            </div>
          </div>

          {/* Add to order button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة باقة الكروت للطلب ({selectedPackage.price} ج.م)</span>
          </button>

        </div>

      </div>

    </div>
  );
};
