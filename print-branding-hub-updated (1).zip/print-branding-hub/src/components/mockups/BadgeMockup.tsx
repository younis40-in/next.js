import React, { useState } from 'react';
import { CompanyProfile, BadgeOptions } from '../../types';
import { Plus, Check, Shield, Award, Sparkles, Magnet } from 'lucide-react';

interface BadgeMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

export const BadgeMockup: React.FC<BadgeMockupProps> = ({ profile, onAddToCart }) => {
  const [badgeOptions, setBadgeOptions] = useState<BadgeOptions>({
    material: 'magnetic_brass',
    layout: 'badge_with_logo',
    quantity: 10,
  });

  const priceFor10 = 350; // As per catalog: باج اسم مغناطيسي 10 قطع بـ 350 ج.م

  const handleAddOrder = () => {
    onAddToCart({
      productId: 'magnetic_name_badges_10',
      title: 'باجات اسم مغناطيسية فاخرة (10 قطع)',
      category: 'badges',
      unitPrice: priceFor10,
      quantity: 1,
      optionsSummary: `الخامة: ${badgeOptions.material === 'magnetic_brass' ? 'نحاس مذهب' : 'فيبر فضي'} | الكمية: 10 باجات مخصصة`,
      customizationDetails: {
        material: badgeOptions.material,
        layout: badgeOptions.layout,
        fullName: profile.fullName,
        jobTitle: profile.jobTitle,
        companyName: profile.companyName,
      },
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-sky-900 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              عرض الكتالوج 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              باجات اسم مغناطيسية فاخرة (عرض 10 قطع)
            </h3>
          </div>
          <p className="text-xs text-sky-200 mt-1">
            باجات معدنية بمغناطيس ثلاثي فائق القوة تثبت على البدل والقمصان دون ثقب القماش
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              350 <span className="text-xs font-bold text-white">ج.م (لـ 10 باجات)</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">تسليم خلال ساعات</div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>طلب الباجات</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Visual Mockup Canvas (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-slate-100 p-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between">
            <span>معاينة حية للباج مثبت على البدلة الرسمية أو القميص:</span>
            <span className="text-sky-700 font-extrabold flex items-center gap-1">
              <Magnet className="w-3.5 h-3.5 text-red-500" />
              تثبيت مغناطيسي آمن
            </span>
          </div>

          {/* Realistic Suit Fabric Canvas */}
          <div className="relative bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950 rounded-2xl p-8 sm:p-14 flex items-center justify-center min-h-[340px] shadow-inner overflow-hidden">
            
            {/* Fabric Pinstripe Lines */}
            <div className="absolute inset-0 opacity-15 bg-[repeating-linear-gradient(90deg,#94a3b8_0,#94a3b8_1px,transparent_0,transparent_16px)]"></div>
            
            {/* Suit Lapel Collar Line */}
            <div className="absolute top-0 right-1/4 w-32 h-64 border-r-4 border-slate-700/80 -rotate-12 pointer-events-none opacity-40"></div>

            {/* The Badge Itself */}
            <div className={`relative z-10 w-full max-w-[340px] h-24 rounded-xl p-3.5 shadow-2xl flex items-center justify-between border-2 transform -rotate-1 hover:rotate-0 transition-transform duration-300 ${
              badgeOptions.material === 'magnetic_brass'
                ? 'bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 text-stone-950 border-amber-500 shadow-amber-950/40'
                : 'bg-gradient-to-r from-slate-200 via-white to-slate-300 text-slate-900 border-slate-400 shadow-black/40'
            }`}>
              
              {/* Badge Clear Dome Gloss Sheen */}
              <div className="absolute inset-0 bg-gradient-to-tr from-white/30 via-transparent to-white/10 rounded-xl pointer-events-none"></div>

              {/* Text Information */}
              <div className="flex-1 pr-1 text-right">
                <div className="text-[10px] font-bold opacity-80 truncate">
                  {profile.companyName || 'شركة يونس للإعلان'}
                </div>
                <div className="text-base sm:text-lg font-black tracking-tight leading-tight my-0.5 text-stone-950 font-['Cairo']">
                  {profile.fullName || 'نادر محمود'}
                </div>
                <div className="text-[11px] font-extrabold text-sky-900 opacity-95 truncate">
                  {profile.jobTitle || 'ضابط شرطة / مدير تسويق'}
                </div>
              </div>

              {/* Company Logo / Emblem on Badge */}
              <div className="w-12 h-12 rounded-lg bg-black/10 border border-black/15 flex items-center justify-center p-1 shrink-0">
                {profile.logoUrl ? (
                  <img src={profile.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" />
                ) : (
                  <span className="text-2xl">
                    {profile.logoIconId === 'balance' ? '⚖️' : profile.logoIconId === 'caduceus' ? '⚕️' : '🦅'}
                  </span>
                )}
              </div>

              {/* Magnet indicator pin badge */}
              <div className="absolute -bottom-2.5 -left-2 bg-slate-900 text-amber-400 text-[8px] font-bold px-2 py-0.5 rounded-full border border-amber-400/40 shadow-xs">
                مغناطيس ثلاثي قوي
              </div>

            </div>

          </div>

        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span>مواصفات باج الاسم</span>
            <span className="text-xs text-sky-700 font-bold">10 قطع بـ 350 ج.م</span>
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              نوع ولون المعدن:
            </label>
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setBadgeOptions((prev) => ({ ...prev, material: 'magnetic_brass' }))}
                className={`w-full p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                  badgeOptions.material === 'magnetic_brass'
                    ? 'border-amber-500 bg-amber-50 font-bold text-amber-950 ring-1 ring-amber-400'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs">🥇 نحاس مذهب فاخر (Brass Gold)</span>
                  <span className="text-[10px] text-amber-700 font-bold">الأكثر طلباً</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setBadgeOptions((prev) => ({ ...prev, material: 'magnetic_silver' }))}
                className={`w-full p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                  badgeOptions.material === 'magnetic_silver'
                    ? 'border-slate-500 bg-slate-100 font-bold text-slate-950 ring-1 ring-slate-400'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs">🥈 فيبر / استانلس فضي مطفي</span>
                  <span className="text-[10px] text-slate-600">فخم وعصري</span>
                </div>
              </button>
            </div>
          </div>

          <div className="p-3 bg-sky-50 rounded-xl border border-sky-100 text-xs text-sky-900">
            <strong>مميزات باجات You Adv:</strong>
            <ul className="list-disc list-inside mt-1 space-y-0.5 text-[11px]">
              <li>طبقة كريستال واقية من الخدش والماء</li>
              <li>مغناطيس نيوديميوم ثلاثي يمنع السقوط تماماً</li>
              <li>إمكانية كتابة أسماء ومسميات مختلفة لكل قطعة في الـ 10 باجات</li>
            </ul>
          </div>

          {/* Add to order button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة عرض 10 باجات للطلب (350 ج.م)</span>
          </button>

        </div>

      </div>

    </div>
  );
};
