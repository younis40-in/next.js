import React, { useState } from 'react';
import { CompanyProfile, StampOptions } from '../../types';
import { Download, Sparkles, Plus, Check, RefreshCw, Layers, Shield, AlertCircle, Droplet, X } from 'lucide-react';

interface StampMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

const INK_COLORS = [
  { id: 'blue', name: 'أزرق كحلي رسمي (الأساسي)', shortName: 'أزرق', hex: '#1e40af', bgClass: 'bg-blue-800', extraFee: 0, isStandard: true },
  { id: 'black', name: 'أسود فحمي وقور (+50 ج.م)', shortName: 'أسود (+50ج)', hex: '#18181b', bgClass: 'bg-zinc-900', extraFee: 50, isStandard: false },
  { id: 'red', name: 'أحمر اعتمادات وهام (+50 ج.م)', shortName: 'أحمر (+50ج)', hex: '#b91c1c', bgClass: 'bg-red-700', extraFee: 50, isStandard: false },
];

const STAMP_MODELS = [
  { id: 'traxx_small', name: 'تراكْس صغير (1.5 × 4 سم)', price: 190, dimensions: '1.5 × 4 سم', modelCode: 'Traxx 9010', type: 'traxx' },
  { id: 'traxx_medium', name: 'تراكْس وسط (2 × 5 سم)', price: 205, dimensions: '2 × 5 سم', modelCode: 'Traxx 9011', type: 'traxx', popular: true },
  { id: 'traxx_large', name: 'تراكْس كبير (2.3 × 5.6 سم)', price: 215, dimensions: '2.3 × 5.6 سم', modelCode: 'Traxx 9012', type: 'traxx' },
  { id: 'traxx_big_machine', name: 'ماكينة جامبو (2.5 × 5.5 سم)', price: 250, dimensions: '2.5 × 5.5 سم', modelCode: 'Traxx Mega', type: 'traxx' },
  { id: 'pocket_small', name: 'بوكيت جيب صغير (1.5 × 4 سم)', price: 300, dimensions: '1.5 × 4 سم', modelCode: 'Pocket Slim', type: 'pocket' },
  { id: 'pocket_large', name: 'بوكيت جيب كبير (2 × 5 سم)', price: 325, dimensions: '2 × 5 سم', modelCode: 'Pocket Max', type: 'pocket' },
];

export const StampMockup: React.FC<StampMockupProps> = ({ profile, onAddToCart }) => {
  const [stampOptions, setStampOptions] = useState<StampOptions>({
    modelType: 'traxx_medium',
    inkColor: 'blue',
    shape: 'rectangle',
    borderStyle: 'double',
    showDate: true,
    showEmblem: true,
    emblemType: 'eagle',
  });

  const [viewMode, setViewMode] = useState<'impression' | 'machine'>('impression');
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [pendingInkColor, setPendingInkColor] = useState<'black' | 'red' | null>(null);
  const [showInkPopup, setShowInkPopup] = useState(false);

  const selectedModel = STAMP_MODELS.find((m) => m.id === stampOptions.modelType) || STAMP_MODELS[1];
  const activeInk = INK_COLORS.find((c) => c.id === stampOptions.inkColor) || INK_COLORS[0];
  const extraInkFee = stampOptions.inkColor !== 'blue' ? 50 : 0;
  const currentTotalPrice = selectedModel.price + extraInkFee;

  const handleSelectInk = (inkId: 'blue' | 'black' | 'red') => {
    if (inkId === 'blue') {
      setStampOptions((prev) => ({ ...prev, inkColor: 'blue' }));
    } else {
      setPendingInkColor(inkId);
      setShowInkPopup(true);
    }
  };

  const confirmInkChange = () => {
    if (pendingInkColor) {
      setStampOptions((prev) => ({ ...prev, inkColor: pendingInkColor }));
    }
    setShowInkPopup(false);
    setPendingInkColor(null);
  };

  const cancelInkChange = () => {
    setShowInkPopup(false);
    setPendingInkColor(null);
  };

  const handleDownloadStampSVG = () => {
    const svgElement = document.getElementById('stamp-svg-target');
    if (!svgElement) return;

    const svgData = new XMLSerializer().serializeToString(svgElement);
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);
    const downloadLink = document.createElement('a');
    downloadLink.href = svgUrl;
    downloadLink.download = `YouAdv-Stamp-${profile.companyName || 'Seal'}.svg`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleAddOrder = () => {
    onAddToCart({
      productId: selectedModel.id,
      title: `ختم ${selectedModel.name}`,
      category: 'stamps',
      unitPrice: currentTotalPrice,
      quantity: 1,
      optionsSummary: `لون الحبر: ${activeInk.name} ${extraInkFee > 0 ? '(+50 ج.م)' : ''} | الشكل: ${stampOptions.shape === 'round' ? 'دائري' : 'مستطيل'}`,
      customizationDetails: {
        modelCode: selectedModel.modelCode,
        inkColor: activeInk.name,
        extraInkFee,
        shape: stampOptions.shape,
        borderStyle: stampOptions.borderStyle,
        textLine1: profile.stampTextLine1,
        textLine2: profile.stampTextLine2,
        textLine3: profile.stampTextLine3,
      },
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Price info */}
      <div className="bg-gradient-to-r from-sky-900 to-blue-900 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              تسعير 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              {selectedModel.name}
            </h3>
          </div>
          <p className="text-xs text-sky-200 mt-1">
            أختام تراكْس وبوكيت الأصلية عالية الجودة مع حبر ذاتي يدوم لآلاف الاستخدامات
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              {currentTotalPrice} <span className="text-xs font-bold text-white">ج.م</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">
              {extraInkFee > 0 ? `شامل +50 ج.م حبر ${activeInk.shortName}` : 'تسليم فوري خلال ساعات'}
            </div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>طلب الختم</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Visualizer + Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left/Main Column: Visual Mockup Canvas (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Canvas View Switcher */}
          <div className="flex items-center justify-between bg-slate-100 p-1 rounded-xl text-xs font-bold">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setViewMode('impression')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'impression'
                    ? 'bg-white text-sky-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                طبعة الختم على الورق
              </button>
              <button
                type="button"
                onClick={() => setViewMode('machine')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'machine'
                    ? 'bg-white text-sky-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                مجسم ماكينة الختم 3D
              </button>
            </div>

            <button
              onClick={handleDownloadStampSVG}
              className="flex items-center gap-1 text-[11px] font-bold text-sky-700 hover:text-sky-900 bg-white hover:bg-sky-50 px-2.5 py-1.5 rounded-lg border border-slate-200 transition-colors cursor-pointer"
              title="تحميل صيغة الختم SVG بجودة عالية لملفات الـ PDF والخطابات"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">تم التحميل!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-sky-600" />
                  <span>تصدير SVG للخطابات</span>
                </>
              )}
            </button>
          </div>

          {/* Canvas Stage */}
          <div className="relative bg-stone-100/90 rounded-2xl border border-stone-300/80 p-6 sm:p-10 flex items-center justify-center min-h-[340px] shadow-inner overflow-hidden">
            
            {/* Paper Texture Lines background */}
            <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:16px_16px]"></div>
            
            {/* Realistic Sheet of Official Document Paper */}
            <div className="relative z-10 w-full max-w-md bg-white p-6 rounded-xl shadow-lg border border-slate-200/90 transform transition-all duration-300">
              
              {/* Fake Document Context Lines */}
              <div className="space-y-1.5 mb-6 opacity-20 select-none pointer-events-none">
                <div className="h-2 bg-slate-400 rounded-sm w-3/4"></div>
                <div className="h-1.5 bg-slate-300 rounded-sm w-full"></div>
                <div className="h-1.5 bg-slate-300 rounded-sm w-5/6"></div>
              </div>

              {/* View Mode 1: Genuine Stamped Ink Impression (SVG Vector Render) */}
              {viewMode === 'impression' && (
                <div className="flex justify-center items-center py-4">
                  <div className="relative inline-block transform -rotate-1 hover:rotate-0 transition-transform duration-200">
                    
                    {stampOptions.shape === 'round' ? (
                      /* CIRCULAR CORPORATE SEAL */
                      <svg
                        id="stamp-svg-target"
                        viewBox="0 0 300 300"
                        className="w-56 h-56 sm:w-64 sm:h-64 drop-shadow-xs"
                        style={{ color: activeInk.hex }}
                      >
                        <defs>
                          <path
                            id="topCurve"
                            d="M 40,150 A 110,110 0 1,1 260,150"
                            fill="none"
                          />
                          <path
                            id="bottomCurve"
                            d="M 260,150 A 110,110 0 0,1 40,150"
                            fill="none"
                          />
                        </defs>

                        {/* Outer and Inner Circles */}
                        <circle cx="150" cy="150" r="140" fill="none" stroke="currentColor" strokeWidth="4.5" strokeDasharray={stampOptions.borderStyle === 'ornament' ? '8 4' : 'none'} />
                        <circle cx="150" cy="150" r="132" fill="none" stroke="currentColor" strokeWidth="1.5" />
                        <circle cx="150" cy="150" r="95" fill="none" stroke="currentColor" strokeWidth="2.5" />

                        {/* Top Curved Text */}
                        <text fill="currentColor" fontSize="15" fontWeight="900" letterSpacing="1.5">
                          <textPath href="#topCurve" startOffset="50%" textAnchor="middle">
                            ★ {profile.stampTextLine1 || 'يونس للإعلان You Adv'} ★
                          </textPath>
                        </text>

                        {/* Center Emblem & Data */}
                        <g transform="translate(150, 140)">
                          <text y="-10" textAnchor="middle" fill="currentColor" fontSize="13" fontWeight="800">
                            {profile.stampTextLine2 || 'إدارة التوكيلات والإنتاج'}
                          </text>

                          {/* Center Emblem Icon or Star */}
                          <text y="15" textAnchor="middle" fill="currentColor" fontSize="22">
                            {profile.logoIconId === 'balance' ? '⚖️' : profile.logoIconId === 'caduceus' ? '⚕️' : '🦅'}
                          </text>

                          {stampOptions.showDate && (
                            <text y="32" textAnchor="middle" fill="currentColor" fontSize="11" fontWeight="bold">
                              {profile.stampDate || '2026-08-18'}
                            </text>
                          )}
                        </g>

                        {/* Bottom Curved Text (Legal Line) */}
                        <text fill="currentColor" fontSize="12" fontWeight="800">
                          <textPath href="#bottomCurve" startOffset="50%" textAnchor="middle">
                            {profile.stampTextLine3 || `س.ت: ${profile.commercialReg || '142857'} - ب.ض: ${profile.taxCard || '419-883'}`}
                          </textPath>
                        </text>
                      </svg>
                    ) : (
                      /* RECTANGULAR / OVAL TRAXX STAMP */
                      <div
                        id="stamp-svg-target"
                        className={`p-4 sm:p-5 text-center transition-all ${
                          stampOptions.shape === 'oval' ? 'rounded-[50px]' : 'rounded-lg'
                        }`}
                        style={{
                          color: activeInk.hex,
                          border: `${stampOptions.borderStyle === 'double' ? '3.5px double' : '3px solid'} ${activeInk.hex}`,
                          backgroundColor: `${activeInk.hex}05`,
                        }}
                      >
                        {/* Stamp Header Line 1 */}
                        <div className="text-base sm:text-lg font-black tracking-tight leading-tight">
                          {profile.stampTextLine1 || profile.companyName || 'شركة يونس للحلول المتكاملة'}
                        </div>

                        {/* Decorative Divider with stars */}
                        <div className="flex items-center justify-center gap-2 my-1 text-xs opacity-90">
                          <div className="h-[1.5px] w-8 bg-current"></div>
                          <span>★</span>
                          <span>★</span>
                          <span>★</span>
                          <div className="h-[1.5px] w-8 bg-current"></div>
                        </div>

                        {/* Stamp Line 2 */}
                        <div className="text-xs sm:text-sm font-bold opacity-95">
                          {profile.stampTextLine2 || profile.jobTitle || 'إدارة المشروعات والاعتمادات الرسمية'}
                        </div>

                        {/* Date and Legal Line */}
                        <div className="mt-2 pt-1 border-t border-current/30 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] font-bold">
                          <span>{profile.stampTextLine3 || `س.ت: ${profile.commercialReg || '142857'}`}</span>
                          {stampOptions.showDate && (
                            <span className="px-1.5 py-0.5 rounded bg-current/10 text-[10px]">
                              التاريخ: {profile.stampDate || '2026-08-18'}
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Stamp authenticity watermark badge */}
                    <div className="absolute -bottom-2 -left-2 bg-white/90 px-1.5 py-0.5 rounded text-[9px] font-bold text-slate-400 border border-slate-200 select-none shadow-xs">
                      طبعة معتمدة
                    </div>
                  </div>
                </div>
              )}

              {/* View Mode 2: 3D Stamp Machine Visualizer */}
              {viewMode === 'machine' && (
                <div className="flex flex-col items-center justify-center py-6">
                  {selectedModel.type === 'traxx' ? (
                    /* TRAXX SELF-INKING MACHINE 3D RENDERING */
                    <div className="relative flex flex-col items-center">
                      {/* Machine Top Handle */}
                      <div className="w-24 h-12 bg-gradient-to-b from-slate-800 to-slate-950 rounded-t-2xl shadow-md border-t border-slate-700 flex items-center justify-center">
                        <span className="text-[10px] font-extrabold text-white tracking-widest uppercase">
                          TRAXX
                        </span>
                      </div>

                      {/* Machine Red/Blue accent ring */}
                      <div className="w-28 h-2 bg-gradient-to-r from-red-600 via-red-500 to-red-600 shadow-inner"></div>

                      {/* Machine Main Body with Brand & Transparent Index Window */}
                      <div className="w-36 h-28 bg-gradient-to-b from-slate-900 to-slate-950 rounded-b-xl shadow-2xl p-2.5 flex flex-col justify-between border border-slate-800 relative">
                        {/* Red side buttons */}
                        <div className="absolute top-4 -right-1.5 w-2 h-6 bg-red-600 rounded-r-md"></div>
                        <div className="absolute top-4 -left-1.5 w-2 h-6 bg-red-600 rounded-l-md"></div>

                        {/* Top Brand Label */}
                        <div className="flex justify-between items-center px-1">
                          <span className="text-[9px] font-bold text-slate-400">{selectedModel.modelCode}</span>
                          <span className="text-[9px] font-bold text-cyan-400">You Adv</span>
                        </div>

                        {/* Clear Window Showing Stamp Content */}
                        <div className="bg-white/95 rounded-lg p-2 text-center border border-slate-300 shadow-inner">
                          <div className="text-[10px] font-black text-slate-900 truncate">
                            {profile.stampTextLine1 || 'يونس للإعلان'}
                          </div>
                          <div className="text-[8px] font-bold text-slate-600 truncate mt-0.5">
                            {profile.stampTextLine2 || 'اعتماد رسمي'}
                          </div>
                          <div className="w-full h-1 mt-1 rounded-full" style={{ backgroundColor: activeInk.hex }}></div>
                        </div>

                        <div className="text-center text-[8px] font-bold text-slate-400">
                          {selectedModel.dimensions}
                        </div>
                      </div>

                      {/* Clear Base Skirt */}
                      <div className="w-40 h-8 bg-slate-200/90 rounded-b-xl border border-slate-300 shadow-lg flex items-center justify-center">
                        <span className="text-[9px] font-bold text-slate-600">حبر ذاتي أوتوماتيك</span>
                      </div>
                    </div>
                  ) : (
                    /* POCKET SLIM STAMP */
                    <div className="flex flex-col items-center">
                      <div className="w-32 h-16 bg-gradient-to-r from-red-700 via-red-600 to-red-800 rounded-xl shadow-xl border border-red-500 p-2 flex flex-col justify-between text-white">
                        <div className="flex justify-between text-[9px] font-bold">
                          <span>Pocket Stamp</span>
                          <span className="text-amber-300">You Adv</span>
                        </div>
                        <div className="bg-white/90 text-slate-950 text-[10px] font-black text-center py-1 rounded truncate">
                          {profile.stampTextLine1 || 'ختم جيب مدمج'}
                        </div>
                        <div className="text-center text-[8px] text-red-100">
                          متحرك خفيف للجيب والحقائب
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Bottom Document signature line */}
              <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-medium">
                <span>توقيع المدير المسؤول: .......................</span>
                <span>المقاس المعتمد: {selectedModel.dimensions}</span>
              </div>
            </div>

          </div>
        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
            <Layers className="w-4 h-4 text-sky-600" />
            خيارات ومقاسات الختم المتاح
          </h3>

          {/* 1. Model Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              اختر نوع وماكينة الختم:
            </label>
            <div className="space-y-1.5">
              {STAMP_MODELS.map((model) => (
                <button
                  key={model.id}
                  type="button"
                  onClick={() => setStampOptions((prev) => ({ ...prev, modelType: model.id as any }))}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-xs text-right transition-all cursor-pointer ${
                    stampOptions.modelType === model.id
                      ? 'border-sky-500 bg-sky-50/80 text-sky-950 font-bold shadow-xs ring-1 ring-sky-300'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100 text-slate-700 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full border ${stampOptions.modelType === model.id ? 'bg-sky-600 border-sky-600' : 'border-slate-300'}`}></div>
                    <span>{model.name}</span>
                  </div>
                  <span className="font-extrabold text-sky-700">{model.price} ج.م</span>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Ink Color Selector */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">
                لون الحبر الداخلي:
              </label>
              {extraInkFee > 0 ? (
                <span className="text-[10px] font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200">
                  +50 ج.م تغيير الحبر
                </span>
              ) : (
                <span className="text-[10px] font-bold text-slate-500">
                  الأزرق قياسي مجاني
                </span>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2">
              {INK_COLORS.map((ink) => {
                const isSelected = stampOptions.inkColor === ink.id;
                return (
                  <button
                    key={ink.id}
                    type="button"
                    onClick={() => handleSelectInk(ink.id as any)}
                    className={`flex flex-col items-center p-2.5 rounded-xl border text-center transition-all cursor-pointer relative ${
                      isSelected
                        ? 'border-sky-600 bg-sky-50/80 font-extrabold ring-2 ring-sky-600/30 shadow-xs'
                        : 'border-slate-200 bg-white hover:bg-slate-50 font-medium'
                    }`}
                  >
                    <span className={`w-6 h-6 rounded-full ${ink.bgClass} shadow-sm border-2 border-white flex items-center justify-center text-white`}>
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </span>
                    <span className="text-[11px] mt-1.5 text-slate-900 font-bold">
                      {ink.shortName}
                    </span>
                    {ink.extraFee > 0 && (
                      <span className="text-[9px] text-amber-700 font-extrabold mt-0.5">
                        +50 ج.م
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Shape & Border Style */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                شكل الإطار:
              </label>
              <select
                value={stampOptions.shape}
                onChange={(e) => setStampOptions((prev) => ({ ...prev, shape: e.target.value as any }))}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500"
              >
                <option value="rectangle">مستطيل قياسي</option>
                <option value="oval">بيضاوي أنيق</option>
                <option value="round">دائري رسمي (ختم النسر / الشركة)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                نوع البرواز:
              </label>
              <select
                value={stampOptions.borderStyle}
                onChange={(e) => setStampOptions((prev) => ({ ...prev, borderStyle: e.target.value as any }))}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500"
              >
                <option value="double">إطار مزدوج رسمي</option>
                <option value="single">إطار مفرد ناعم</option>
                <option value="ornament">إطار منقط وزخرفي</option>
                <option value="none">بدون إطار خارجي</option>
              </select>
            </div>
          </div>

          {/* 4. Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="flex items-center justify-between text-xs font-bold text-slate-700 cursor-pointer">
              <span>إدراج مربع التاريخ بالختم</span>
              <input
                type="checkbox"
                checked={stampOptions.showDate}
                onChange={(e) => setStampOptions((prev) => ({ ...prev, showDate: e.target.checked }))}
                className="w-4 h-4 text-sky-600 rounded cursor-pointer"
              />
            </label>
          </div>

          {/* Action Order Button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3 hover:scale-[1.01] active:scale-[0.99]"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة الختم لطلب الشراء والمقايسة ({currentTotalPrice} ج.م)</span>
          </button>

        </div>

      </div>

      {/* Pop-up Modal when Selecting Red or Black Ink */}
      {showInkPopup && pendingInkColor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-right">
            
            {/* Modal Header */}
            <div className={`p-4 text-white flex items-center justify-between ${
              pendingInkColor === 'red' 
                ? 'bg-gradient-to-r from-red-700 to-red-900' 
                : 'bg-gradient-to-r from-slate-900 to-zinc-800'
            }`}>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                  <Droplet className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-sm font-['Cairo']">
                    تغيير لون الحبر الأساسي
                  </h4>
                  <p className="text-[11px] text-white/80">
                    طلب تجهيز لون حبر خاص ({pendingInkColor === 'red' ? 'أحمر اعتمادات' : 'أسود وقور'})
                  </p>
                </div>
              </div>

              <button
                onClick={cancelInkChange}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-5 space-y-4">
              <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 p-3.5 rounded-2xl">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs text-slate-700 leading-relaxed">
                  <p className="font-bold text-amber-950">
                    ملاحظة فنية من قسم الطباعة والأختام:
                  </p>
                  <p>
                    الحبر القياسي المعتمد لماكينات الأختام هو <strong>اللون الأزرق</strong> (بدون أي رسوم إضافية).
                  </p>
                  <p>
                    عند اختيار اللون <strong>{pendingInkColor === 'red' ? 'الأحمر' : 'الأسود'}</strong>، يتم استبدال وتجهيز وسادة حبر مستوردة خاصة وتعبئتها بحبر ياباني عالي الكثافة لضمان نقاء الطباعة، ويتم إضافة <strong>٥٠ ج.م</strong> تكلفة تجهيز لون الحبر.
                  </p>
                </div>
              </div>

              {/* Price Breakdown Preview */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>سعر ماكينة الختم ({selectedModel.name}):</span>
                  <span className="font-bold">{selectedModel.price} ج.م</span>
                </div>
                <div className="flex justify-between text-amber-800 font-bold">
                  <span>إضافة حبر خاص ({pendingInkColor === 'red' ? 'أحمر' : 'أسود'}):</span>
                  <span>+50 ج.م</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-black text-slate-900">
                  <span>الإجمالي بعد تغيير الحبر:</span>
                  <span className="text-sky-700">{selectedModel.price + 50} ج.م</span>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={confirmInkChange}
                  className={`w-full sm:flex-1 py-3 px-4 rounded-xl text-xs font-black text-white shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 ${
                    pendingInkColor === 'red'
                      ? 'bg-red-700 hover:bg-red-800'
                      : 'bg-slate-900 hover:bg-black'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>تأكيد اللون وإضافة 50 ج.م</span>
                </button>

                <button
                  type="button"
                  onClick={cancelInkChange}
                  className="w-full sm:w-auto py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  الرجوع للأزرق القياسي (مجاناً)
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
