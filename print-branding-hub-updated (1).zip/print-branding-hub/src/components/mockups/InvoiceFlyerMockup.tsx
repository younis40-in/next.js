import React, { useState } from 'react';
import { CompanyProfile } from '../../types';
import { Plus, Check, FileSpreadsheet, Sparkles, Printer, FileText } from 'lucide-react';

interface InvoiceFlyerMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

const STATIONERY_ITEMS = [
  { id: 'invoice_books_quarter_20', name: 'دفاتر فواتير وسندات ربع A4 (20 دفتر)', price: 650, dimensions: 'ربع A4 (10.5 × 15 سم)', quantityStr: 'كمية 20 دفتر', type: 'invoice_quarter', tag: 'أفضل عرض للشركات' },
  { id: 'invoice_books_half_10', name: 'دفاتر فواتير وسندات نص A4 (10 دفاتر)', price: 600, dimensions: 'نص A4 (15 × 21 سم)', quantityStr: 'كمية 10 دفاتر عريضة', type: 'invoice_half', tag: 'للفواتير المفصلة' },
  { id: 'flyer_half_a4_bw', name: 'فلاير إعلاني نص A4 (1000 إعلان)', price: 450, dimensions: 'نص A4 (15 × 21 سم)', quantityStr: '1000 إعلان', type: 'flyer_half', tag: 'للانشار السريع' },
  { id: 'flyer_quarter_a4_bw', name: 'فلاير إعلاني ربع A4 (2000 إعلان)', price: 500, dimensions: 'ربع A4 (10.5 × 15 سم)', quantityStr: '2000 إعلان', type: 'flyer_quarter', tag: 'أكبر كمية انتشار' },
];

export const InvoiceFlyerMockup: React.FC<InvoiceFlyerMockupProps> = ({ profile, onAddToCart }) => {
  const [selectedItem, setSelectedItem] = useState(STATIONERY_ITEMS[0]);
  const [printOption, setPrintOption] = useState<'original_only' | 'carbon_copy'>('original_only');

  const handleAddOrder = () => {
    onAddToCart({
      productId: selectedItem.id,
      title: selectedItem.name,
      category: 'invoices_flyers',
      unitPrice: selectedItem.price,
      quantity: 1,
      optionsSummary: `الكمية: ${selectedItem.quantityStr} | المقاس: ${selectedItem.dimensions} | النوع: ${printOption === 'original_only' ? 'أصل فقط 50 ورقة/دفتر' : 'أصل وصورة مكربن'}`,
      customizationDetails: {
        item: selectedItem.name,
        dimensions: selectedItem.dimensions,
        companyName: profile.companyName,
        commercialReg: profile.commercialReg,
        taxCard: profile.taxCard,
        phone: profile.phone1,
        address: profile.address,
      },
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              تسعير 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              {selectedItem.name}
            </h3>
          </div>
          <p className="text-xs text-emerald-200 mt-1">
            دفاتر فواتير وسندات مكربنة وفلايرات إعلانية للانتشار السريع وتسيير أعمالك
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              {selectedItem.price} <span className="text-xs font-bold text-white">ج.م</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">{selectedItem.quantityStr}</div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>طلب المطبوعات</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Visual Mockup (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-slate-100 p-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between">
            <span>معاينة حية لدفتر الفواتير أو الفلاير الورقي:</span>
            <span className="text-teal-700 font-extrabold">{selectedItem.dimensions}</span>
          </div>

          {/* Realistic Paper Stage */}
          <div className="relative bg-gradient-to-b from-slate-200 via-stone-200 to-slate-300 rounded-2xl p-6 sm:p-10 flex items-center justify-center min-h-[420px] shadow-inner overflow-hidden">
            
            {/* Paper Document */}
            <div className="relative z-10 w-full max-w-md bg-white rounded-lg p-6 shadow-2xl border border-slate-300 transform -rotate-0.5 hover:rotate-0 transition-transform duration-300">
              
              {/* Top Perforation / Tear line for Invoice Book */}
              <div className="border-b-2 border-dashed border-slate-300 pb-2 mb-4 flex items-center justify-between text-[9px] text-slate-400 font-mono">
                <span>✄ خط فصل الورقة والتخريم</span>
                <span className="text-red-600 font-bold">No. 002481</span>
              </div>

              {/* Invoice Header */}
              <div className="flex items-start justify-between gap-3 pb-3 border-b-2 border-slate-900">
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                    {profile.companyName || 'شركة يونس للإعلان والمطبوعات'}
                  </h3>
                  <p className="text-[10px] text-slate-600 font-bold mt-0.5">
                    {profile.field || 'الأنشطة التجارية والتوكيلات'}
                  </p>
                  <p className="text-[9px] text-slate-500 mt-0.5">
                    س.ت: {profile.commercialReg || '142857'} | ب.ض: {profile.taxCard || '419-883'}
                  </p>
                </div>

                <div className="text-left shrink-0">
                  <span className="inline-block bg-slate-900 text-white font-black text-[11px] px-2 py-0.5 rounded">
                    فاتورة بيع / استلام
                  </span>
                  <div className="text-[9px] text-slate-500 font-bold mt-1" dir="ltr">
                    DATE: 2026 / 08 / 18
                  </div>
                </div>
              </div>

              {/* Customer Row */}
              <div className="grid grid-cols-2 gap-2 text-[10px] my-3 p-2 bg-slate-50 rounded border border-slate-200">
                <div>
                  <span className="font-bold text-slate-700">المطلوب من السيد: </span>
                  <span className="text-slate-500 font-mono">...........................</span>
                </div>
                <div>
                  <span className="font-bold text-slate-700">العنوان: </span>
                  <span className="text-slate-500 font-mono">...........................</span>
                </div>
              </div>

              {/* Invoice Itemized Table */}
              <div className="border border-slate-300 rounded overflow-hidden text-[10px]">
                <div className="grid grid-cols-12 bg-slate-100 font-black text-slate-800 p-1 border-b border-slate-300 text-center">
                  <div className="col-span-1">م</div>
                  <div className="col-span-6 text-right pr-1">بيان الصنف والخدمة</div>
                  <div className="col-span-2">الكمية</div>
                  <div className="col-span-3">الإجمالي</div>
                </div>
                <div className="grid grid-cols-12 p-1.5 border-b border-slate-100 text-slate-700">
                  <div className="col-span-1 text-center font-mono">1</div>
                  <div className="col-span-6 text-right pr-1 font-medium">توريد مطبوعات وهوية بصرية 2026</div>
                  <div className="col-span-2 text-center font-mono">1</div>
                  <div className="col-span-3 text-center font-mono font-bold">450.00</div>
                </div>
                <div className="grid grid-cols-12 p-1.5 border-b border-slate-100 text-slate-700 bg-slate-50/50">
                  <div className="col-span-1 text-center font-mono">2</div>
                  <div className="col-span-6 text-right pr-1 font-medium">ختم تراكْس رسمي حبر أزرق</div>
                  <div className="col-span-2 text-center font-mono">1</div>
                  <div className="col-span-3 text-center font-mono font-bold">205.00</div>
                </div>
                <div className="grid grid-cols-12 p-1 bg-slate-100/80 font-black text-slate-900">
                  <div className="col-span-9 text-left pl-2">إجمالي الفاتورة:</div>
                  <div className="col-span-3 text-center font-mono text-sky-800 font-black">655.00 ج.م</div>
                </div>
              </div>

              {/* Footer Signature and Stamp Watermark */}
              <div className="mt-4 pt-2 border-t border-slate-200 flex items-center justify-between text-[10px] relative">
                <div>
                  <div className="font-bold text-slate-700">توقيع المستلم: ....................</div>
                  <div className="text-[9px] text-slate-500 mt-1">{profile.address} - {profile.phone1}</div>
                </div>

                {/* Stamp Watermark in red/blue */}
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-blue-600/60 p-1 flex flex-col items-center justify-center text-center text-blue-700 -rotate-12 select-none pointer-events-none opacity-80">
                  <span className="text-[8px] font-black">{profile.companyName ? profile.companyName.split(' ')[0] : 'You Adv'}</span>
                  <span className="text-[7px] font-bold">معتمد</span>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span>باقات الدفاتر والفلايرات 2026</span>
            <span className="text-xs text-sky-700 font-bold">You Adv</span>
          </h3>

          {/* Stationery Packages List */}
          <div className="space-y-2">
            {STATIONERY_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedItem(item)}
                className={`w-full p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedItem.id === item.id
                    ? 'border-emerald-600 bg-emerald-50/80 ring-1 ring-emerald-400 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">{item.name}</span>
                  <span className="text-sm font-black text-emerald-800">{item.price} ج.م</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>{item.dimensions}</span>
                  {item.tag && (
                    <span className="bg-emerald-100 text-emerald-900 font-bold px-1.5 py-0.2 rounded">
                      {item.tag}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Add to order button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة باقة المطبوعات للطلب ({selectedItem.price} ج.م)</span>
          </button>

        </div>

      </div>

    </div>
  );
};
