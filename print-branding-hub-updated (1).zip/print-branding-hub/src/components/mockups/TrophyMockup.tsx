import React, { useState } from 'react';
import { CompanyProfile, TrophyOptions } from '../../types';
import { Plus, Check, Award, Sparkles, Shield, Gift } from 'lucide-react';

interface TrophyMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

const TROPHY_ITEMS = [
  { id: 'crystal_trophy_small', name: 'درع كريستال فاخر صغير مع العلبة القطيفة', price: 150, dimensions: '18 × 12 سم', type: 'crystal', popular: true, tag: 'سعر اقتصادي وتكريم مشرف' },
  { id: 'crystal_trophy_medium', name: 'درع كريستال وسط فاخر مع العلبة القطيفة', price: 300, dimensions: '23 × 15 سم', type: 'crystal_medium', popular: true, tag: 'الأكثر طلباً للتكريم' },
  { id: 'sports_medals_trio', name: 'ميداليات رياضية وتكريمية فاخرة (ذهبي / فضي / برونزي)', price: 65, dimensions: 'قطر 6.5 سم', type: 'medal', tag: 'شامل الشريط والطباعة' },
];

export const TrophyMockup: React.FC<TrophyMockupProps> = ({ profile, onAddToCart }) => {
  const [selectedTrophy, setSelectedTrophy] = useState(TROPHY_ITEMS[1]);
  const [trophyOptions, setTrophyOptions] = useState<TrophyOptions>({
    size: 'crystal_medium',
    boxColor: 'navy_blue_velvet',
    engravingTone: 'gold_leaf',
  });

  const handleAddOrder = () => {
    onAddToCart({
      productId: selectedTrophy.id,
      title: selectedTrophy.name,
      category: 'trophies',
      unitPrice: selectedTrophy.price,
      quantity: 1,
      optionsSummary: `النوع: ${selectedTrophy.name} | العلبة: ${trophyOptions.boxColor === 'navy_blue_velvet' ? 'قطيفة كحلي' : 'قطيفة نبيتي فاخر'}`,
      customizationDetails: {
        trophy: selectedTrophy.name,
        price: selectedTrophy.price,
        recipientName: profile.fullName,
        companyName: profile.companyName,
        tributeText: profile.trophyTribute,
        boxColor: trophyOptions.boxColor,
      },
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-red-950 via-slate-900 to-blue-950 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              تسعير 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              الدروع الكريستالية والميداليات التكريمية الفاخرة
            </h3>
          </div>
          <p className="text-xs text-amber-200/90 mt-1">
            شاملة العلبة القطيفة الكبس الفاخرة والطباعة الكاملة أو الحفر بالليزر
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              {selectedTrophy.price} <span className="text-xs font-bold text-white">ج.م</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">تسليم خلال 24 ساعة</div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>طلب الدرع</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Visual Mockup (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-slate-100 p-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between">
            <span>معاينة حية للدرع داخل العلبة القطيفة الفاخرة:</span>
            <span className="text-amber-700 font-extrabold">{selectedTrophy.dimensions}</span>
          </div>

          {/* Realistic Trophy Mockup Stage */}
          <div className="relative bg-gradient-to-b from-stone-800 via-stone-900 to-black rounded-2xl p-6 sm:p-10 flex items-center justify-center min-h-[400px] shadow-inner overflow-hidden">
            
            {/* Ambient Spotlight */}
            <div className="absolute inset-0 bg-radial from-amber-400/20 via-transparent to-transparent"></div>

            {selectedTrophy.type === 'medal' ? (
              /* SPORTS / HONORING MEDALS MOCKUP */
              <div className="relative z-10 flex flex-col items-center">
                {/* Ribbons */}
                <div className="w-10 h-24 bg-gradient-to-b from-blue-700 via-blue-600 to-blue-800 rounded-t-lg shadow-lg"></div>
                {/* Gold Medal */}
                <div className="relative -mt-4 w-36 h-36 rounded-full bg-gradient-to-tr from-amber-600 via-amber-300 to-amber-500 p-2 shadow-2xl border-4 border-amber-400 flex flex-col items-center justify-center text-center text-stone-950">
                  <div className="w-full h-full rounded-full border-2 border-dashed border-amber-900/60 p-2 flex flex-col items-center justify-center">
                    <span className="text-2xl">🥇</span>
                    <span className="text-[10px] font-black">{profile.companyName || 'You Adv'}</span>
                    <span className="text-[9px] font-bold text-stone-900 truncate max-w-[100px]">{profile.fullName}</span>
                    <span className="text-[8px] font-bold text-amber-900">2026</span>
                  </div>
                </div>
              </div>
            ) : (
              /* LUXURY CRYSTAL TROPHY IN VELVET CASE */
              <div className="relative z-10 w-full max-w-sm flex flex-col items-center">
                
                {/* Velvet Presentation Box Shell */}
                <div className={`w-full rounded-2xl p-6 shadow-2xl border-4 relative overflow-hidden ${
                  trophyOptions.boxColor === 'navy_blue_velvet'
                    ? 'bg-[#0f172a] border-[#1e293b]'
                    : 'bg-[#450a0a] border-[#7f1d1d]'
                }`}>
                  
                  {/* Velvet Box Inner Silk Satin Lining (Gold / Cream) */}
                  <div className="bg-gradient-to-b from-[#fef3c7] via-[#fffbeb] to-[#fde68a] rounded-xl p-6 shadow-inner border border-amber-200 text-center relative">
                    
                    {/* The Crystal Trophy Itself */}
                    <div className="bg-white/80 backdrop-blur-md rounded-xl p-5 shadow-2xl border-2 border-white/90 text-stone-900 relative">
                      
                      {/* Top Golden Crest */}
                      <div className="w-10 h-10 mx-auto rounded-full bg-gradient-to-tr from-amber-400 to-amber-200 border border-amber-500 flex items-center justify-center text-lg shadow-sm mb-2">
                        {profile.logoIconId === 'balance' ? '⚖️' : profile.logoIconId === 'caduceus' ? '⚕️' : '🏆'}
                      </div>

                      <div className="text-[10px] font-bold text-stone-600 mb-0.5">
                        {profile.companyName || 'مؤسسة يونس للإعلان'}
                      </div>

                      <div className="text-xs font-black text-amber-900 mb-1">
                        درع شكر وتقدير ووفاء
                      </div>

                      {/* Recipient Full Name */}
                      <h3 className="text-base sm:text-lg font-black text-stone-950 leading-tight my-1.5 font-['Cairo']">
                        {profile.fullName || 'أحمد محمود سالم'}
                      </h3>

                      {/* Tribute Inscription */}
                      <p className="text-[10px] sm:text-[11px] font-medium text-stone-800 leading-relaxed my-2 px-2 italic">
                        "{profile.trophyTribute || 'تقديراً لجهوده الاستثنائية وتفانيه المستمر في النجاح والعطاء لعام 2026'}"
                      </p>

                      <div className="h-0.5 w-16 bg-amber-400 mx-auto my-2"></div>

                      <div className="flex justify-between text-[9px] font-bold text-stone-500 pt-1 border-t border-stone-200">
                        <span>مع تحيات الإدارة</span>
                        <span>2026</span>
                      </div>

                    </div>

                    {/* Crystal Base Stand */}
                    <div className="w-3/4 h-3 bg-cyan-900/30 backdrop-blur-md mx-auto rounded-b-md mt-1 border-t border-cyan-400/40"></div>

                  </div>

                  {/* Velvet Box Latch Gold Accent */}
                  <div className="w-8 h-3 bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 rounded-full mx-auto mt-2 border border-amber-600"></div>

                </div>

              </div>
            )}

          </div>

        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span>مقاسات الدروع والميداليات</span>
            <span className="text-xs text-sky-700 font-bold">تسعير You Adv 2026</span>
          </h3>

          {/* Trophy List */}
          <div className="space-y-2">
            {TROPHY_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedTrophy(item)}
                className={`w-full p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedTrophy.id === item.id
                    ? 'border-red-600 bg-red-50/80 ring-1 ring-red-400 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">{item.name}</span>
                  <span className="text-sm font-black text-red-800">{item.price} ج.م</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>{item.dimensions}</span>
                  {item.tag && (
                    <span className="bg-amber-100 text-amber-900 font-bold px-1.5 py-0.2 rounded">
                      {item.tag}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Velvet Box Color */}
          {selectedTrophy.type !== 'medal' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                لون العلبة القطيفة الكبس:
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTrophyOptions((prev) => ({ ...prev, boxColor: 'navy_blue_velvet' }))}
                  className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    trophyOptions.boxColor === 'navy_blue_velvet'
                      ? 'border-blue-900 bg-blue-50 text-blue-950 ring-2 ring-blue-500'
                      : 'border-slate-200 bg-slate-50 text-slate-700'
                  }`}
                >
                  🟦 قطيفة كحلي ملكي (Navy)
                </button>

                <button
                  type="button"
                  onClick={() => setTrophyOptions((prev) => ({ ...prev, boxColor: 'bordeaux_red_velvet' }))}
                  className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    trophyOptions.boxColor === 'bordeaux_red_velvet'
                      ? 'border-red-900 bg-red-50 text-red-950 ring-2 ring-red-500'
                      : 'border-slate-200 bg-slate-50 text-slate-700'
                  }`}
                >
                  🟥 قطيفة نبيتي فاخر (Bordeaux)
                </button>
              </div>
            </div>
          )}

          {/* Add to order button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-red-700 to-red-800 hover:from-red-800 hover:to-red-900 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة الدرع للطلب والمقايسة ({selectedTrophy.price} ج.م)</span>
          </button>

        </div>

      </div>

    </div>
  );
};
