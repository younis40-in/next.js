import React, { useState } from 'react';
import { CompanyProfile, DeskSignOptions } from '../../types';
import { Plus, Check, Sparkles, Shield, Award, Layers } from 'lucide-react';

interface DeskSignMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

const DESK_PRODUCTS = [
  { id: 'wood_small_pen', name: 'قاعدة مكتب خشب كلاسيكية مع قلم ذهبي', price: 350, dimensions: '25 × 10 سم', type: 'wood', popular: true, tag: 'فخر الإنتاج المصري' },
  { id: 'wood_luxury_large', name: 'قاعدة مكتب خشبية ملكية فاخرة كبيرة', price: 650, dimensions: '35 × 12 سم', type: 'wood_luxury', tag: 'للمديرين والمستشارين' },
  { id: 'crystal_desk_pyramid', name: 'قاعدة هرم مكتب كريستال فاخر كبير', price: 350, dimensions: '22 × 8 سم', type: 'crystal', tag: 'كريستال بصري نقي' },
  { id: 'office_door_sign', name: 'لافتة باب ومكتب (أكريليك / نحاس / فيبر)', price: 280, dimensions: '30 × 10 سم', type: 'plate', tag: 'مع مسامير استانلس ديكورية' },
  { id: 'leather_desk_set_small', name: 'طقم مكتب جلد عملي وأنيق (مقاس صغير 4 قطع)', price: 600, dimensions: 'طقم 4 قطع', type: 'leather', tag: 'جلد فاخر' },
  { id: 'leather_desk_set_large', name: 'طقم مكتب جلد تنفيذي كبير (طقم 6 قطع)', price: 850, dimensions: 'طقم 6 قطع متكامل', type: 'leather', tag: 'الطقم الملكي الأكمل' },
];

export const DeskSignMockup: React.FC<DeskSignMockupProps> = ({ profile, onAddToCart }) => {
  const [selectedProduct, setSelectedProduct] = useState(DESK_PRODUCTS[0]);
  const [deskOptions, setDeskOptions] = useState<DeskSignOptions>({
    baseType: 'wood_small_pen',
    plateColor: 'gold_brass',
    fontStyle: 'classic_thuluth',
    includePenHolder: true,
  });

  const handleAddOrder = () => {
    onAddToCart({
      productId: selectedProduct.id,
      title: selectedProduct.name,
      category: 'desk_signs',
      unitPrice: selectedProduct.price,
      quantity: 1,
      optionsSummary: `الخامة: ${selectedProduct.dimensions} | الشريحة: ${deskOptions.plateColor === 'gold_brass' ? 'نحاس مذهب' : 'فضة كروم'} | الخط: ${deskOptions.fontStyle === 'classic_thuluth' ? 'ثلث كلاسيكي' : 'كايرو هندسي'}`,
      customizationDetails: {
        product: selectedProduct.name,
        dimensions: selectedProduct.dimensions,
        plateColor: deskOptions.plateColor,
        fontStyle: deskOptions.fontStyle,
        fullName: profile.fullName,
        jobTitle: profile.jobTitle,
        companyName: profile.companyName,
      },
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Price info */}
      <div className="bg-gradient-to-r from-amber-950 via-stone-900 to-sky-950 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              تسعير 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              {selectedProduct.name}
            </h3>
          </div>
          <p className="text-xs text-amber-200/90 mt-1">
            لافتات وقواعد وأهرامات المكاتب التنفيذية بأعلى درجات الفخامة والحفر بالليزر
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              {selectedProduct.price} <span className="text-xs font-bold text-white">ج.م</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">تسليم خلال 24 ساعة</div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>طلب اللافتة</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Visual Mockup (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-stone-100 p-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between">
            <span>معاينة حية لقاعدة ولافتة المكتب في بيئة عمل تنفيذية:</span>
            <span className="text-amber-700 font-extrabold">{selectedProduct.dimensions}</span>
          </div>

          {/* Realistic Executive Desk Scene */}
          <div className="relative bg-gradient-to-b from-slate-200 via-stone-200 to-stone-400 rounded-2xl p-6 sm:p-10 flex items-center justify-center min-h-[380px] shadow-inner overflow-hidden">
            
            {/* Ambient Background & Desk Surface */}
            <div className="absolute inset-0 bg-radial from-amber-100/20 via-transparent to-stone-900/30"></div>
            
            {/* Wooden Desk Surface Base */}
            <div className="absolute bottom-0 inset-x-0 h-32 bg-gradient-to-t from-stone-800 via-stone-700 to-transparent opacity-60"></div>

            {/* MOCKUP 1: Classic or Luxury Wood Desk Base */}
            {(selectedProduct.type === 'wood' || selectedProduct.type === 'wood_luxury') && (
              <div className="relative z-10 flex flex-col items-center transform -rotate-1 hover:rotate-0 transition-transform duration-300 w-full max-w-md">
                
                {/* Mahogany Wood Slanted Base */}
                <div className="w-full bg-gradient-to-r from-[#451e11] via-[#5c2817] to-[#3a180d] rounded-t-xl p-6 sm:p-8 shadow-2xl border-t-2 border-[#823d24] relative overflow-hidden">
                  
                  {/* Subtle Wood Grain Texture Reflection */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"></div>
                  
                  {/* Brass Engraved Plaque */}
                  <div className={`relative z-10 rounded-lg p-4 sm:p-5 text-center shadow-lg border ${
                    deskOptions.plateColor === 'gold_brass'
                      ? 'bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 text-stone-950 border-amber-500/80 shadow-amber-900/20'
                      : 'bg-gradient-to-r from-slate-200 via-slate-100 to-slate-300 text-stone-950 border-slate-400 shadow-slate-900/20'
                  }`}>
                    {/* Metallic Corner Screws / Bolts */}
                    <div className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-700/80 border border-amber-950 flex items-center justify-center text-[7px] text-white">✚</div>
                    <div className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-amber-700/80 border border-amber-950 flex items-center justify-center text-[7px] text-white">✚</div>
                    <div className="absolute bottom-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-700/80 border border-amber-950 flex items-center justify-center text-[7px] text-white">✚</div>
                    <div className="absolute bottom-1.5 left-1.5 w-2 h-2 rounded-full bg-amber-700/80 border border-amber-950 flex items-center justify-center text-[7px] text-white">✚</div>

                    {/* Company Crest or Logo */}
                    <div className="text-xs font-bold opacity-85 mb-1 tracking-wide">
                      {profile.companyName || 'مجموعة الأفق للاستشارات'}
                    </div>

                    {/* Main Name in Arabic Typography */}
                    <h2 className="text-xl sm:text-2xl font-black tracking-tight leading-none text-stone-950 my-1 drop-shadow-xs font-['Cairo']">
                      {profile.fullName || 'أحمد محمود سالم'}
                    </h2>

                    {/* Decorative Arabic Divider */}
                    <div className="flex items-center justify-center gap-2 my-1.5 opacity-70">
                      <div className="h-[1px] w-12 bg-stone-900"></div>
                      <span className="text-[10px]">◆</span>
                      <div className="h-[1px] w-12 bg-stone-900"></div>
                    </div>

                    {/* Job Title */}
                    <div className="text-xs sm:text-sm font-extrabold text-stone-900 opacity-95">
                      {profile.jobTitle || 'المدير العام والتنفيذي'}
                    </div>
                  </div>

                  {/* Golden Pen Holder Attachment */}
                  <div className="absolute -top-3 left-6 flex items-center gap-2">
                    <div className="w-5 h-8 bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 rounded-t-full shadow-lg border border-amber-600"></div>
                    {selectedProduct.type === 'wood_luxury' && (
                      <div className="w-5 h-8 bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 rounded-t-full shadow-lg border border-amber-600"></div>
                    )}
                  </div>
                </div>

                {/* Solid Wood Base Platform with Beveled Edge & Shadow */}
                <div className="w-[106%] h-6 bg-gradient-to-b from-[#33140a] to-[#200b05] rounded-b-xl shadow-2xl border-t border-[#6e301b]"></div>
                <div className="w-[90%] h-3 bg-black/40 blur-md rounded-full mt-1"></div>
              </div>
            )}

            {/* MOCKUP 2: Crystal Prism Desk Sign */}
            {selectedProduct.type === 'crystal' && (
              <div className="relative z-10 flex flex-col items-center w-full max-w-md">
                <div className="w-full bg-white/60 backdrop-blur-xl rounded-xl p-8 shadow-2xl border-2 border-white/90 text-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-tr from-cyan-200/20 via-transparent to-amber-200/20 pointer-events-none"></div>
                  
                  {/* Beveled Optical Glass Reflection Lines */}
                  <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"></div>

                  <div className="text-xs font-bold text-slate-600 mb-1">
                    {profile.companyName || 'شركة يونس للإعلان'}
                  </div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight my-2">
                    {profile.fullName || 'أحمد محمود سالم'}
                  </h2>
                  <div className="h-0.5 w-16 bg-cyan-600 mx-auto my-2"></div>
                  <div className="text-sm font-bold text-sky-800">
                    {profile.jobTitle || 'الرئيس التنفيذي'}
                  </div>
                </div>
                {/* Crystal Beveled Base */}
                <div className="w-[104%] h-5 bg-cyan-900/30 backdrop-blur-md rounded-b-lg border-t border-cyan-300/40 shadow-xl"></div>
              </div>
            )}

            {/* MOCKUP 3: Office Door & Wall Sign with Stainless Spacers */}
            {selectedProduct.type === 'plate' && (
              <div className="relative z-10 w-full max-w-md bg-white/90 backdrop-blur-md rounded-xl p-6 shadow-2xl border-2 border-slate-300 text-center">
                {/* 4 Stainless Steel Wall Spacers */}
                <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-slate-500 border border-slate-600 shadow-md"></div>
                <div className="absolute top-2 left-2 w-4 h-4 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-slate-500 border border-slate-600 shadow-md"></div>
                <div className="absolute bottom-2 right-2 w-4 h-4 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-slate-500 border border-slate-600 shadow-md"></div>
                <div className="absolute bottom-2 left-2 w-4 h-4 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-slate-500 border border-slate-600 shadow-md"></div>

                <div className="p-4 bg-gradient-to-r from-amber-200 via-amber-100 to-amber-300 rounded-lg border border-amber-400 text-stone-950">
                  <div className="text-xs font-bold opacity-80">{profile.companyName}</div>
                  <h3 className="text-xl font-black my-1">{profile.fullName}</h3>
                  <div className="text-xs font-extrabold">{profile.jobTitle}</div>
                </div>
                <div className="text-[10px] text-slate-500 mt-2">مقاس 30 × 10 سم مخصص للأبواب والمكاتب</div>
              </div>
            )}

            {/* MOCKUP 4: Leather Desk Set */}
            {selectedProduct.type === 'leather' && (
              <div className="relative z-10 w-full max-w-md bg-gradient-to-br from-zinc-900 via-black to-zinc-950 text-white rounded-2xl p-6 shadow-2xl border border-zinc-800">
                <div className="border-2 border-dashed border-amber-500/40 p-4 rounded-xl text-center">
                  <div className="text-amber-400 text-xs font-bold mb-1">
                    {selectedProduct.name}
                  </div>
                  <div className="text-lg font-black text-white">
                    {profile.fullName}
                  </div>
                  <div className="text-xs text-zinc-400 mt-1">
                    {profile.jobTitle} | {profile.companyName}
                  </div>
                </div>
                <div className="flex justify-around text-[10px] text-zinc-400 mt-4 pt-3 border-t border-zinc-800">
                  <span>باد كتابة</span>
                  <span>حامل أقلام</span>
                  <span>حامل كروت</span>
                  <span>حامل أوراق</span>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span>أنواع وخامات لافتات وقواعد المكاتب</span>
            <span className="text-xs text-sky-700 font-bold">تسعير 2026</span>
          </h3>

          {/* Products List */}
          <div className="space-y-2">
            {DESK_PRODUCTS.map((prod) => (
              <button
                key={prod.id}
                type="button"
                onClick={() => setSelectedProduct(prod)}
                className={`w-full p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedProduct.id === prod.id
                    ? 'border-amber-600 bg-amber-50/80 ring-1 ring-amber-400 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">{prod.name}</span>
                  <span className="text-sm font-black text-amber-700">{prod.price} ج.م</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>المقاس: {prod.dimensions}</span>
                  {prod.tag && (
                    <span className="bg-amber-100 text-amber-900 font-bold px-1.5 py-0.2 rounded">
                      {prod.tag}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Color of Metallic Plaque */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              لون الشريحة المعدنية المطبوعة / المحفورة:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setDeskOptions((prev) => ({ ...prev, plateColor: 'gold_brass' }))}
                className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  deskOptions.plateColor === 'gold_brass'
                    ? 'border-amber-500 bg-amber-100/70 text-amber-950 ring-1 ring-amber-400'
                    : 'border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                🥇 نحاس مذهب لامع (Classic Gold)
              </button>

              <button
                type="button"
                onClick={() => setDeskOptions((prev) => ({ ...prev, plateColor: 'silver_chrome' }))}
                className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  deskOptions.plateColor === 'silver_chrome'
                    ? 'border-slate-500 bg-slate-200 text-slate-950 ring-1 ring-slate-400'
                    : 'border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                🥈 فضة كروم مطفي (Brushed Silver)
              </button>
            </div>
          </div>

          {/* Add to order button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة لافتة المكتب للطلب ({selectedProduct.price} ج.م)</span>
          </button>

        </div>

      </div>

    </div>
  );
};
