import React, { useState } from 'react';
import { CompanyProfile } from '../../types';
import { Plus, Check, Flag, ShoppingBag, Sparkles } from 'lucide-react';

interface FlagBagMockupProps {
  profile: CompanyProfile;
  onAddToCart: (itemDetails: any) => void;
}

const FLAG_BAG_ITEMS = [
  { id: 'office_mini_flag', name: 'علم مكتب استانلس فاخر', price: 200, dimensions: 'ارتفاع 30 سم', type: 'flag_office', popular: true, tag: 'للمكاتب وقاعات الاجتماعات' },
  { id: 'feather_flag_single', name: 'علم سنارة مفرد للمعارض والمحلات (Feather Flag)', price: 650, dimensions: 'ارتفاع 3 أمتار', type: 'flag_feather', tag: 'لجذب الأنظار خارج المحل' },
  { id: 'tall_pole_flag_1800', name: 'علم ساري كبير كامل للمباني والمؤسسات', price: 1800, dimensions: 'ساري ألومنيوم 6 متر', type: 'flag_tall', tag: 'للواجهات والنوادي' },
];

export const FlagBagMockup: React.FC<FlagBagMockupProps> = ({ profile, onAddToCart }) => {
  const [selectedItem, setSelectedItem] = useState(FLAG_BAG_ITEMS[0]);

  const handleAddOrder = () => {
    onAddToCart({
      productId: selectedItem.id,
      title: selectedItem.name,
      category: 'flags_bags',
      unitPrice: selectedItem.price,
      quantity: 1,
      optionsSummary: `المقاس: ${selectedItem.dimensions} | الشعار: ${profile.companyName}`,
      customizationDetails: {
        item: selectedItem.name,
        dimensions: selectedItem.dimensions,
        companyName: profile.companyName,
        slogan: profile.slogan,
      },
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-sky-900 via-cyan-900 to-slate-900 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md">
              تسعير 2026
            </span>
            <h3 className="text-base font-bold font-['Cairo']">
              أعلام المعارض والمكاتب والستاندات
            </h3>
          </div>
          <p className="text-xs text-sky-200 mt-1">
            أعلام قماش ستان وبوليستر مقاومة للعوامل الجوية مع ساريات وقواعد متينة
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl font-black text-amber-300 font-['Cairo']">
              {selectedItem.price} <span className="text-xs font-bold text-white">ج.م</span>
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">تسليم فوري أو 24 ساعة</div>
          </div>

          <button
            onClick={handleAddOrder}
            className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>طلب العلم</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Visual Mockup (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-slate-100 p-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between">
            <span>معاينة حية للعلم:</span>
            <span className="text-sky-700 font-extrabold">{selectedItem.dimensions}</span>
          </div>

          {/* Realistic 3D Flag Stage */}
          <div className="relative bg-gradient-to-b from-sky-100 via-slate-100 to-stone-200 rounded-2xl p-6 sm:p-10 flex items-center justify-center min-h-[400px] shadow-inner overflow-hidden">
            
            {/* Feather Flag / Beach Banner Mockup */}
            {selectedItem.type === 'flag_feather' ? (
              <div className="relative z-10 flex flex-col items-center">
                {/* 3m Curved Feather Flag */}
                <div className="relative w-32 sm:w-40 h-72 sm:h-80 bg-gradient-to-b from-sky-600 via-blue-600 to-cyan-500 rounded-tr-[80px] p-3 text-white shadow-2xl flex flex-col justify-between border-l-4 border-slate-800">
                  <div className="text-[10px] font-black tracking-widest text-amber-300 uppercase transform -rotate-90 origin-bottom-left translate-y-36 translate-x-4">
                    {profile.companyName || 'You Adv'}
                  </div>
                  <div className="my-auto text-center">
                    <span className="text-3xl">🚩</span>
                    <div className="text-xs font-black mt-2">{profile.slogan || 'يونس للإعلان'}</div>
                  </div>
                  <div className="text-[9px] font-bold text-center text-sky-100 pb-2">
                    {profile.phone1}
                  </div>
                </div>
                {/* Water Base */}
                <div className="w-24 h-5 bg-slate-700 rounded-full shadow-lg border border-slate-600 -mt-1"></div>
              </div>
            ) : (
              /* Mini Desk Flag Stainless Stand */
              <div className="relative z-10 flex flex-col items-center">
                {/* Silver Pole Tip */}
                <div className="w-3 h-3 rounded-full bg-gradient-to-tr from-slate-400 to-white shadow-xs"></div>
                {/* Pole Line */}
                <div className="w-1.5 h-64 bg-gradient-to-r from-slate-400 via-slate-200 to-slate-500 relative flex items-start">
                  {/* Silk Flag */}
                  <div className="relative -mr-0.5 w-44 h-32 bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 text-white rounded-r-lg p-3 shadow-xl border-r-2 border-amber-400 flex flex-col justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="text-lg">🏢</span>
                      <span className="text-[11px] font-black text-amber-300 truncate">{profile.companyName || 'You Adv'}</span>
                    </div>
                    <div className="text-center my-auto text-xs font-bold">
                      {profile.slogan || 'رؤية تصنع المستقبل'}
                    </div>
                    <div className="text-[9px] text-slate-300 flex justify-between border-t border-white/20 pt-1">
                      <span>2026</span>
                      <span dir="ltr">{profile.phone1}</span>
                    </div>
                  </div>
                </div>
                {/* Circular Stainless Steel Base */}
                <div className="w-24 h-4 bg-gradient-to-r from-slate-400 via-slate-100 to-slate-400 rounded-full shadow-xl border border-slate-500 -mt-1"></div>
              </div>
            )}

          </div>

        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span>أنواع ومقاسات الأعلام والستاندات</span>
            <span className="text-xs text-sky-700 font-bold">2026</span>
          </h3>

          <div className="space-y-2">
            {FLAG_BAG_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedItem(item)}
                className={`w-full p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedItem.id === item.id
                    ? 'border-sky-600 bg-sky-50/80 ring-1 ring-sky-400 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">{item.name}</span>
                  <span className="text-sm font-black text-sky-800">{item.price} ج.م</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>المقاس: {item.dimensions}</span>
                  {item.tag && (
                    <span className="bg-sky-100 text-sky-900 font-bold px-1.5 py-0.2 rounded">
                      {item.tag}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Add to order button */}
          <button
            onClick={handleAddOrder}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-bold py-3 rounded-xl text-xs shadow-md hover:shadow-lg transition-all cursor-pointer mt-3"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة العلم للطلب ({selectedItem.price} ج.م)</span>
          </button>

        </div>

      </div>

    </div>
  );
};
