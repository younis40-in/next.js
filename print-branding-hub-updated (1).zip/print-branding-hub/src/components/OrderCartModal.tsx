import React, { useState, useEffect } from 'react';
import { CartItem, CompanyProfile, OrderHistoryRecord, CustomerOrder } from '../types';
import { getStoredOrders, saveStoredOrders, INITIAL_PRODUCTION_STAGES } from '../data/ordersStore';
import { 
  X, 
  Trash2, 
  MessageCircle, 
  Printer, 
  FileText,
  Download,
  MapPin, 
  Phone, 
  Clock, 
  ShieldCheck, 
  ShoppingBag, 
  CheckCircle2,
  Sparkles,
  ArrowRight,
  RotateCcw,
  History,
  Plus,
  Check,
  PackageCheck,
  Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuotationModal } from './QuotationModal';

interface OrderCartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  setCartItems: React.Dispatch<React.SetStateAction<CartItem[]>>;
  profile: CompanyProfile;
  onOpenTracker?: (orderNumber: string) => void;
}

const GOVERNORATES = [
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'القليوبية',
  'الشرقية',
  'الدقهلية',
  'الغربية',
  'المنوفية',
  'البحيرة',
  'كفر الشيخ',
  'دمياط',
  'بورسعيد',
  'الإسماعيلية',
  'السويس',
  'الفيوم',
  'بني سويف',
  'المنيا',
  'أسيوط',
  'سوهاج',
  'قنا',
  'الأقصر',
  'أسوان',
  'البحر الأحمر',
  'مطروح'
];

const STORAGE_KEY = 'youadv_order_history_v1';

export const OrderCartModal: React.FC<OrderCartModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  setCartItems,
  profile,
  onOpenTracker,
}) => {
  const [shippingMethod, setShippingMethod] = useState<'pickup' | 'cairo_express' | 'governorates'>('cairo_express');
  const [selectedGovernorate, setSelectedGovernorate] = useState('القاهرة');
  const [customerNotes, setCustomerNotes] = useState('');
  const [orderSent, setOrderSent] = useState(false);
  const [lastGeneratedOrderNumber, setLastGeneratedOrderNumber] = useState('');
  const [isQuotationOpen, setIsQuotationOpen] = useState(false);
  const [activeView, setActiveView] = useState<'cart' | 'history'>('cart');
  const [reorderFeedback, setReorderFeedback] = useState<string | null>(null);

  // Load Order History from localStorage or seed initial realistic orders
  const [orderHistory, setOrderHistory] = useState<OrderHistoryRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load order history', e);
    }
    
    // Seed default realistic previous orders
    return [
      {
        id: 'hist_1',
        orderNumber: 'YOU-ORD-2026-9214',
        date: 'منذ أسبوعين • 02 أغسطس 2026',
        shippingMethod: 'cairo_express',
        governorate: 'القاهرة',
        totalAmount: 525,
        items: [
          {
            id: 'item_prev_1',
            productId: 'stamp_medium',
            title: 'ختم تراكْس 9011 وسط أوتوماتيك (2 × 5 سم)',
            category: 'stamps',
            unitPrice: 205,
            quantity: 1,
            totalPrice: 205,
            optionsSummary: 'لون الحبر: أزرق ملكي | إطار مزدوج كلاسيكي | Traxx 9011',
            customizationDetails: {}
          },
          {
            id: 'item_prev_2',
            productId: 'card_luxury_matte',
            title: '1000 كارت شخصي بيزنس فاخر (سلوفان مط دبل فيس)',
            category: 'cards',
            unitPrice: 320,
            quantity: 1,
            totalPrice: 320,
            optionsSummary: 'كوشيه 350 جرام فاخر | سليفان مط وجهين | QR vCard ذكي',
            customizationDetails: {}
          }
        ]
      },
      {
        id: 'hist_2',
        orderNumber: 'YOU-ORD-2026-8840',
        date: 'منذ شهر • 18 يوليو 2026',
        shippingMethod: 'pickup',
        governorate: 'القاهرة',
        totalAmount: 700,
        items: [
          {
            id: 'item_prev_3',
            productId: 'desk_wood_pen',
            title: 'لافتة مكتب خشب ماهوجني فاخر مع قلم ذهبي',
            category: 'desk_signs',
            unitPrice: 350,
            quantity: 1,
            totalPrice: 350,
            optionsSummary: 'قاعدة خشب طبيعي معتق | شريحة نحاس محفورة بالليزر | خط ثلث كلاسيكي',
            customizationDetails: {}
          },
          {
            id: 'item_prev_4',
            productId: 'badges_brass_10',
            title: '10 باجات أسماء مغناطيسية (نحاس مذهب محفور ليزر)',
            category: 'badges',
            unitPrice: 350,
            quantity: 1,
            totalPrice: 350,
            optionsSummary: 'نحاس مذهب عالي اللمعان | مغناطيس ثلاثي فائق القوة | 10 قطع',
            customizationDetails: {}
          }
        ]
      },
      {
        id: 'hist_3',
        orderNumber: 'YOU-ORD-2026-7931',
        date: 'منذ شهرين • 04 يونيو 2026',
        shippingMethod: 'cairo_express',
        governorate: 'الجيزة',
        totalAmount: 450,
        items: [
          {
            id: 'item_prev_5',
            productId: 'trophy_crystal_royal',
            title: 'درع كريستال تكريم ملكي مع علبة قطيفة كبس',
            category: 'trophies',
            unitPrice: 450,
            quantity: 1,
            totalPrice: 450,
            optionsSummary: 'كريستال بصري K9 نقي | حفر ليزر ثلاثي الأبعاد مع لمسات ذهبية | علبة قطيفة كحلي',
            customizationDetails: {}
          }
        ]
      }
    ];
  });

  // Persist history to localStorage
  const saveOrderHistory = (updated: OrderHistoryRecord[]) => {
    setOrderHistory(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save order history', e);
    }
  };

  const showReorderToast = (msg: string) => {
    setReorderFeedback(msg);
    setTimeout(() => {
      setReorderFeedback(null);
    }, 3000);
  };

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.totalPrice, 0);

  // Buy 2 Get 1 Free discount calculation: for every 3 items of an eligible product, 1 item is free
  const promoDiscount = cartItems.reduce((acc, item) => {
    const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
    if (isOfferItem && item.quantity >= 3) {
      const freeCount = Math.floor(item.quantity / 3);
      return acc + (freeCount * item.unitPrice);
    }
    return acc;
  }, 0);

  const totalFreeItemsCount = cartItems.reduce((acc, item) => {
    const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
    if (isOfferItem && item.quantity >= 3) {
      return acc + Math.floor(item.quantity / 3);
    }
    return acc;
  }, 0);

  const discountedSubtotal = Math.max(0, subtotal - promoDiscount);
  const shippingCost = shippingMethod === 'pickup' ? 0 : shippingMethod === 'cairo_express' ? 50 : 70;
  const grandTotal = discountedSubtotal + shippingCost;

  const handleQuantityChange = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = Math.max(1, item.quantity + delta);
            return {
              ...item,
              quantity: newQty,
              totalPrice: item.unitPrice * newQty,
            };
          }
          return item;
        })
    );
  };

  const handleApplyPromoThirdPiece = (id: string) => {
    setCartItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newQty = item.quantity + 1;
          return {
            ...item,
            quantity: newQty,
            totalPrice: item.unitPrice * newQty,
            buy2Get1Free: true,
          };
        }
        return item;
      })
    );
    showReorderToast('🎉 تم تفعيل العرض وإضافة القطعة الثالثة مجاناً 100%!');
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Quick Reorder: Add entire previous order to current cart
  const handleQuickReorderAll = (record: OrderHistoryRecord) => {
    const newItemsWithFreshIds: CartItem[] = record.items.map((item) => ({
      ...item,
      id: `${item.productId}_reorder_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    }));

    setCartItems((prev) => [...prev, ...newItemsWithFreshIds]);
    setActiveView('cart');
    showReorderToast(`تمت إضافة ${newItemsWithFreshIds.length} أصناف من الطلب (${record.orderNumber}) إلى السلة بنجاح!`);
    
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  // Quick Reorder: Add a single item from past history
  const handleQuickReorderSingleItem = (item: CartItem) => {
    const freshItem: CartItem = {
      ...item,
      id: `${item.productId}_reorder_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };

    setCartItems((prev) => [...prev, freshItem]);
    showReorderToast(`تمت إضافة "${item.title}" إلى السلة!`);
  };

  const handleSendWhatsAppOrder = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    const generatedOrderNum = `YOU-ORD-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setLastGeneratedOrderNumber(generatedOrderNum);

    // Record this order into history
    const newHistoryRecord: OrderHistoryRecord = {
      id: `hist_${Date.now()}`,
      orderNumber: generatedOrderNum,
      date: `اليوم • ${new Date().toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}`,
      shippingMethod,
      governorate: selectedGovernorate,
      totalAmount: grandTotal,
      items: [...cartItems],
    };

    saveOrderHistory([newHistoryRecord, ...orderHistory]);

    // Save full live CustomerOrder into ordersStore for Admin Dashboard & Live Customer Tracker
    const newCustomerOrder: CustomerOrder = {
      id: `ord_${Date.now()}`,
      orderNumber: generatedOrderNum,
      createdAt: `اليوم • ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
      customerName: profile.fullName || 'عميل You Adv',
      customerPhone: profile.phone1 || '01141350759',
      customerEmail: profile.email || '',
      companyName: profile.companyName,
      address: profile.address || selectedGovernorate,
      governorate: selectedGovernorate,
      shippingMethod,
      status: 'received',
      statusArabic: 'تم استلام وتأكيد بيانات الطلب',
      subtotal,
      discount: promoDiscount,
      shippingFee: shippingCost,
      grandTotal,
      customerNotes,
      items: [...cartItems],
      stages: INITIAL_PRODUCTION_STAGES(`اليوم • ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`),
    };

    const existingOrders = getStoredOrders();
    saveStoredOrders([newCustomerOrder, ...existingOrders]);

    let message = `*طلب جديد من ستوديو يونس للإعلان You Adv (تسعير 2026)*\n\n`;
    message += `🔖 *رقم الطلب:* ${generatedOrderNum}\n`;
    message += `👤 *العميل:* ${profile.fullName || 'غير محدد'}\n`;
    message += `🏢 *الشركة/النشاط:* ${profile.companyName || '---'}\n`;
    message += `📱 *رقم الهاتف:* ${profile.phone1}\n`;
    message += `📍 *العنوان:* ${profile.address || selectedGovernorate} (${selectedGovernorate})\n`;
    message += `⚖️ *س.ت / ب.ض:* ${profile.commercialReg || '---'} / ${profile.taxCard || '---'}\n\n`;
    
    message += `📋 *المنتجات المطلوبة بالمقايسة:*\n`;
    cartItems.forEach((item, index) => {
      const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
      const freeUnits = isOfferItem && item.quantity >= 3 ? Math.floor(item.quantity / 3) : 0;
      message += `${index + 1}. *${item.title}*\n`;
      message += `   - الكمية: ${item.quantity}${freeUnits > 0 ? ` (منها ${freeUnits} مجانية بعرض 2+1)` : ''}\n`;
      message += `   - المواصفات: ${item.optionsSummary}\n`;
      message += `   - السعر الأصلي: ${item.totalPrice} ج.م\n`;
    });

    if (promoDiscount > 0) {
      message += `\n🎁 *خصم عرض التطبيق (اشتري 2 واحصل على الـ 3 مجاناً):* -${promoDiscount} ج.م (${totalFreeItemsCount} قطعة مجاناً)\n`;
    }

    message += `\n🚚 *طريقة الاستلام:* ${
      shippingMethod === 'pickup'
        ? 'استلام من المقر (شارع محمد علي، الموسكي، القاهرة)'
        : shippingMethod === 'cairo_express'
        ? 'توصيل فوري خلال ساعات (القاهرة/الجيزة)'
        : `شحن محافظات (${selectedGovernorate})`
    }\n`;

    if (customerNotes) {
      message += `📝 *ملاحظات العميل:* ${customerNotes}\n`;
    }

    message += `\n💰 *الإجمالي النهائي المستحق:* ${grandTotal} ج.م\n`;
    message += `\n_تم إرسال الطلب والمواصفات من خلال منصة You Adv 2026_`;

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/201141350759?text=${encoded}`, '_blank');
    setOrderSent(true);
  };

  const handlePrintProof = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
        
        {/* Toast feedback for reorder actions */}
        {reorderFeedback && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-lg flex items-center gap-2 border border-emerald-500 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-amber-300" />
            <span>{reorderFeedback}</span>
          </div>
        )}

        {/* Modal Header */}
        <div className="bg-gradient-to-r from-sky-900 via-blue-900 to-sky-950 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/10 border border-white/20">
              <ShoppingBag className="w-5 h-5 text-cyan-300" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-['Cairo']">
                سلة الطلبات والمقايسة الفورية
              </h3>
              <p className="text-xs text-sky-200">
                يونس للإعلان You Adv - تسعير رسمي ومراجعة التنفيذ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Reorder Switcher Button */}
            <button
              onClick={() => setActiveView(activeView === 'cart' ? 'history' : 'cart')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                activeView === 'history'
                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md font-black'
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
              }`}
              title="إعادة طلب سريع من مشترياتك السابقة"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${activeView === 'history' ? 'animate-spin-once' : ''}`} />
              <span className="hidden sm:inline">
                {activeView === 'history' ? 'العودة للسلة' : 'إعادة طلب سريع (Reorder)'}
              </span>
              <span className="sm:hidden">
                {activeView === 'history' ? 'السلة' : 'إعادة طلب'}
              </span>
              <span className="bg-amber-500/30 text-amber-200 text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold">
                {orderHistory.length}
              </span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal View Selector Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2">
          <button
            onClick={() => setActiveView('cart')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeView === 'cart'
                ? 'border-sky-600 text-sky-900 bg-white rounded-t-xl font-black shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>السلة الحالية ({cartItems.length})</span>
          </button>

          <button
            onClick={() => setActiveView('history')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeView === 'history'
                ? 'border-amber-500 text-amber-900 bg-white rounded-t-xl font-black shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-600" />
            <span>إعادة طلب سريع / الطلبات السابقة ({orderHistory.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-6 max-h-[72vh] overflow-y-auto">
          
          {/* VIEW 1: ACTIVE CART */}
          {activeView === 'cart' && (
            <>
              {cartItems.length === 0 ? (
                <div className="text-center py-8 space-y-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h4 className="text-base font-bold text-slate-800">
                    سلة الطلبات فارغة حالياً
                  </h4>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    اختر أي منتج من الاستوديو، أو استخدم زر إعادة الطلب السريع لاسترجاع طلبياتك السابقة بضغطة زر واحدة.
                  </p>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-2">
                    <button
                      onClick={() => setActiveView('history')}
                      className="flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer w-full sm:w-auto"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>إعادة طلب من المشتريات السابقة (Quick Reorder)</span>
                    </button>

                    <button
                      onClick={onClose}
                      className="bg-sky-700 hover:bg-sky-800 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition-colors cursor-pointer w-full sm:w-auto"
                    >
                      تصفح المنتجات والاستوديو
                    </button>
                  </div>

                  {/* Quick Reorder Suggestions Preview */}
                  {orderHistory.length > 0 && (
                    <div className="pt-4 text-right border-t border-slate-100">
                      <div className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                        <History className="w-3.5 h-3.5 text-amber-600" />
                        <span>آخر باقة تم طلبها:</span>
                      </div>
                      <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div>
                          <div className="text-xs font-black text-slate-900 font-['Cairo']">
                            {orderHistory[0].orderNumber} • {orderHistory[0].items.length} أصناف
                          </div>
                          <div className="text-[11px] text-slate-600 mt-0.5">
                            {orderHistory[0].items.map(i => i.title).join(' + ')}
                          </div>
                        </div>
                        <button
                          onClick={() => handleQuickReorderAll(orderHistory[0])}
                          className="flex items-center gap-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow-xs transition-all cursor-pointer whitespace-nowrap"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>إعادة إضافة للسلة ({orderHistory[0].totalAmount} ج.م)</span>
                        </button>
                      </div>
                    </div>
                  )}

                </div>
              ) : (
                <>
                  {/* Items List */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-700 flex items-center gap-2">
                        <span>المنتجات المخصصة بالسلة ({cartItems.length}):</span>
                      </h4>

                      {/* Top Quick Reorder pill */}
                      <button
                        onClick={() => setActiveView('history')}
                        className="text-[11px] text-amber-800 hover:text-amber-950 font-bold bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-lg border border-amber-200 flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <RotateCcw className="w-3 h-3 text-amber-600" />
                        <span>إضافة أصناف من طلب سابق</span>
                      </button>
                    </div>

                    <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-slate-50/50">
                      {cartItems.map((item) => {
                        const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
                        const freeUnits = isOfferItem && item.quantity >= 3 ? Math.floor(item.quantity / 3) : 0;
                        const canGetThirdFree = isOfferItem && item.quantity % 3 === 2;

                        return (
                          <div key={item.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
                            <div className="flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-xs font-black text-slate-900">{item.title}</span>
                                <span className="text-[10px] bg-sky-100 text-sky-800 font-bold px-1.5 py-0.2 rounded">
                                  {item.unitPrice} ج.م / وحدة
                                </span>

                                {isOfferItem && (
                                  <span className="text-[10px] bg-amber-100 text-amber-900 font-black px-1.5 py-0.2 rounded border border-amber-300">
                                    مشمول بعرض 2+1 مجاناً
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500 mt-0.5">{item.optionsSummary}</p>

                              {/* Promo Badges & Prompts */}
                              {freeUnits > 0 && (
                                <div className="mt-1 inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg">
                                  <Sparkles className="w-3 h-3 text-emerald-600" />
                                  <span>مطبّق: {freeUnits} قطعة مجانية 100% (وفرت {freeUnits * item.unitPrice} ج.م)</span>
                                </div>
                              )}

                              {canGetThirdFree && (
                                <div className="mt-1 flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => handleApplyPromoThirdPiece(item.id)}
                                    className="inline-flex items-center gap-1.5 text-[11px] font-black text-orange-950 bg-gradient-to-r from-amber-200 to-orange-300 hover:from-amber-300 hover:to-orange-400 border border-orange-400/50 px-2.5 py-1 rounded-lg shadow-xs transition-all cursor-pointer animate-pulse"
                                  >
                                    <Sparkles className="w-3.5 h-3.5 text-orange-700" />
                                    <span>💡 أضف القطعة الـ 3 مجاناً الآن! (عرض التطبيق)</span>
                                  </button>
                                </div>
                              )}
                            </div>

                            <div className="flex items-center justify-between sm:justify-end gap-4">
                              {/* Quantity Controls */}
                              <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                                <button
                                  onClick={() => handleQuantityChange(item.id, -1)}
                                  className="w-7 h-7 flex items-center justify-center text-slate-600 hover:bg-slate-200 rounded-r-lg font-black text-xs cursor-pointer"
                                >
                                  -
                                </button>
                                <span className="w-8 text-center text-xs font-bold text-slate-900 font-mono">
                                  {item.quantity}
                                </span>
                                <button
                                  onClick={() => handleQuantityChange(item.id, 1)}
                                  className="w-7 h-7 flex items-center justify-center text-slate-600 hover:bg-slate-200 rounded-l-lg font-black text-xs cursor-pointer"
                                >
                                  +
                                </button>
                              </div>

                              {/* Total per line */}
                              <div className="text-right min-w-[75px]">
                                {freeUnits > 0 ? (
                                  <div>
                                    <div className="text-sm font-black text-emerald-800 font-mono">
                                      {item.totalPrice - (freeUnits * item.unitPrice)}
                                      <span className="text-[10px] text-emerald-800 font-bold mr-1">ج.م</span>
                                    </div>
                                    <div className="text-[10px] text-slate-400 line-through font-mono">
                                      {item.totalPrice} ج.م
                                    </div>
                                  </div>
                                ) : (
                                  <div>
                                    <span className="text-sm font-black text-slate-900 font-mono">
                                      {item.totalPrice}
                                    </span>
                                    <span className="text-[10px] text-slate-500 font-bold mr-1">ج.م</span>
                                  </div>
                                )}
                              </div>

                              {/* Remove */}
                              <button
                                onClick={() => handleRemoveItem(item.id)}
                                className="text-slate-400 hover:text-red-600 transition-colors p-1 cursor-pointer"
                                title="حذف من السلة"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Delivery / Shipping Options */}
                  <div className="space-y-3 pt-2">
                    <label className="block text-xs font-bold text-slate-800">
                      اختر طريقة الاستلام ومكان التوصيل:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setShippingMethod('cairo_express')}
                        className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                          shippingMethod === 'cairo_express'
                            ? 'border-sky-500 bg-sky-50 font-bold text-sky-950 ring-1 ring-sky-300'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className="text-xs font-black">توصيل القاهرة والجيزة</div>
                        <div className="text-[10px] text-emerald-700 font-bold mt-1">تسليم فوري (50 ج.م)</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShippingMethod('governorates')}
                        className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                          shippingMethod === 'governorates'
                            ? 'border-sky-500 bg-sky-50 font-bold text-sky-950 ring-1 ring-sky-300'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className="text-xs font-black">شحن لكافة المحافظات</div>
                        <div className="text-[10px] text-slate-600 mt-1">1 - 3 أيام (70 ج.م)</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShippingMethod('pickup')}
                        className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                          shippingMethod === 'pickup'
                            ? 'border-sky-500 bg-sky-50 font-bold text-sky-950 ring-1 ring-sky-300'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className="text-xs font-black">استلام من المقر</div>
                        <div className="text-[10px] text-slate-600 mt-1">العتبة، الموسكي (مجاناً)</div>
                      </button>
                    </div>

                    {shippingMethod === 'governorates' && (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          اختر محافظتك:
                        </label>
                        <select
                          value={selectedGovernorate}
                          onChange={(e) => setSelectedGovernorate(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500"
                        >
                          {GOVERNORATES.map((gov) => (
                            <option key={gov} value={gov}>
                              {gov}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>

                  {/* Customer Notes */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      ملاحظات أو تعديلات خاصة على التصميم والتنفيذ:
                    </label>
                    <textarea
                      rows={2}
                      value={customerNotes}
                      onChange={(e) => setCustomerNotes(e.target.value)}
                      placeholder="مثال: يرجى إرسال بروفة الختم على الواتساب قبل الحفر..."
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-sky-500"
                    />
                  </div>

                  {/* Summary Calculation Box */}
                  <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-2">
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>إجمالي المنتجات قبل الخصم:</span>
                      <span className="font-mono font-bold text-white">{subtotal} ج.م</span>
                    </div>

                    {promoDiscount > 0 && (
                      <div className="flex justify-between text-xs text-emerald-400 bg-emerald-950/60 p-2 rounded-xl border border-emerald-700/50">
                        <span className="flex items-center gap-1 font-bold">
                          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                          خصم عرض التطبيق (اشتري 2 واحصل على 3 مجاناً):
                        </span>
                        <span className="font-mono font-black text-emerald-300">-{promoDiscount} ج.م</span>
                      </div>
                    )}

                    <div className="flex justify-between text-xs text-slate-300">
                      <span>تكلفة الشحن والتوصيل:</span>
                      <span className="font-mono font-bold text-white">{shippingCost} ج.م</span>
                    </div>
                    <div className="h-px bg-slate-800 my-1"></div>
                    <div className="flex justify-between items-center text-sm font-black">
                      <span className="text-amber-400">الإجمالي النهائي المستحق:</span>
                      <span className="text-xl font-black text-amber-300 font-mono">
                        {grandTotal} <span className="text-xs text-white font-bold">ج.م</span>
                      </span>
                    </div>
                  </div>

                  {/* Order Sent Live Tracking Callout */}
                  {orderSent && (
                    <div className="p-4 bg-gradient-to-r from-emerald-950 to-slate-900 border-2 border-emerald-500 rounded-2xl text-white space-y-3 text-right animate-fadeIn shadow-xl">
                      <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        <span>تم إرسال الطلب وحفظه بنجاح لدى إدارة You Adv!</span>
                      </div>
                      <p className="text-xs text-slate-200 leading-relaxed">
                        رقم طلبك الخاص هو: <strong className="text-amber-300 font-mono text-sm bg-black/40 px-2 py-0.5 rounded border border-amber-300/40">{lastGeneratedOrderNumber}</strong>. يمكنك الآن مشاهدة مراحل تصنيع وتجهيز منتجك بالصور الحية من ورشة الليزر والمطبعة.
                      </p>
                      {onOpenTracker && (
                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onOpenTracker(lastGeneratedOrderNumber);
                          }}
                          className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          <span>الانتقال فوراً لمتابعة مراحل تصنيع طلبي المباشرة</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Preliminary Design Notice */}
                  {!orderSent && (
                    <div className="flex items-start gap-2.5 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200">
                      <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                      <p className="text-[11px] leading-relaxed">
                        التصميم المعروض تقريبي (أولي) لتوضيح الشكل العام. بمجرد تأكيد الحجز، سيرسل فريقنا <strong className="text-amber-300">التصميم النهائي الجاهز للطباعة</strong> لاعتماده معك قبل بدء التنفيذ.
                      </p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                    <button
                      onClick={handleSendWhatsAppOrder}
                      className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 px-4 rounded-xl text-xs sm:text-sm shadow-lg hover:shadow-emerald-600/30 transition-all cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 fill-white text-emerald-600" />
                      <span>{orderSent ? 'إعادة إرسال عبر واتساب' : 'إرسال الطلب عبر واتساب'}</span>
                    </button>

                    <button
                      onClick={() => setIsQuotationOpen(true)}
                      className="flex items-center justify-center gap-2 bg-sky-700 hover:bg-sky-800 text-white font-bold py-3.5 px-4 rounded-xl text-xs transition-all shadow-md hover:shadow-sky-700/25 cursor-pointer"
                      title="توليد وتصدير عرض سعر رسمي PDF معتمد"
                    >
                      <FileText className="w-4 h-4 text-cyan-300" />
                      <span>تصدير عرض سعر (PDF)</span>
                    </button>

                    <button
                      onClick={handlePrintProof}
                      className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-3.5 px-3.5 rounded-xl text-xs transition-colors cursor-pointer border border-slate-300"
                      title="طباعة بروفة ومقايسة سريعة"
                    >
                      <Printer className="w-4 h-4 text-slate-600" />
                      <span>طباعة سريعة</span>
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-4 text-[11px] text-slate-500 font-medium text-center">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      ضمان جودة الخامات والتنفيذ
                    </span>
                    <span>•</span>
                    <span>مقرنا: شارع محمد علي - العتبة - القاهرة</span>
                  </div>
                </>
              )}
            </>
          )}

          {/* VIEW 2: ORDER HISTORY & QUICK REORDER */}
          {activeView === 'history' && (
            <div className="space-y-5">
              <div className="bg-amber-50/80 rounded-2xl p-4 border border-amber-200/80 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-900 shrink-0">
                  <RotateCcw className="w-5 h-5 text-amber-700" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-black font-['Cairo'] text-amber-950">
                    ميزة إعادة الطلب السريع (Quick Reorder)
                  </h4>
                  <p className="text-xs text-amber-900/80 leading-relaxed">
                    يمكنك بنقرة واحدة إعادة طلب أي شحنة أو منتج سبق شراؤه بالكامل مع نفس المواصفات والخامات المعتمدة دون الحاجة لإعادة إدخال البيانات والتفاصيل.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-800 flex items-center justify-between">
                  <span>سجل الطلبيات السابقة ({orderHistory.length}):</span>
                  <span className="text-[11px] text-slate-500 font-normal">اضغط "إعادة الطلب" لإضافتها فوراً للسلة</span>
                </h4>

                {orderHistory.map((record) => (
                  <div 
                    key={record.id}
                    className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:border-amber-300 transition-all space-y-3 p-4"
                  >
                    {/* Header of Record */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                            {record.orderNumber}
                          </span>
                          <span className="text-[11px] text-slate-500 font-medium">
                            {record.date}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-600">
                          طريقة الاستلام: {record.shippingMethod === 'pickup' ? 'استلام مقر' : `توصيل (${record.governorate || 'القاهرة'})`}
                        </div>
                      </div>

                      {/* Quick Reorder Entire Order Button */}
                      <button
                        onClick={() => handleQuickReorderAll(record)}
                        className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3.5 py-2 rounded-xl text-xs shadow-xs hover:shadow-md transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>إعادة طلب الشحنة بالكامل ({record.totalAmount} ج.م)</span>
                      </button>
                    </div>

                    {/* Items List Inside Record */}
                    <div className="space-y-2">
                      {record.items.map((item, idx) => (
                        <div 
                          key={idx}
                          className="flex items-center justify-between gap-3 p-2 rounded-xl bg-slate-50 text-xs"
                        >
                          <div className="flex-1">
                            <div className="font-bold text-slate-900">
                              {item.title}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {item.optionsSummary} (الكمية: {item.quantity})
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-mono font-bold text-slate-800">
                              {item.totalPrice} ج.م
                            </span>

                            {/* Reorder single item */}
                            <button
                              onClick={() => handleQuickReorderSingleItem(item)}
                              className="flex items-center gap-1 text-[11px] bg-white hover:bg-sky-50 text-sky-800 hover:text-sky-900 border border-slate-200 px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer"
                              title="إضافة هذا الصنف فقط للسلة"
                            >
                              <Plus className="w-3 h-3 text-sky-600" />
                              <span>إضافة هذا الصنف</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => setActiveView('cart')}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow-md transition-colors cursor-pointer"
                >
                  العودة إلى سلة الطلبات الحالية ({cartItems.length})
                </button>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Official PDF Quotation Document Modal */}
      <QuotationModal
        isOpen={isQuotationOpen}
        onClose={() => setIsQuotationOpen(false)}
        cartItems={cartItems}
        profile={profile}
        shippingMethod={shippingMethod}
        selectedGovernorate={selectedGovernorate}
        customerNotes={customerNotes}
      />
    </div>
  );
};

