import React, { useRef } from 'react';
import { CartItem, CompanyProfile } from '../types';
import { 
  X, 
  Printer, 
  Download, 
  FileText, 
  Building, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  CheckCircle2,
  Share2,
  MessageCircle
} from 'lucide-react';

interface QuotationModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  profile: CompanyProfile;
  shippingMethod: 'pickup' | 'cairo_express' | 'governorates';
  selectedGovernorate: string;
  customerNotes?: string;
}

// Convert numbers to Arabic words for professional quotation
function numberToArabicWords(num: number): string {
  const units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
  const teens = ['عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
  const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
  const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
  const thousands = ['', 'ألف', 'ألفان', 'ثلاثة آلاف', 'أربعة آلاف', 'خمسة آلاف', 'ستة آلاف', 'سبعة آلاف', 'ثمانية آلاف', 'تسعة آلاف'];

  if (num === 0) return 'صفر جنيهاً مصرياً';
  if (num < 0) return '';

  let result = '';
  const th = Math.floor(num / 1000);
  const rem1 = num % 1000;
  const h = Math.floor(rem1 / 100);
  const rem2 = rem1 % 100;

  if (th > 0) {
    if (th <= 9) result += thousands[th];
    else result += `${th} ألف`;
  }

  if (h > 0) {
    if (result) result += ' و';
    result += hundreds[h];
  }

  if (rem2 > 0) {
    if (result) result += ' و';
    if (rem2 < 10) {
      result += units[rem2];
    } else if (rem2 < 20) {
      result += teens[rem2 - 10];
    } else {
      const u = rem2 % 10;
      const t = Math.floor(rem2 / 10);
      if (u > 0) {
        result += `${units[u]} و${tens[t]}`;
      } else {
        result += tens[t];
      }
    }
  }

  return `فقط وقدره ${result} جنيهاً مصرياً لا غير`;
}

export const QuotationModal: React.FC<QuotationModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  profile,
  shippingMethod,
  selectedGovernorate,
  customerNotes,
}) => {
  const quotationRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.totalPrice, 0);

  // Buy 2 Get 1 Free discount calculation
  const promoDiscount = cartItems.reduce((acc, item) => {
    const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
    if (isOfferItem && item.quantity >= 3) {
      const freeCount = Math.floor(item.quantity / 3);
      return acc + (freeCount * item.unitPrice);
    }
    return acc;
  }, 0);

  const totalFreeUnits = cartItems.reduce((acc, item) => {
    const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
    if (isOfferItem && item.quantity >= 3) {
      return acc + Math.floor(item.quantity / 3);
    }
    return acc;
  }, 0);

  const discountedSubtotal = Math.max(0, subtotal - promoDiscount);
  const shippingCost = shippingMethod === 'pickup' ? 0 : shippingMethod === 'cairo_express' ? 50 : 70;
  const grandTotal = discountedSubtotal + shippingCost;

  const quotationNumber = `YOU-QT-${new Date().getFullYear()}-${Math.floor(1000 + (Math.abs(Math.sin(subtotal + cartItems.length)) * 9000))}`;
  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const validUntilDate = new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const handlePrintPDF = () => {
    window.print();
  };

  const handleShareWhatsAppQuotation = () => {
    let text = `*عرض سعر رسمي من شركة يونس للإعلان You Adv*\n`;
    text += `رقم العرض: ${quotationNumber}\n`;
    text += `التاريخ: ${currentDate}\n`;
    text += `العميل: ${profile.fullName || 'السادة الأفاضل'} - ${profile.companyName || ''}\n\n`;
    text += `*تفاصيل الأصناف والأسعار:*\n`;
    cartItems.forEach((item, i) => {
      const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
      const freeCount = isOfferItem && item.quantity >= 3 ? Math.floor(item.quantity / 3) : 0;
      text += `${i + 1}. ${item.title} (الكمية: ${item.quantity}${freeCount > 0 ? ` - منها ${freeCount} مجاناً` : ''}) - ${item.totalPrice} ج.م\n`;
    });

    if (promoDiscount > 0) {
      text += `\n🎁 *خصم عرض التطبيق (اشتري 2 واحصل على 3 مجاناً):* -${promoDiscount} ج.م\n`;
    }

    text += `\n*الإجمالي المطلوب شامل التوصيل:* ${grandTotal} ج.م\n`;
    text += `(${numberToArabicWords(grandTotal)})\n\n`;
    text += `للطلب وتأكيد العرض: ت/واتساب 01141350759`;

    window.open(`https://wa.me/201141350759?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/75 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      
      {/* Container Dialog */}
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto print:border-none print:shadow-none print:w-full print:max-w-none print:rounded-none">
        
        {/* Top Control Bar (Hidden on Print) */}
        <div className="print:hidden bg-slate-900 text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-['Cairo'] text-white">
                عرض سعر رسمي معتمد (PDF)
              </h3>
              <p className="text-xs text-slate-400">
                رقم المرجع: <span className="font-mono text-amber-300 font-bold">{quotationNumber}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintPDF}
              className="flex items-center gap-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-md transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة / حفظ كـ PDF</span>
            </button>

            <button
              onClick={handleShareWhatsAppQuotation}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-md transition-all cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
              <span className="hidden sm:inline">إرسال بالواتساب</span>
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Document Area */}
        <div className="max-h-[80vh] overflow-y-auto p-4 sm:p-8 bg-slate-100/60 print:max-h-none print:overflow-visible print:p-0 print:bg-white">
          
          {/* THE OFFICIAL A4 QUOTATION SHEET */}
          <div 
            ref={quotationRef}
            id="printable-quotation"
            className="w-full max-w-3xl mx-auto bg-white rounded-2xl shadow-md border border-slate-200 p-6 sm:p-10 space-y-6 text-slate-900 print:shadow-none print:border-none print:p-8 print:max-w-none print:rounded-none"
          >
            
            {/* Header: Company Letterhead */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b-2 border-slate-900">
              
              {/* Brand & Logo */}
              <div className="flex items-center gap-3.5">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-900 to-blue-950 flex items-center justify-center text-white font-black text-2xl border-2 border-amber-400 shadow-md">
                  <span className="font-['Cairo'] text-amber-300">Y</span>
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-black font-['Cairo'] text-slate-950 tracking-tight">
                    شركة يونس للإعلان
                  </h1>
                  <p className="text-xs font-bold text-sky-900 tracking-wide font-['Cairo']">
                    YOU ADV | تصميم وتنفيذ الدعاية والإعلان والمطبوعات
                  </p>
                  <p className="text-[11px] text-slate-600 font-medium">
                    س.ت: 294810 • ب.ض: 541-892-301 • سجل تجاري القاهرة
                  </p>
                </div>
              </div>

              {/* Quotation Tag & Meta */}
              <div className="sm:text-left bg-slate-50 p-3 rounded-xl border border-slate-200 min-w-[200px]">
                <div className="text-xs font-black text-sky-900 font-['Cairo'] uppercase tracking-wider mb-1">
                  عرض سعر معتمد / QUOTATION
                </div>
                <div className="text-[11px] text-slate-700 space-y-0.5">
                  <div><span className="font-bold">رقم العرض:</span> <span className="font-mono font-bold text-slate-900">{quotationNumber}</span></div>
                  <div><span className="font-bold">التاريخ:</span> {currentDate}</div>
                  <div><span className="font-bold">صالح حتى:</span> {validUntilDate}</div>
                </div>
              </div>

            </div>

            {/* Customer Information Block */}
            <div className="bg-sky-50/70 rounded-2xl p-4 sm:p-5 border border-sky-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-sky-950 flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-sky-700" />
                  <span>بيانات العميل / المؤسسة:</span>
                </div>
                <div className="text-base font-black text-slate-950 font-['Cairo']">
                  {profile.fullName || 'السادة الأفاضل'}
                </div>
                {profile.companyName && (
                  <div className="text-xs font-bold text-slate-700">
                    {profile.companyName} {profile.jobTitle ? `(${profile.jobTitle})` : ''}
                  </div>
                )}
                {profile.field && (
                  <div className="text-[11px] text-slate-500">
                    النشاط: {profile.field}
                  </div>
                )}
              </div>

              <div className="space-y-1.5 text-xs text-slate-700 sm:border-r sm:border-sky-200 sm:pr-4">
                <div className="text-[11px] font-bold text-sky-950 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-sky-700" />
                  <span>بيانات الاتصال والتسليم:</span>
                </div>
                <div><span className="font-bold">الهاتف:</span> <span className="font-mono">{profile.phone1 || '010XXXXXXXX'}</span></div>
                {profile.phone2 && <div><span className="font-bold">هاتف إضافي:</span> <span className="font-mono">{profile.phone2}</span></div>}
                <div><span className="font-bold">العنوان/المحافظة:</span> {profile.address || selectedGovernorate} ({selectedGovernorate})</div>
                {(profile.commercialReg || profile.taxCard) && (
                  <div className="text-[10px] text-slate-500">
                    س.ت: {profile.commercialReg || '---'} | ب.ض: {profile.taxCard || '---'}
                  </div>
                )}
              </div>
            </div>

            {/* Products & Items Table */}
            <div className="space-y-2">
              <h2 className="text-xs font-bold text-slate-800 font-['Cairo'] flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-sky-600" />
                <span>بيان الأصناف والكميات والمواصفات الفنية:</span>
              </h2>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-900 text-white font-bold font-['Cairo']">
                    <tr>
                      <th className="p-3 w-8 text-center">#</th>
                      <th className="p-3">الصنف / المنتج</th>
                      <th className="p-3">المواصفات والخامات</th>
                      <th className="p-3 text-center w-16">الكمية</th>
                      <th className="p-3 text-left w-24">سعر الوحدة</th>
                      <th className="p-3 text-left w-24">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {cartItems.map((item, idx) => {
                      const isOfferItem = item.category === 'youadv_exclusive' || item.buy2Get1Free;
                      const freeCount = isOfferItem && item.quantity >= 3 ? Math.floor(item.quantity / 3) : 0;

                      return (
                        <tr key={item.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}>
                          <td className="p-3 text-center font-bold text-slate-500">{idx + 1}</td>
                          <td className="p-3 font-bold text-slate-900 font-['Cairo']">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span>{item.title}</span>
                              {isOfferItem && (
                                <span className="text-[9px] bg-amber-100 text-amber-900 font-bold px-1.5 py-0.2 rounded border border-amber-300 print:border print:text-black">
                                  عرض 2+1
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3 text-slate-600 text-[11px]">
                            {item.optionsSummary}
                            {freeCount > 0 && (
                              <div className="text-[10px] text-emerald-700 font-bold mt-0.5">
                                ✓ مشمول بالعرض: تم احتساب {freeCount} قطعة مجانية
                              </div>
                            )}
                          </td>
                          <td className="p-3 text-center font-mono font-bold text-slate-900">
                            {item.quantity}
                          </td>
                          <td className="p-3 text-left font-mono font-bold text-slate-800">
                            {item.unitPrice} ج.م
                          </td>
                          <td className="p-3 text-left font-mono font-black text-sky-950">
                            {freeCount > 0 ? (
                              <div>
                                <span>{item.totalPrice - (freeCount * item.unitPrice)} ج.م</span>
                                <span className="block text-[9px] text-slate-400 line-through">{item.totalPrice} ج.م</span>
                              </div>
                            ) : (
                              <span>{item.totalPrice} ج.م</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Financial Summary & Total */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start pt-2">
              
              {/* Spelled-out Total & Notes */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="font-bold text-slate-800 font-['Cairo']">
                  فقط وقدره كتابةً:
                </div>
                <div className="text-xs font-black text-sky-950 bg-white p-2.5 rounded-lg border border-slate-200">
                  {numberToArabicWords(grandTotal)}
                </div>
                {promoDiscount > 0 && (
                  <div className="text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                    <span className="font-bold">ملاحظة العرض الترويجي:</span> العرض ساري وحصري داخل التطبيق (اشتري 2 واحصل على 3 مجاناً).
                  </div>
                )}
                {customerNotes && (
                  <div className="text-[11px] text-slate-600 pt-1">
                    <span className="font-bold text-slate-800">ملاحظات العميل:</span> {customerNotes}
                  </div>
                )}
              </div>

              {/* Calculation Box */}
              <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>إجمالي الأصناف قبل الخصم:</span>
                  <span className="font-mono font-bold text-white">{subtotal} ج.م</span>
                </div>

                {promoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-300 font-bold bg-emerald-950/80 p-1.5 rounded-lg border border-emerald-700/50">
                    <span>خصم عرض التطبيق (2+1 مجاناً):</span>
                    <span className="font-mono text-emerald-300">-{promoDiscount} ج.م ({totalFreeUnits} مجاناً)</span>
                  </div>
                )}

                <div className="flex justify-between text-slate-300">
                  <span>خدمة الشحن والتوصيل ({shippingMethod === 'pickup' ? 'استلام مقر' : selectedGovernorate}):</span>
                  <span className="font-mono font-bold text-white">{shippingCost} ج.م</span>
                </div>
                <div className="h-px bg-slate-700 my-1"></div>
                <div className="flex justify-between items-center text-sm font-black pt-1">
                  <span className="text-amber-400 font-['Cairo']">الإجمالي الصافي المستحق:</span>
                  <span className="text-lg font-black text-amber-300 font-mono">
                    {grandTotal} <span className="text-xs font-bold text-white">ج.م</span>
                  </span>
                </div>
              </div>

            </div>

            {/* Terms and Conditions */}
            <div className="bg-amber-50/50 rounded-xl p-4 border border-amber-200/70 text-[11px] text-slate-700 space-y-1.5">
              <div className="font-bold text-amber-950 font-['Cairo'] text-xs flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-700" />
                <span>الشروط والأحكام والضمان:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 pr-1 text-slate-600">
                <li>الأسعار المعروضة معتمدة لعام 2026 وسارية لمدة 15 يوماً من تاريخ إصدار العرض.</li>
                <li>مدة التجهيز والتنفيذ: من 3 ساعات إلى 48 ساعة حسب نوع المنتجات وكمياتها.</li>
                <li>يتم إرسال بروفة رقمية للتصميم قبل البدء الفعلي في الحفر أو الطباعة للاعتماد النهائي.</li>
                <li>طرق السداد المعتمدة: نقداً بالمقر، تحويل بنكي / إنستاباي، أو فودافون كاش على الرقم <span className="font-mono font-bold text-slate-900">01141350759</span>.</li>
              </ul>
            </div>

            {/* Signatures & Official Stamp */}
            <div className="pt-6 border-t border-slate-200 grid grid-cols-2 gap-6 items-end">
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-800 font-['Cairo']">
                  اعتماد العميل / المستلم:
                </div>
                <div className="text-[11px] text-slate-500">
                  الاسم والتوقيع: ................................
                </div>
                <div className="text-[11px] text-slate-500">
                  التاريخ: ................................
                </div>
              </div>

              <div className="text-left space-y-1">
                <div className="text-xs font-bold text-sky-950 font-['Cairo']">
                  عن شركة يونس للإعلان You Adv
                </div>
                <div className="text-[11px] font-bold text-slate-600">
                  إدارة المبيعات والتنفيذ والمقايسات
                </div>
                <div className="inline-block border-2 border-sky-800 border-dashed rounded-xl px-3 py-1 text-[10px] font-bold text-sky-900 bg-sky-50 mt-1">
                  معتمد ومختوم إلكترونياً • You Adv 2026
                </div>
              </div>
            </div>

            {/* Quotation Footer */}
            <div className="text-center text-[10px] text-slate-400 pt-2 border-t border-slate-100">
              المقر الرئيسي: 12 شارع محمد علي - الموسكي - العتبة - القاهرة | ت/واتساب: 01141350759 | info@youadv.com
            </div>

          </div>

        </div>

        {/* Modal Footer Controls (Hidden in Print) */}
        <div className="print:hidden bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-sky-600" />
            <span>يمكنك حفظ هذا العرض كملف PDF رسمي أو طباعته على ورق A4</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handlePrintPDF}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-sky-700 hover:bg-sky-800 text-white font-bold py-2.5 px-5 rounded-xl text-xs shadow-md transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة / حفظ PDF</span>
            </button>

            <button
              onClick={onClose}
              className="flex-1 sm:flex-none bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2.5 px-4 rounded-xl text-xs transition-colors cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
