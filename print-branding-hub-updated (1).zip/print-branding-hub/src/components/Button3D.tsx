import React from "react";

type Variant = "navy" | "gold" | "blue" | "pink" | "mint" | "whatsapp" | "ghost";

interface Button3DProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  as?: "button";
}

interface Link3DProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: Variant;
  as: "a";
}

const VARIANT_STYLES: Record<Variant, string> = {
  // bg / text / shadow(pressed edge) / hover-bg
  navy: "bg-brand-navy text-white shadow-[0_6px_0_0_#0A1226] hover:bg-[#1c2c4d]",
  gold: "bg-brand-gold text-white shadow-[0_6px_0_0_#8F721C] hover:bg-[#d6ac2c]",
  blue: "bg-brand-blue text-brand-navy shadow-[0_6px_0_0_#4C7FC7] hover:bg-[#b9d4f8]",
  pink: "bg-brand-pink text-brand-navy shadow-[0_6px_0_0_#D46A82] hover:bg-[#f8b8c1]",
  mint: "bg-brand-mint text-brand-navy shadow-[0_6px_0_0_#2F9C74] hover:bg-[#a3e3c8]",
  whatsapp: "bg-[#25D366] text-white shadow-[0_6px_0_0_#128C3E] hover:bg-[#20bd5a]",
  ghost:
    "bg-white text-brand-navy border-2 border-brand-border shadow-[0_6px_0_0_#E2E8F5] hover:bg-brand-surface-alt",
};

const BASE =
  "inline-flex items-center justify-center gap-2 font-black rounded-2xl transition-all duration-150 active:translate-y-[6px] active:shadow-none hover:-translate-y-0.5 select-none";

/**
 * A button styled with a solid "pressed" 3D edge, matching the playful
 * pastel identity of the YouAdv 2026 catalog. Works as either a <button>
 * (default) or an <a> tag (pass as="a" + href) so it can be used for
 * in-page anchors, external links, or real form submits alike.
 */
export default function Button3D(props: Button3DProps | Link3DProps) {
  const { variant = "navy", className = "", ...rest } = props as Button3DProps & { as?: string };
  const classes = `${BASE} ${VARIANT_STYLES[variant]} ${className}`;

  if (props.as === "a") {
    const { as, variant: _v, className: _c, ...anchorProps } = props as Link3DProps;
    return <a className={classes} {...anchorProps} />;
  }

  const { as, variant: _v, className: _c, ...buttonProps } = props as Button3DProps & { as?: string };
  return <button className={classes} {...buttonProps} />;
}
