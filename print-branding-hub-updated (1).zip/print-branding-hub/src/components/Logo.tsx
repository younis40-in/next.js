"use client";

import React, { useState } from "react";
import Link from "next/link";

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

export default function Logo({ size = "md", className = "" }: LogoProps) {
  const [imageError, setImageError] = useState(false);

  const sizeClasses = {
    sm: "h-12 w-auto",
    md: "h-20 w-auto",
    lg: "h-32 w-auto",
    xl: "h-44 w-auto",
  };

  return (
    <Link href="/" className={`inline-flex items-center justify-center select-none group transition-transform hover:scale-105 ${className}`}>
      {!imageError ? (
        <div className="relative flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-r from-brand-blue/40 via-brand-pink/40 to-brand-yellow/40 blur-2xl rounded-full opacity-80 group-hover:opacity-100 transition-opacity" />
          <img
            src="/logo.png"
            alt="YouAdv - YOU WILL CUSTOMIZE THE WORLD"
            onError={() => setImageError(true)}
            className={`${sizeClasses[size]} object-contain relative z-10 drop-shadow-[0_8px_24px_rgba(76,127,199,0.35)]`}
          />
        </div>
      ) : (
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-brand-navy to-brand-blue-dark p-0.5 shadow-xl flex items-center justify-center">
            <div className="w-full h-full bg-brand-navy rounded-[14px] flex items-center justify-center font-black text-brand-gold text-xl">
              YA
            </div>
          </div>
          <div className="flex flex-col text-right">
            <span className="text-xl font-black text-brand-navy leading-none">You<span className="text-brand-gold-dark">Adv</span></span>
            <span className="text-xs font-bold text-brand-blue-dark mt-1">يُونُسْ لِلإعْلاَن</span>
          </div>
        </div>
      )}
    </Link>
  );
}
