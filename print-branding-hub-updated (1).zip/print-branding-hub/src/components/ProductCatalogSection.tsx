"use client";

import React, { useState } from "react";
import { finalCatalog, CatalogProduct } from "@/data/catalog";
import OrderModal, { OrderDetails } from "@/components/OrderModal";
import Button3D from "@/components/Button3D";
import { Search, Sparkles, ShoppingBag, CheckCircle2, Stamp, CreditCard, FileText, Award, Layers, Tag } from "lucide-react";

export default function ProductCatalogSection() {
  const [selectedCategory, setSelectedCategory] = useState<string>("الكل");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<OrderDetails | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const categories = ["الكل", "أختام", "كروت شخصية", "دفاتر فواتير", "فلايرات", "نيم تاج", "دروع تكريم"];

  const filteredProducts = finalCatalog.filter((item) => {
    const matchesCategory = selectedCategory === "الكل" || item.category === selectedCategory;
    const matchesSearch = item.title.includes(searchQuery) || item.description.includes(searchQuery) || item.price.includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  const handleQuickOrder = (product: CatalogProduct) => {
    setSelectedOrder({
      title: product.title,
      price: product.price,
      size: product.size,
      category: product.category,
    });
    setIsModalOpen(true);
  };

  return (
    <section id="pricing-catalog" className="scroll-mt-28">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-brand-border gap-4 text-right">
        <div>
          <span className="text-brand-pink-dark font-black text-xs uppercase tracking-widest bg-brand-pink/40 px-3 py-1 rounded-full border border-brand-pink">
            معرض المنتجات والأسعار الرسمية
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-brand-navy mt-2">
            جميع منتجات YouAdv بالأسعار المعتمدة
          </h2>
        </div>
      </div>

      <div className="bg-white p-4 sm:p-6 rounded-3xl border border-brand-border shadow-[0_5px_0_0_#E2E8F5] mb-8 space-y-4">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-brand-muted absolute right-3.5 top-3.5" />
            <input
              type="text"
              placeholder="ابحث بالاسم أو السعر..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-brand-surface-alt border border-brand-border rounded-2xl pr-10 pl-4 py-2.5 text-xs text-brand-navy outline-none focus:border-brand-blue-dark"
            />
          </div>

          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                  selectedCategory === cat
                    ? "bg-brand-navy text-white shadow-[0_3px_0_0_#0A1226]"
                    : "bg-brand-surface-alt border border-brand-border text-brand-body hover:text-brand-navy"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="bg-white rounded-3xl border border-brand-border p-5 flex flex-col justify-between hover:border-brand-blue-dark/50 transition shadow-[0_5px_0_0_#E2E8F5] text-right"
          >
            <div>
              <div className="flex justify-between items-start mb-2.5">
                <span className="text-[10px] font-bold bg-brand-blue/50 text-brand-blue-dark border border-brand-blue px-2.5 py-0.5 rounded-lg">
                  {product.category}
                </span>
                <span className="text-sm font-black text-brand-pink-dark font-mono bg-brand-pink/40 px-2.5 py-0.5 rounded-lg border border-brand-pink">
                  {product.price}
                </span>
              </div>

              <h3 className="font-extrabold text-sm text-brand-navy mb-1.5 leading-snug">
                {product.title}
              </h3>
              <p className="text-xs text-brand-muted leading-relaxed mb-3">
                {product.description}
              </p>
            </div>

            <div className="pt-3 border-t border-brand-border flex items-center justify-between gap-2 mt-2">
              <a href="#studio" className="text-xs font-bold text-brand-blue-dark hover:text-brand-navy flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>تخصيص 3D</span>
              </a>

              <Button3D onClick={() => handleQuickOrder(product)} variant="gold" className="text-xs px-4 py-2">
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>طلب سريع</span>
              </Button3D>
            </div>
          </div>
        ))}
      </div>

      <OrderModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} order={selectedOrder} />
    </section>
  );
}
