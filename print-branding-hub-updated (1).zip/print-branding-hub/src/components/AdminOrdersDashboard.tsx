"use client";

import React, { useState, useEffect } from 'react';
import { CustomerOrder, OrderStatus } from '../types';
import { getStoredOrders, saveStoredOrders, updateOrderStatus } from '../data/ordersStore';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  Phone, 
  MessageCircle, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  Printer, 
  Eye, 
  Edit3, 
  Image as ImageIcon, 
  Layers, 
  Package, 
  Truck, 
  FileText, 
  RefreshCw, 
  Plus, 
  X,
  AlertCircle,
  ExternalLink,
  ChevronDown
} from 'lucide-react';

interface AdminOrdersDashboardProps {
  onOpenCustomerTracker?: (orderNumber: string) => void;
}

const SAMPLE_STAGE_PHOTOS = [
  { label: 'بروفة تصميم متجهات Vector', url: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=600&q=80' },
  { label: 'ماكينة حفر الليزر والكاوتشوك', url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80' },
  { label: 'فحص البصمة وجودة الحبر', url: 'https://images.unsplash.com/photo-1607344645866-009c320b5ab8?auto=format&fit=crop&w=600&q=80' },
  { label: 'تغليف علب You Adv الفاخرة', url: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=600&q=80' },
  { label: 'حفر خشب الأرو واللوحات النحاسية', url: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=600&q=80' },
  { label: 'طباعة كروت UV وفوال ذهبي', url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' },
];

export const AdminOrdersDashboard: React.FC<AdminOrdersDashboardProps> = ({ onOpenCustomerTracker }) => {
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<CustomerOrder | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingStatus, setEditingStatus] = useState<OrderStatus>('received');
  const [editingNotes, setEditingNotes] = useState('');
  const [editingPhotoUrl, setEditingPhotoUrl] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = () => {
    const list = getStoredOrders();
    setOrders(list);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const filteredOrders = orders.filter((ord) => {
    const matchesSearch =
      ord.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ord.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ord.customerPhone.includes(searchTerm) ||
      (ord.companyName && ord.companyName.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesFilter = statusFilter === 'all' || ord.status === statusFilter;

    return matchesSearch && matchesFilter;
  });

  const handleOpenEdit = (order: CustomerOrder) => {
    setSelectedOrder(order);
    setEditingStatus(order.status);
    setEditingNotes(order.adminNotes || '');
    setEditingPhotoUrl(order.customProofImage || '');
    setIsEditModalOpen(true);
  };

  const handleSaveStatusUpdate = () => {
    if (!selectedOrder) return;
    const updatedList = updateOrderStatus(
      selectedOrder.id,
      editingStatus,
      editingNotes,
      editingPhotoUrl || undefined
    );
    setOrders(updatedList);
    setIsEditModalOpen(false);
    showToast(`تم تحديث حالة الطلب (${selectedOrder.orderNumber}) بنجاح`);
  };

  const handleSendWhatsAppUpdate = (order: CustomerOrder) => {
    const phone = order.customerPhone.replace(/[^0-9]/g, '');
    const cleanPhone = phone.startsWith('0') ? '20' + phone.substring(1) : phone.startsWith('2') ? phone : '20' + phone;

    let message = `مرحباً أ/ *${order.customerName}*، تحياتنا من إدارة *يونس للإعلان You Adv* 🌟\n\n`;
    message += `نود إعلامكم بتحديث حالة طلبكم رقم: *${order.orderNumber}*\n`;
    message += `📌 *المرحلة الحالية:* ${order.statusArabic}\n`;
    if (order.adminNotes) {
      message += `📝 *ملاحظات قسم التنفيذ:* ${order.adminNotes}\n`;
    }
    message += `\n🔍 يمكنك متابعة صور بروفة ومراحل تصنيع طلبك لحظة بلحظة عبر الرابط المباشر بالتطبيق.\n`;
    message += `شكراً لاختياركم You Adv 2026.`;

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
  };

  // Stats
  const totalRevenue = orders.reduce((sum, o) => sum + o.grandTotal, 0);
  const activeInProduction = orders.filter((o) => ['designing', 'engraving', 'quality_check'].includes(o.status)).length;
  const readyToShip = orders.filter((o) => o.status === 'out_for_delivery').length;

  return (
    <div className="space-y-6">
      
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white border border-cyan-400/50 px-4 py-2 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-sky-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 text-right">
            <div className="inline-flex items-center gap-2 bg-sky-500/20 text-sky-300 border border-sky-500/30 px-3 py-1 rounded-full text-xs font-bold">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>لوحة تحكم قسم المبيعات والتشغيل • You Adv Admin</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-['Cairo'] text-white">
              إدارة الطلبات المباشرة ومتابعة مراحل التنفيذ
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              تحديث حالات التصنيع، رفع صور البروفة وماكينة الليزر للعميل، وإرسال إشعارات الواتساب بضغطة واحدة.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-2.5 sm:gap-4 shrink-0">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <span className="text-[10px] text-slate-400 font-bold block">إجمالي الطلبات</span>
              <span className="text-lg sm:text-2xl font-black text-white font-mono">{orders.length}</span>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <span className="text-[10px] text-amber-300 font-bold block">قيد التنفيذ بالمطبعة</span>
              <span className="text-lg sm:text-2xl font-black text-amber-400 font-mono">{activeInProduction}</span>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <span className="text-[10px] text-emerald-300 font-bold block">إجمالي المقايسات</span>
              <span className="text-sm sm:text-lg font-black text-emerald-400 font-mono">{totalRevenue} ج.م</span>
            </div>
          </div>
        </div>
      </div>

      {/* Controls Bar: Search & Filter Tabs */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث برقم الطلب (YOU-ORD...) أو اسم العميل أو الهاتف..."
              className="w-full pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500 focus:bg-white transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                مسح
              </button>
            )}
          </div>

          {/* Refresh Button */}
          <button
            onClick={loadOrders}
            className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>تحديث القائمة</span>
          </button>
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          {[
            { id: 'all', label: 'كافة الطلبات', count: orders.length },
            { id: 'received', label: '📥 جديد / مستلم', count: orders.filter((o) => o.status === 'received').length },
            { id: 'designing', label: '🎨 البروفة الرقمية', count: orders.filter((o) => o.status === 'designing').length },
            { id: 'engraving', label: '⚡ الحفر بالليزر والطباعة', count: orders.filter((o) => o.status === 'engraving').length },
            { id: 'quality_check', label: '🔍 فحص الجودة', count: orders.filter((o) => o.status === 'quality_check').length },
            { id: 'out_for_delivery', label: '🚚 الشحن والتسليم', count: orders.filter((o) => o.status === 'out_for_delivery').length },
            { id: 'delivered', label: '✅ تم التسليم', count: orders.filter((o) => o.status === 'delivered').length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                statusFilter === tab.id
                  ? 'bg-sky-900 text-white shadow-xs'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                statusFilter === tab.id ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-3">
            <Package className="w-12 h-12 text-slate-300 mx-auto" />
            <h3 className="text-base font-bold text-slate-800">لا توجد طلبات مطابقة للبحث</h3>
            <p className="text-xs text-slate-500">جرب تغيير كلمات البحث أو الفلتر المختار</p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const currentStageObj = order.stages.find((s) => s.current) || order.stages[order.stages.length - 1];

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all overflow-hidden"
              >
                {/* Card Header */}
                <div className="p-4 sm:p-5 bg-slate-50/70 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-right">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono font-black text-xs sm:text-sm text-sky-950 bg-sky-100 px-2.5 py-0.5 rounded-lg border border-sky-300">
                        {order.orderNumber}
                      </span>
                      <span className="text-[11px] font-bold text-slate-500">
                        {order.createdAt}
                      </span>
                      <span className="text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-md">
                        {order.shippingMethod === 'pickup' ? 'استلام من المقر' : `توصيل (${order.governorate})`}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <h4 className="font-bold text-sm text-slate-900 font-['Cairo']">
                        {order.customerName}
                      </h4>
                      {order.companyName && (
                        <span className="text-xs text-slate-600">
                          • {order.companyName}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions & Price */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                    <div className="text-right">
                      <span className="text-[11px] text-slate-500 block">الإجمالي:</span>
                      <span className="text-base sm:text-lg font-black text-sky-900 font-mono">
                        {order.grandTotal} ج.م
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleSendWhatsAppUpdate(order)}
                        className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                        title="إرسال إشعار واتساب للعميل"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-white" />
                        <span className="hidden sm:inline">واتساب العميل</span>
                      </button>

                      {onOpenCustomerTracker && (
                        <button
                          onClick={() => onOpenCustomerTracker(order.orderNumber)}
                          className="flex items-center gap-1 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 px-3 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                          title="عرض صفحة تتبع العميل"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">معاينة العميل</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleOpenEdit(order)}
                        className="flex items-center gap-1 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>تحديث المرحلة</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Card Body: Items & Current Stage */}
                <div className="p-4 sm:p-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                  
                  {/* Ordered Items List (7 cols) */}
                  <div className="md:col-span-7 space-y-2.5 text-right">
                    <span className="text-[11px] font-bold text-slate-500 block">
                      المنتجات المخصصة للطلب ({order.items.length}):
                    </span>
                    <div className="space-y-2">
                      {order.items.map((item, idx) => (
                        <div
                          key={item.id || idx}
                          className="bg-slate-50 border border-slate-200/80 rounded-xl p-2.5 text-xs flex items-start justify-between gap-3"
                        >
                          <div className="space-y-0.5">
                            <span className="font-bold text-slate-900 block">
                              {item.title} × {item.quantity}
                            </span>
                            <p className="text-[11px] text-slate-600 leading-relaxed">
                              {item.optionsSummary}
                            </p>
                            {item.customizationDetails && Object.keys(item.customizationDetails).length > 0 && (
                              <div className="text-[10px] text-sky-800 font-semibold bg-white p-1 rounded border border-slate-200 mt-1">
                                {item.customizationDetails.stampLine1 && <span>السطر 1: {item.customizationDetails.stampLine1} | </span>}
                                {item.customizationDetails.inkColor && <span>الحبر: {item.customizationDetails.inkColor}</span>}
                              </div>
                            )}
                          </div>
                          <span className="font-black font-mono text-slate-800 shrink-0">
                            {item.totalPrice} ج.م
                          </span>
                        </div>
                      ))}
                    </div>

                    {order.customerNotes && (
                      <div className="text-[11px] bg-amber-50 border border-amber-200 text-amber-900 p-2 rounded-xl">
                        <strong>ملاحظة العميل:</strong> {order.customerNotes}
                      </div>
                    )}
                  </div>

                  {/* Stage Status & Proof Photo Preview (5 cols) */}
                  <div className="md:col-span-5 bg-slate-900 text-white rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-cyan-300 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>المرحلة الحالية المعروضة للعميل:</span>
                      </span>
                      <span className="bg-sky-500/20 text-sky-300 text-[10px] px-2 py-0.5 rounded-full border border-sky-400/30">
                        {order.statusArabic}
                      </span>
                    </div>

                    {/* Stage Photo */}
                    {currentStageObj?.photoUrl && (
                      <div className="relative rounded-xl overflow-hidden border border-white/10 group h-28 bg-black/40">
                        <img
                          src={currentStageObj.photoUrl}
                          alt={currentStageObj.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                          <span className="text-[10px] font-bold text-slate-200 truncate">
                            {currentStageObj.photoCaption || currentStageObj.title}
                          </span>
                        </div>
                      </div>
                    )}

                    {order.adminNotes && (
                      <p className="text-[11px] text-slate-300 bg-white/5 p-2 rounded-xl border border-white/10 leading-relaxed">
                        <span className="text-amber-300 font-bold">ملاحظة الورشة: </span>
                        {order.adminNotes}
                      </p>
                    )}

                    {/* Visual Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                        <span>التقدم:</span>
                        <span>{order.stages.filter((s) => s.completed).length} / {order.stages.length} مراحل</span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-sky-400 to-emerald-400 h-full rounded-full transition-all"
                          style={{
                            width: `${(order.stages.filter((s) => s.completed).length / order.stages.length) * 100}%`,
                          }}
                        ></div>
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            );
          })
        )}
      </div>

      {/* Edit Stage Modal */}
      {isEditModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-right">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-sky-950 to-blue-900 text-white p-4 sm:p-5 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base font-['Cairo'] flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-cyan-300" />
                  <span>تحديث مرحلة تصنيع الطلب ({selectedOrder.orderNumber})</span>
                </h3>
                <p className="text-xs text-sky-200 mt-0.5">
                  العميل: {selectedOrder.customerName} • {selectedOrder.customerPhone}
                </p>
              </div>

              <button
                onClick={() => setIsEditModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
              
              {/* Select Status */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5">
                  حدد مرحلة التصنيع الحالية:
                </label>
                <div className="space-y-1.5">
                  {[
                    { key: 'received', title: '1. استلام الطلب وتأكيد البيانات', desc: 'تم تدقيق المقايسة والبيانات' },
                    { key: 'designing', title: '2. إعداد واعتماد البروفة الرقمية', desc: 'تجهيز ملف الـ Vector والخطوط' },
                    { key: 'engraving', title: '3. الحفر بالليزر والطباعة المباشرة', desc: 'الماكينات تعمل على تجهيز المنتج' },
                    { key: 'quality_check', title: '4. فحص الجودة وتجربة البصمة', desc: 'اختبار وضوح الحبر والتشطيب' },
                    { key: 'out_for_delivery', title: '5. التغليف والشحن للتسليم', desc: 'مع مندوب التوصيل أو جاهز بالمقر' },
                    { key: 'delivered', title: '6. تم التسليم للعميل بنجاح', desc: 'اكتملت دورة الطلب' },
                  ].map((st) => (
                    <button
                      key={st.key}
                      type="button"
                      onClick={() => setEditingStatus(st.key as OrderStatus)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-xs text-right transition-all cursor-pointer ${
                        editingStatus === st.key
                          ? 'border-sky-600 bg-sky-50 text-sky-950 font-black ring-1 ring-sky-400'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                          editingStatus === st.key ? 'border-sky-600 bg-sky-600' : 'border-slate-300'
                        }`}>
                          {editingStatus === st.key && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                        </div>
                        <span className="font-bold">{st.title}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{st.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Photo Selector for this stage */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5">
                  اختيار صورة بروفة / مرحلة التصنيع (تظهر مباشرة في صفحة تتبع العميل):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SAMPLE_STAGE_PHOTOS.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setEditingPhotoUrl(sample.url)}
                      className={`relative rounded-xl overflow-hidden border text-right transition-all cursor-pointer h-20 group ${
                        editingPhotoUrl === sample.url ? 'ring-2 ring-sky-600 border-sky-600' : 'border-slate-200'
                      }`}
                    >
                      <img
                        src={sample.url}
                        alt={sample.label}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/50 p-1.5 flex items-end">
                        <span className="text-[9px] font-bold text-white leading-tight">
                          {sample.label}
                        </span>
                      </div>
                      {editingPhotoUrl === sample.url && (
                        <div className="absolute top-1 right-1 bg-sky-600 text-white rounded-full p-0.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Admin Note */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  ملاحظة الورشة / رسالة تظهر للعميل بصفحة التتبع:
                </label>
                <textarea
                  rows={2}
                  value={editingNotes}
                  onChange={(e) => setEditingNotes(e.target.value)}
                  placeholder="مثال: تم الانتهاء من الحفر بماكينة تراكْس الأصلية وجاري تجميع وسادة الحبر..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 outline-none focus:border-sky-500"
                ></textarea>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={handleSaveStatusUpdate}
                  className="flex-1 py-3 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-black text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>حفظ وتطبيق المرحلة للعميل</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
