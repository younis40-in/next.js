"use client";

import React, { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Sparkles, Loader2 } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const WELCOME_MESSAGE: Message = {
  role: "assistant",
  content: "أهلاً بيك في YouAdv! 👋 أنا مساعدك الذكي، تقدر تسألني عن الأسعار والمنتجات والشحن أو أي استفسار. إزاي أقدر أساعدك؟",
};

export default function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isOpen]);

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;

    const newMessages: Message[] = [...messages, { role: "user", content: trimmed }];
    setMessages(newMessages);
    setInput("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newMessages.slice(-10) }),
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.reply || "معلش، حصل خطأ. جرب تاني." },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "معلش، فيه مشكلة في الاتصال. جرب تاني بعد شوية." },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label={isOpen ? "إغلاق الشات" : "افتح الشات"}
        className="fixed bottom-5 left-5 z-[60] w-14 h-14 rounded-full bg-brand-navy hover:bg-[#1c2c4d] shadow-2xl shadow-brand-navy/30 flex items-center justify-center text-white transition-all hover:scale-110 border-2 border-brand-gold/50"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 left-5 z-[60] w-[92vw] max-w-sm h-[70vh] max-h-[520px] bg-white border-2 border-brand-border rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-fadeIn">
          {/* Header */}
          <div className="bg-brand-navy px-4 py-3.5 flex items-center gap-2.5 border-b border-brand-gold/30">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-white font-black text-sm leading-none">مساعد YouAdv الذكي</p>
              <p className="text-brand-blue text-[10px] mt-1">بيرد عليك فورًا 24/7</p>
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 text-right">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-start" : "justify-end"}`}>
                <div
                  className={`max-w-[85%] text-xs leading-relaxed px-3.5 py-2.5 rounded-2xl ${
                    m.role === "user"
                      ? "bg-brand-surface-alt text-brand-navy rounded-bl-sm"
                      : "bg-brand-navy text-white rounded-br-sm"
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-end">
                <div className="bg-brand-navy text-white px-3.5 py-2.5 rounded-2xl rounded-br-sm flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span className="text-[11px]">بيكتب...</span>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="p-3 border-t border-brand-border bg-brand-surface-alt flex items-center gap-2">
            <button
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              className="w-9 h-9 shrink-0 rounded-xl bg-brand-gold disabled:opacity-40 flex items-center justify-center text-white transition"
            >
              <Send className="w-4 h-4 -rotate-45" />
            </button>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب سؤالك هنا..."
              className="flex-1 bg-white border border-brand-border rounded-xl px-3.5 py-2.5 text-xs text-brand-navy outline-none focus:border-brand-blue-dark transition"
            />
          </div>
        </div>
      )}
    </>
  );
}
