"use client";

import React, { useState } from "react";
import { useCart } from "@/context/CartContext";
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Send, 
  User, 
  Phone, 
  MapPin, 
  Truck,
  Sparkles
} from "lucide-react";
import Button3D from "@/components/Button3D";

export default function CartDrawer() {
  const { cart, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice, isCartOpen, setIsCartOpen } = useCart();
  
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [shippingSpeed, setShippingSpeed] = useState("سريع (خلال 24 ساعة)");
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  if (!isCartOpen) return null;

  const handleSendFullOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName || !phone) {
      alert("يرجى إدخال الاسم ورقم الهاتف.");
      return;
    }

    const itemsSummary = cart.map((item, idx) => 
      `${idx + 1}. *${item.title}* × ${item.quantity} = ${item.priceNum * item.quantity} ج.م`
    ).join("\n");

    const message = `*طلب سلة مشتريات جديدة من YouAdv* 🛒
----------------------------------------
📦 *المنتجات المطلوبة:*
${itemsSummary}

💰 *الإجمالي الكلي:* ${totalPrice} ج.م
📊 *عدد العناصر:* ${totalItems}

👤 *بيانات العميل والتوصيل:*
- *الاسم:* ${customerName}
- *الهاتف:* ${phone}
- *العنوان:* ${address || "سيتم التحديد في المحادثة"}
- *خيار الشحن:* ${shippingSpeed}
----------------------------------------
_تم إرسال الطلب عبر سلة YouAdv Web Hub_`;

    const whatsappUrl = `https://wa.me/201141350759?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
    clearCart();
    setIsCartOpen(false);
    setIsCheckingOut(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-brand-navy-dark/60 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-md bg-white text-brand-navy border-r border-brand-border h-full flex flex-col justify-between shadow-2xl animate-in slide-in-from-left duration-300">
        
        {/* Header */}
        <div className="p-6 border-b border-brand-border flex items-center justify-between">
          <button onClick={() => setIsCartOpen(false)} className="p-2 rounded-xl bg-brand-surface-alt text-brand-muted hover:text-brand-navy">
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 text-right">
            <div>
              <h3 className="font-black text-lg text-brand-navy">سلة المشتريات</h3>
              <span className="text-xs text-brand-blue-dark font-mono">{totalItems} عناصر</span>
            </div>
            <div className="p-2.5 rounded-xl bg-brand-pink/40 text-brand-pink-dark">
              <ShoppingBag className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Cart Items List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-right">
          {cart.length === 0 ? (
            <div className="text-center py-20 text-brand-muted">
              <ShoppingBag className="w-16 h-16 mx-auto mb-3 opacity-30 text-brand-pink-dark" />
              <p className="font-bold text-sm text-brand-body">السلة فارغة حالياً</p>
              <span className="text-xs">تصفح المعرض وأضف المنتجات لسلتك</span>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="bg-brand-surface-alt p-4 rounded-2xl border border-brand-border flex items-center justify-between gap-3">
                <button onClick={() => removeFromCart(item.id)} className="text-brand-muted hover:text-brand-pink-dark p-1">
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2 bg-white px-2 py-1 rounded-xl border border-brand-border">
                  <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="text-brand-muted hover:text-brand-navy">
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-xs font-mono font-bold w-4 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="text-brand-muted hover:text-brand-navy">
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 text-right">
                  <h4 className="font-bold text-xs text-brand-navy truncate">{item.title}</h4>
                  <span className="text-[11px] font-mono text-brand-pink-dark font-bold block">{item.priceNum * item.quantity} ج.م</span>
                </div>
              </div>
            ))
          )}

          {/* Checkout Info Form */}
          {cart.length > 0 && isCheckingOut && (
            <form onSubmit={handleSendFullOrder} id="cart-form" className="space-y-3 pt-4 border-t border-brand-border text-right">
              <div>
                <label className="text-[11px] font-bold text-brand-body block mb-1">الاسم بالكامل:</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="محمد حسني"
                  className="w-full bg-brand-surface-alt border border-brand-border rounded-xl px-3 py-2 text-xs text-brand-navy focus:outline-none focus:border-brand-blue-dark"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-brand-body block mb-1">رقم الهاتف / واتساب:</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01141350759"
                  className="w-full bg-brand-surface-alt border border-brand-border rounded-xl px-3 py-2 text-xs text-brand-navy focus:outline-none focus:border-brand-blue-dark font-mono text-right"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-brand-body block mb-1">العنوان بالتفصيل:</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="القاهرة - العتبة أو الجيزة"
                  className="w-full bg-brand-surface-alt border border-brand-border rounded-xl px-3 py-2 text-xs text-brand-navy focus:outline-none focus:border-brand-blue-dark"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-brand-body block mb-1">سرعة الشحن:</label>
                <select
                  value={shippingSpeed}
                  onChange={(e) => setShippingSpeed(e.target.value)}
                  className="w-full bg-brand-surface-alt border border-brand-border rounded-xl px-3 py-2 text-xs text-brand-navy"
                >
                  <option value="شحن فوري (ساعتين)">شحن فوري (ساعتين)</option>
                  <option value="شحن سريع (24 ساعة)">شحن سريع (24 ساعة)</option>
                  <option value="شحن عادي (1 - 3 أيام)">شحن عادي (1 - 3 أيام)</option>
                </select>
              </div>
            </form>
          )}
        </div>

        {/* Footer / Total & Action */}
        {cart.length > 0 && (
          <div className="p-6 bg-brand-surface-alt border-t border-brand-border space-y-4">
            <div className="flex justify-between items-center text-sm font-bold">
              <span className="text-xl font-black text-brand-pink-dark font-mono">{totalPrice} ج.م</span>
              <span className="text-brand-body">الإجمالي النهائي:</span>
            </div>

            {!isCheckingOut ? (
              <Button3D onClick={() => setIsCheckingOut(true)} variant="navy" className="w-full py-3.5 text-xs">
                متابعة تأكيد الطلب ({totalPrice} ج.م)
              </Button3D>
            ) : (
              <Button3D type="submit" form="cart-form" variant="mint" className="w-full py-3.5 text-xs">
                <Send className="w-4 h-4 -rotate-45" />
                <span>إرسال السلة بالكامل للواتساب</span>
              </Button3D>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
