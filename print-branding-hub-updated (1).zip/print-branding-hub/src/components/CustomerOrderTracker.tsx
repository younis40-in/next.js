import React, { useState, useEffect } from 'react';
import { CustomerOrder, ProductionStage } from '../types';
import { getStoredOrders } from '../data/ordersStore';
import { 
  Search, 
  CheckCircle2, 
  Clock, 
  Package, 
  Truck, 
  ShieldCheck, 
  Sparkles, 
  MessageCircle, 
  FileText, 
  Printer, 
  Maximize2, 
  ArrowRight, 
  Layers, 
  Check, 
  AlertCircle,
  HelpCircle,
  Eye,
  MapPin,
  Phone
} from 'lucide-react';

interface CustomerOrderTrackerProps {
  initialOrderNumber?: string;
  onBackToStudio?: () => void;
}

export const CustomerOrderTracker: React.FC<CustomerOrderTrackerProps> = ({
  initialOrderNumber,
  onBackToStudio,
}) => {
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [searchQuery, setSearchQuery] = useState(initialOrderNumber || '');
  const [activeOrder, setActiveOrder] = useState<CustomerOrder | null>(null);
  const [selectedImageModal, setSelectedImageModal] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    const list = getStoredOrders();
    setOrders(list);

    if (initialOrderNumber) {
      const match = list.find(
        (o) => o.orderNumber.toLowerCase() === initialOrderNumber.toLowerCase()
      );
      if (match) {
        setActiveOrder(match);
        setSearched(true);
      }
    } else if (list.length > 0) {
      // Default to the most recent customer order
      setActiveOrder(list[0]);
      setSearchQuery(list[0].orderNumber);
      setSearched(true);
    }
  }, [initialOrderNumber]);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSearched(true);
    const query = searchQuery.trim().toLowerCase();

    if (!query) {
      setActiveOrder(null);
      return;
    }

    const match = orders.find(
      (o) =>
        o.orderNumber.toLowerCase().includes(query) ||
        o.customerPhone.includes(query) ||
        o.customerName.toLowerCase().includes(query)
    );

    setActiveOrder(match || null);
  };

  const handleQuickSelectOrder = (order: CustomerOrder) => {
    setActiveOrder(order);
    setSearchQuery(order.orderNumber);
    setSearched(true);
  };

  const handleOpenWhatsAppSupport = () => {
    if (!activeOrder) return;
    let text = `مرحباً يونس للإعلان You Adv، بخصوص طلبي الخاص رقم: *${activeOrder.orderNumber}*\n`;
    text += `الاسم: *${activeOrder.customerName}*\n`;
    text += `أتابع حالياً مراحل تنفيذ طلبي (${activeOrder.statusArabic}) وأرغب في الاستفسار عن الموعد النهائي للاستلام.`;
    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/201141350759?text=${encoded}`, '_blank');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-sky-950 via-blue-900 to-sky-900 text-white rounded-3xl p-6 sm:p-8 border border-sky-800 shadow-xl text-right relative overflow-hidden">
        <div className="absolute -bottom-10 -left-10 w-44 h-44 bg-cyan-400/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-amber-400/20 text-amber-300 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>نظام البث الحي لمراحل التصنيع والحفر • Live Production Tracker</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-['Cairo'] text-white">
              متابعة تصنيع منتجك الخاص لحظة بلحظة
            </h2>
            <p className="text-xs sm:text-sm text-sky-200 max-w-xl">
              شاهد منتجك في مراحل الإعداد، الحفر بماكينات الليزر، فحص جودة الحبر والتجميع حتى وصول المندوب لباب مقرك.
            </p>
          </div>

          {/* Quick Stats or Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenWhatsAppSupport}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>تحدث مع مهندس التنفيذ</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search Order Lookup Form */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3 text-right">
        <label className="block text-xs font-bold text-slate-800">
          ابحث عن طلبك برقم الطلب (Order ID) أو رقم الهاتف المسجل:
        </label>

        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="مثال: YOU-ORD-2026-9214 أو 01141350759..."
              className="w-full pr-10 pl-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-sky-500 focus:bg-white transition-all font-mono"
            />
          </div>

          <button
            type="submit"
            className="bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-black px-6 py-3 rounded-xl text-xs shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2 shrink-0"
          >
            <Search className="w-4 h-4" />
            <span>عرض منتجي ومراحل تنفيذه</span>
          </button>
        </form>

        {/* Quick Recent Order Chips for easy 1-click test */}
        {orders.length > 0 && (
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-[11px] text-slate-500 font-bold">طلبات سريعة للاختبار:</span>
            {orders.slice(0, 3).map((ord) => (
              <button
                key={ord.id}
                type="button"
                onClick={() => handleQuickSelectOrder(ord)}
                className={`px-2.5 py-1 rounded-lg font-mono text-[11px] font-bold transition-colors cursor-pointer border ${
                  activeOrder?.id === ord.id
                    ? 'bg-sky-100 text-sky-900 border-sky-300 font-black'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {ord.orderNumber} ({ord.customerName.split(' ')[0]})
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Order View Section: Only shows the customer's specific ordered product */}
      {activeOrder ? (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Order Header Summary Banner */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm text-right">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono font-black text-sm text-sky-950 bg-sky-100 px-3 py-1 rounded-xl border border-sky-300">
                    {activeOrder.orderNumber}
                  </span>
                  <span className="text-xs font-bold text-slate-500">
                    {activeOrder.createdAt}
                  </span>
                  <span className="bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-black px-2.5 py-1 rounded-lg">
                    {activeOrder.statusArabic}
                  </span>
                </div>

                <h3 className="text-lg font-black text-slate-900 font-['Cairo'] mt-2">
                  طلب العميل: {activeOrder.customerName}
                </h3>
                {activeOrder.companyName && (
                  <p className="text-xs text-slate-600 font-medium mt-0.5">
                    النشاط / الشركة: {activeOrder.companyName}
                  </p>
                )}
              </div>

              <div className="text-right sm:text-left bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <span className="text-[11px] text-slate-500 block">إجمالي المقايسة والتنفيذ:</span>
                <span className="text-xl font-black text-sky-900 font-mono">
                  {activeOrder.grandTotal} <span className="text-xs font-bold text-slate-700">ج.م</span>
                </span>
                <span className="text-[10px] text-slate-500 block mt-0.5">
                  طريقة الاستلام: {activeOrder.shippingMethod === 'pickup' ? 'استلام من المقر بالموسكي' : `توصيل (${activeOrder.governorate})`}
                </span>
              </div>
            </div>

            {/* Production Progress Bar */}
            <div className="pt-5 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-sky-900 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-sky-600 animate-spin-once" />
                  <span>المرحلة الحالية: {activeOrder.statusArabic}</span>
                </span>
                <span className="text-slate-500 font-mono">
                  {activeOrder.stages.filter((s) => s.completed).length} من {activeOrder.stages.length} مراحل مكتملة
                </span>
              </div>

              {/* Step Flow Indicators */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2">
                {activeOrder.stages.map((stage, idx) => (
                  <div
                    key={stage.id}
                    className={`p-3 rounded-2xl border text-right transition-all relative ${
                      stage.current
                        ? 'border-sky-500 bg-sky-50 shadow-xs ring-2 ring-sky-400/30'
                        : stage.completed
                        ? 'border-emerald-200 bg-emerald-50/70 text-emerald-950'
                        : 'border-slate-200 bg-slate-50/50 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`w-5 h-5 rounded-full text-[10px] font-mono font-bold flex items-center justify-center ${
                        stage.completed
                          ? 'bg-emerald-600 text-white'
                          : stage.current
                          ? 'bg-sky-600 text-white animate-pulse'
                          : 'bg-slate-200 text-slate-600'
                      }`}>
                        {stage.completed ? <Check className="w-3 h-3 stroke-[3]" /> : idx + 1}
                      </span>
                      {stage.current && (
                        <span className="text-[9px] font-black bg-sky-600 text-white px-1.5 py-0.2 rounded-md animate-pulse">
                          جارٍ الآن
                        </span>
                      )}
                    </div>

                    <span className="text-xs font-bold block leading-snug text-slate-900">
                      {stage.title}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      {stage.updatedAt}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* CUSTOMER'S SPECIFIC PRODUCT SHOWCASE */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-sky-100 text-sky-800">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900 font-['Cairo']">
                    منتجاتك المخصصة قيد التصنيع
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    يتم عرض وتصنيع المنتجات الخاصة بطلبك فقط وفقاً لبيانات الاعتماد المرفقة
                  </p>
                </div>
              </div>
              <span className="text-xs font-black text-sky-800 bg-sky-50 px-2.5 py-1 rounded-lg border border-sky-200">
                {activeOrder.items.length} منتج
              </span>
            </div>

            {/* List of customer's items */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeOrder.items.map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="bg-slate-50 rounded-2xl p-4 border border-slate-200/90 space-y-3 hover:border-sky-300 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h5 className="font-bold text-sm text-slate-900">
                        {item.title}
                      </h5>
                      <span className="text-xs text-sky-800 font-bold block mt-0.5">
                        الكمية: {item.quantity} {item.buy2Get1Free ? '• مشمول بعرض 2+1 مجاناً' : ''}
                      </span>
                    </div>
                    <span className="font-mono font-black text-sm text-slate-900 shrink-0">
                      {item.totalPrice} ج.م
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed bg-white p-2.5 rounded-xl border border-slate-200">
                    <strong className="text-slate-800">المواصفات المختارة:</strong> {item.optionsSummary}
                  </p>

                  {item.customizationDetails && Object.keys(item.customizationDetails).length > 0 && (
                    <div className="bg-white rounded-xl p-3 border border-sky-100 text-xs space-y-1.5">
                      <span className="font-bold text-sky-950 block text-[11px]">
                        بيانات الحفر والطباعة المعتمدة للمنتج:
                      </span>
                      {item.customizationDetails.stampLine1 && (
                        <div className="flex justify-between text-slate-700 text-[11px]">
                          <span>السطر الرئيسي:</span>
                          <span className="font-bold text-slate-900">{item.customizationDetails.stampLine1}</span>
                        </div>
                      )}
                      {item.customizationDetails.stampLine2 && (
                        <div className="flex justify-between text-slate-700 text-[11px]">
                          <span>السطر الفرعي:</span>
                          <span className="font-bold text-slate-900">{item.customizationDetails.stampLine2}</span>
                        </div>
                      )}
                      {item.customizationDetails.inkColor && (
                        <div className="flex justify-between text-slate-700 text-[11px]">
                          <span>لون الحبر المعتمد:</span>
                          <span className="font-bold text-sky-800">{item.customizationDetails.inkColor}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {activeOrder.customerNotes && (
              <div className="bg-amber-50 border border-amber-200 text-amber-950 rounded-2xl p-3.5 text-xs leading-relaxed">
                <span className="font-bold">ملاحظاتك المسجلة مع الطلب: </span>
                {activeOrder.customerNotes}
              </div>
            )}
          </div>

          {/* LIVE PRODUCTION STAGES & STAGE PHOTOS GALLERY */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-800">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900 font-['Cairo']">
                    معرض صور مراحل التنفيذ المباشرة لطلبك
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    صور حية من ورشة ومطبعة You Adv لمراحل التصميم، الليزر، والتغليف
                  </p>
                </div>
              </div>
            </div>

            {/* Stages Detailed Cards with Photos */}
            <div className="space-y-4">
              {activeOrder.stages.map((stage, idx) => (
                <div
                  key={stage.id}
                  className={`rounded-2xl border p-4 sm:p-5 transition-all ${
                    stage.current
                      ? 'border-sky-500 bg-sky-50/40 ring-1 ring-sky-400'
                      : stage.completed
                      ? 'border-slate-200 bg-white'
                      : 'border-slate-200/60 bg-slate-50/40 opacity-75'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    
                    {/* Stage Info (Left/Main in RTL) */}
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`w-6 h-6 rounded-full text-xs font-mono font-bold flex items-center justify-center ${
                          stage.completed
                            ? 'bg-emerald-600 text-white'
                            : stage.current
                            ? 'bg-sky-600 text-white animate-pulse'
                            : 'bg-slate-200 text-slate-600'
                        }`}>
                          {stage.completed ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : idx + 1}
                        </span>
                        
                        <h5 className="font-bold text-sm text-slate-900 font-['Cairo']">
                          {stage.title}
                        </h5>

                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          stage.completed
                            ? 'bg-emerald-100 text-emerald-900'
                            : stage.current
                            ? 'bg-sky-100 text-sky-900 font-black'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {stage.statusText}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed pr-8">
                        {stage.description}
                      </p>

                      <div className="pr-8 text-[11px] text-slate-400 font-medium">
                        توقيت المرحلة: {stage.updatedAt}
                      </div>
                    </div>

                    {/* Stage Photo Thumbnail / Preview */}
                    {stage.photoUrl && (
                      <div
                        onClick={() => setSelectedImageModal(stage.photoUrl || null)}
                        className="relative w-full md:w-56 h-32 rounded-xl overflow-hidden border border-slate-300 shadow-xs cursor-pointer group shrink-0 bg-slate-900"
                      >
                        <img
                          src={stage.photoUrl}
                          alt={stage.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end justify-between p-2">
                          <span className="text-[10px] font-bold text-white truncate max-w-[150px]">
                            {stage.photoCaption || stage.title}
                          </span>
                          <span className="p-1 rounded bg-white/20 text-white">
                            <Maximize2 className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              ))}
            </div>

            {/* Admin Workshop Note if present */}
            {activeOrder.adminNotes && (
              <div className="bg-slate-900 text-white rounded-2xl p-4 space-y-1 text-xs leading-relaxed">
                <span className="text-amber-300 font-bold block text-[11px]">
                  رسالة مباشرة من قسم التشغيل والإنتاج:
                </span>
                <p className="text-slate-200">{activeOrder.adminNotes}</p>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>ضمان الجودة والاستبدال معتمد من You Adv 2026</span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة بطاقة التتبع</span>
                </button>

                <button
                  type="button"
                  onClick={handleOpenWhatsAppSupport}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>تأكيد الموعد عبر واتساب</span>
                </button>
              </div>
            </div>

          </div>

        </div>
      ) : searched ? (
        <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center space-y-4 animate-fadeIn">
          <AlertCircle className="w-12 h-12 text-amber-500 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 font-['Cairo']">
            لم يتم العثور على طلب برقم: «{searchQuery}»
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
            يرجى التأكد من كتابة رقم الطلب بصيغة (YOU-ORD-2026-...) أو استخدام رقم الهاتف المسجل أثناء إنشاء الطلب.
          </p>
          {orders.length > 0 && (
            <button
              onClick={() => handleQuickSelectOrder(orders[0])}
              className="bg-sky-50 text-sky-800 hover:bg-sky-100 font-bold px-4 py-2 rounded-xl text-xs transition-colors border border-sky-200 cursor-pointer"
            >
              عرض آخر طلب نشط ({orders[0].orderNumber})
            </button>
          )}
        </div>
      ) : null}

      {/* Fullscreen Photo Lightbox Modal */}
      {selectedImageModal && (
        <div 
          onClick={() => setSelectedImageModal(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn cursor-zoom-out"
        >
          <div className="relative max-w-3xl w-full max-h-[90vh] flex flex-col items-center">
            <img
              src={selectedImageModal}
              alt="صورة مرحلة التنفيذ"
              referrerPolicy="no-referrer"
              className="max-h-[80vh] w-auto rounded-2xl object-contain shadow-2xl border border-white/20"
            />
            <span className="text-white text-xs font-bold mt-3 bg-black/60 px-4 py-1.5 rounded-full border border-white/10">
              صورة بروفة مرحلة التنفيذ بالورشة • انقر في أي مكان للإغلاق
            </span>
          </div>
        </div>
      )}

    </div>
  );
};
