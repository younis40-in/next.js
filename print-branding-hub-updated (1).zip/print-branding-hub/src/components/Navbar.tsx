import React from 'react';
import { Phone, MessageCircle, Sparkles, FileText, ShoppingBag, MapPin, Clock, Eye, ShieldCheck } from 'lucide-react';
import Logo from './Logo';

export type NavTabType = 'studio' | 'catalog' | 'order' | 'about' | 'tracker' | 'admin';

interface NavbarProps {
  activeTab: NavTabType;
  setActiveTab: (tab: NavTabType) => void;
  cartCount: number;
  openCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, cartCount, openCart }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0c0a1d]/90 backdrop-blur-xl border-b border-rose-500/20 shadow-2xl">
      {/* Top micro bar */}
      <div className="bg-gradient-to-r from-rose-900 via-[#181135] to-sky-950 text-white text-xs py-1.5 px-4 border-b border-rose-500/20">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-sky-300 font-medium">
              <MapPin className="w-3.5 h-3.5 text-rose-400" />
              المقر: 157 شارع محمد علي (العتبة) • المعرض: 171 شارع سعد زغلول (الجيزة)
            </span>
          </div>
          <div className="flex items-center gap-3">
            <a href="tel:01141350759" className="flex items-center gap-1 text-sky-200 hover:text-white">
              <Phone className="w-3 h-3 text-emerald-400" />
              <span>01141350759</span>
            </a>
            <span className="text-slate-500">|</span>
            <a href="https://wa.me/201141350759" target="_blank" rel="noreferrer" className="flex items-center gap-1 text-emerald-400 font-semibold">
              <MessageCircle className="w-3.5 h-3.5 fill-emerald-400 text-emerald-950" />
              <span>واتساب مباشر</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* YouAdv Official Glowing Logo */}
          <div onClick={() => setActiveTab('studio')} className="cursor-pointer">
            <Logo size="md" />
          </div>

          {/* Center Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1.5 bg-[#140e30] p-1.5 rounded-2xl border border-rose-500/20">
            <button
              onClick={() => setActiveTab('studio')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'studio'
                  ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-lg shadow-rose-600/30 border border-rose-400/40 font-black'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>استوديو المعاينة 3D</span>
            </button>
            
            <button
              onClick={() => setActiveTab('tracker')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'tracker'
                  ? 'bg-sky-600 text-white shadow-lg font-black'
                  : 'text-sky-300 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 font-extrabold'
              }`}
            >
              <Eye className="w-3.5 h-3.5 text-amber-400" />
              <span>تتبع الطلبات المباشر</span>
            </button>

            <button
              onClick={() => setActiveTab('catalog')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'catalog'
                  ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-lg border border-rose-400/40 font-black'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-sky-400" />
              <span>كتالوج الأسعار والعروض</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-slate-800 text-white shadow-sm font-black border border-slate-700'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
              <span>لوحة الإدارة</span>
            </button>
          </nav>

          {/* Action Cart Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={openCart}
              className="relative flex items-center gap-2 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-lg shadow-rose-600/30 border border-rose-400/40 transition-all cursor-pointer hover:scale-105"
            >
              <ShoppingBag className="w-4 h-4 text-amber-300" />
              <span>السلة</span>
              {cartCount > 0 && (
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border border-white">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
