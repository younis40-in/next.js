"use client";

import React, { useState } from "react";
import { X, Send, User, Phone, MapPin, Truck, FileText, Sparkles, Info } from "lucide-react";
import Button3D from "@/components/Button3D";

export interface OrderDetails {
  title: string;
  category?: string;
  price?: string;
  size?: string;
  customText?: string;
  subtitleText?: string;
  inkColor?: string;
}

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: OrderDetails | null;
}

export default function OrderModal({ isOpen, onClose, order }: OrderModalProps) {
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [shippingSpeed, setShippingSpeed] = useState("سريع (خلال 24 ساعة)");
  const [notes, setNotes] = useState("");

  if (!isOpen || !order) return null;

  const handleSendOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone) {
      alert("يرجى إدخال الاسم ورقم الهاتف.");
      return;
    }

    const message = `*طلب جديد من منصة YouAdv للطباعة والبراندينج* 🚀
----------------------------------------
📌 *المنتج:* ${order.title}
💰 *السعر:* ${order.price || "حسب المواصفات"}
📏 *المواصفات:* ${order.size || "قياسي معتمد"}
${order.customText ? `✍️ *الاسم:* ${order.customText}` : ""}

👤 *بيانات العميل:*
- *الاسم:* ${customerName}
- *الهاتف:* ${phone}
- *العنوان:* ${address || "سيتم التحديد في المحادثة"}
- *الشحن:* ${shippingSpeed}
----------------------------------------`;

    const whatsappUrl = `https://wa.me/201141350759?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-brand-navy-dark/70 backdrop-blur-md">
      <div className="bg-white text-brand-navy border-2 border-brand-border rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto text-right">
        <button onClick={onClose} className="absolute top-5 left-5 text-brand-muted hover:text-brand-navy p-2 rounded-full bg-brand-surface-alt">
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-2xl font-black text-brand-navy mb-4">إتمام الطلب السريع</h3>
        
        <div className="p-4 rounded-2xl bg-brand-surface-alt border border-brand-border mb-4 space-y-1 text-xs">
          <div className="flex justify-between font-bold text-brand-pink-dark">
            <span>{order.title}</span>
            <span className="text-brand-blue-dark">{order.price}</span>
          </div>
        </div>

        <form onSubmit={handleSendOrder} className="space-y-3.5 text-xs">
          <div>
            <label className="block text-brand-body mb-1 font-bold">الاسم بالكامل:</label>
            <input type="text" required value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="w-full bg-brand-surface-alt border border-brand-border rounded-xl p-2.5 text-brand-navy outline-none focus:border-brand-blue-dark" />
          </div>

          <div>
            <label className="block text-brand-body mb-1 font-bold">رقم الهاتف أو الواتساب:</label>
            <input type="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full bg-brand-surface-alt border border-brand-border rounded-xl p-2.5 text-brand-navy outline-none focus:border-brand-blue-dark text-right font-mono" />
          </div>

          <div>
            <label className="block text-brand-body mb-1 font-bold">العنوان أو المحافظة:</label>
            <input type="text" value={address} onChange={(e) => setAddress(e.target.value)} className="w-full bg-brand-surface-alt border border-brand-border rounded-xl p-2.5 text-brand-navy outline-none focus:border-brand-blue-dark" />
          </div>

          <div className="flex items-start gap-2.5 p-3.5 rounded-2xl bg-brand-yellow/40 border border-brand-yellow text-brand-gold-dark">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-brand-gold-dark" />
            <p className="text-[11px] leading-relaxed">
              المعاينة المعروضة تصميم أولي لتقريب الشكل العام فقط. بمجرد تأكيد الحجز، سيقوم فريق التصميم بإعداد وإرسال <strong className="text-brand-navy">التصميم النهائي الجاهز للطباعة</strong> لاعتماده معك قبل التنفيذ.
            </p>
          </div>

          <Button3D type="submit" variant="mint" className="w-full mt-1 py-3.5">
            <Send className="w-4 h-4 -rotate-45" />
            <span>إرسال وتأكيد الطلب للواتساب</span>
          </Button3D>
        </form>
      </div>
    </div>
  );
}
