import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import { CartProvider } from "@/context/CartContext";
import CartDrawer from "@/components/CartDrawer";
import ChatbotWidget from "@/components/ChatbotWidget";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "600", "700", "800", "900"],
  variable: "--font-cairo",
});

export const metadata: Metadata = {
  title: "Remix You Adv | ستوديو الطباعة والهوية المخصصة 2026",
  description: "منصة تقديم خدمات الطباعة للأفراد والمؤسسات والشركات وتقديم خدمات طباعة فورية",
  applicationName: "You Adv Studio",
  authors: [{ name: "Mohamed Hosny" }],
  keywords: ["طباعة فورية", "أختام ليزر", "كروت شخصية", "دروع تكريم", "فواتير وسندات", "YouAdv", "يونس للإعلان"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${cairo.variable} font-sans bg-brand-bg text-brand-navy antialiased min-h-screen flex flex-col selection:bg-brand-yellow selection:text-brand-navy`}>
        <CartProvider>
          {children}
          <CartDrawer />
          <ChatbotWidget />
        </CartProvider>
      </body>
    </html>
  );
}
