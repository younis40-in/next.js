"use client";

import React, { useState } from "react";
import Link from "next/link";
import Logo from "@/components/Logo";
import ProductCatalogSection from "@/components/ProductCatalogSection";
import DesignStudio from "@/components/DesignStudio";
import OrderModal, { OrderDetails } from "@/components/OrderModal";
import Button3D from "@/components/Button3D";
import { brandKit } from "@/data/brandKit";
import {
  Sparkles, 
  Package, 
  Layers, 
  Award, 
  Clock, 
  ShieldCheck, 
  ArrowLeft, 
  CheckCircle2, 
  Truck, 
  MapPin, 
  Phone,
  ShoppingBag,
  Volume2,
  VolumeX,
  FileText,
  Navigation,
  MessageCircle
} from "lucide-react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      [elemName: string]: any;
    }
  }
}

export default function Home() {
  const [isMuted, setIsMuted] = useState(true);
  const [selectedBundle, setSelectedBundle] = useState<OrderDetails | null>(null);
  const [isBundleModalOpen, setIsBundleModalOpen] = useState(false);

  const handleOrderBundle = (bundleName: string, price: string, details: string) => {
    setSelectedBundle({
      title: bundleName,
      price: price,
      size: details,
      category: "باقات براندينج",
    });
    setIsBundleModalOpen(true);
  };

  return (
    <div className="flex flex-col min-h-screen bg-brand-bg text-brand-navy selection:bg-brand-yellow selection:text-brand-navy font-sans antialiased overflow-x-hidden">
      
      {/* Top Banner */}
      <div className="bg-brand-navy text-white text-xs py-2 px-4 text-center font-extrabold tracking-wider border-b border-brand-gold/30 shadow-md flex items-center justify-center gap-2">
        <Sparkles className="w-4 h-4 text-brand-gold animate-pulse" />
        <span className="text-brand-blue">{brandKit.slogan}</span>
        <span className="text-white/30">|</span>
        <span className="text-brand-pink">{brandKit.calligraphyName}</span>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-xl border-b border-brand-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <Logo size="md" />

          <nav className="hidden md:flex items-center gap-8 text-sm font-bold text-brand-body">
            <a href="#pricing-catalog" className="hover:text-brand-pink-dark transition">الأسعار والمنتجات</a>
            <a href="#studio" className="hover:text-brand-blue-dark transition">استوديو التصميم 3D</a>
            <a href="#bundles" className="hover:text-brand-pink-dark transition">باقات المشروعات</a>
            <a href="#shipping" className="hover:text-brand-blue-dark transition">الشحن والفروع</a>
          </nav>

          <div className="flex items-center gap-4">
            <Button3D as="a" href="#studio" variant="gold" className="text-xs px-5 py-2.5">
              <Sparkles className="w-4 h-4" />
              <span>جرب المعاينة الحية</span>
            </Button3D>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-10 pb-20 lg:pt-14 lg:pb-28 overflow-hidden border-b border-brand-border bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(200,223,252,0.6),rgba(247,250,252,0))]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">

          {/* 3D Video Podium Showcase */}
          <div id="video-showcase" className="max-w-5xl mx-auto scroll-mt-28">
            <div className="relative rounded-[32px] overflow-hidden border-2 border-brand-border shadow-2xl shadow-brand-blue-dark/10 bg-white p-2 sm:p-4">
              <div className="relative rounded-2xl overflow-hidden aspect-video bg-brand-navy flex items-center justify-center">
                <video
                  src="/hero-showcase.mp4"
                  autoPlay
                  loop
                  muted={isMuted}
                  playsInline
                  controls
                  className="w-full h-full object-cover rounded-xl"
                >
                  <source src="/hero-showcase.mp4" type="video/mp4" />
                </video>

                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="absolute bottom-6 left-6 z-20 bg-white/95 hover:bg-brand-surface-alt text-brand-navy px-4 py-2 rounded-xl border border-brand-border backdrop-blur-md transition shadow-xl flex items-center gap-2 text-xs font-bold"
                >
                  {isMuted ? (
                    <>
                      <VolumeX className="w-4 h-4 text-brand-pink-dark" />
                      <span>تشغيل الصوت</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-brand-blue-dark" />
                      <span>كتم الصوت</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          <div className="mt-12 flex flex-wrap justify-center gap-5">
            <Button3D as="a" href="#studio" variant="navy" className="px-8 py-4 text-sm">
              <span>فتح استوديو التصميم الآن</span>
              <ArrowLeft className="w-4 h-4" />
            </Button3D>
            <Button3D as="a" href="/pypdf.pdf" target="_blank" rel="noreferrer" variant="gold" className="px-8 py-4 text-sm">
              <FileText className="w-4 h-4" />
              <span>تصفح الكتالوج</span>
            </Button3D>
            <Button3D
              as="a"
              href="https://www.google.com/maps/search/?api=1&query=157%20%D8%B4%D8%A7%D8%B1%D8%B9%20%D9%85%D8%AD%D9%85%D8%AF%20%D8%B9%D9%84%D9%8A%D8%8C%20%D8%A3%D9%85%D8%A7%D9%85%20%D9%82%D8%B3%D9%85%20%D8%A7%D9%84%D9%85%D9%88%D8%B3%D9%83%D9%8A%D8%8C%20%D8%A7%D9%84%D8%B9%D8%AA%D8%A8%D8%A9%D8%8C%20%D8%A7%D9%84%D9%82%D8%A7%D9%87%D8%B1%D8%A9"
              target="_blank"
              rel="noreferrer"
              variant="blue"
              className="px-8 py-4 text-sm"
            >
              <Navigation className="w-4 h-4" />
              <span>موقعنا على الخريطة</span>
            </Button3D>
          </div>

          {/* Quick Pillars */}
          <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto text-right">
            <div className="bg-white p-4 rounded-2xl border border-brand-border shadow-[0_4px_0_0_#E2E8F5]">
              <Clock className="w-5 h-5 text-brand-blue-dark mb-2" />
              <span className="text-xs font-bold text-brand-navy block">تسليم فوري وسريع</span>
              <span className="text-[11px] text-brand-muted">خلال ساعتين أو 24 ساعة</span>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-brand-border shadow-[0_4px_0_0_#E2E8F5]">
              <ShieldCheck className="w-5 h-5 text-brand-pink-dark mb-2" />
              <span className="text-xs font-bold text-brand-navy block">دقة طباعة ليزر</span>
              <span className="text-[11px] text-brand-muted">خامات أصلية وألوان مطابقة</span>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-brand-border shadow-[0_4px_0_0_#E2E8F5]">
              <Sparkles className="w-5 h-5 text-brand-gold-dark mb-2" />
              <span className="text-xs font-bold text-brand-navy block">معاينة حية فورية</span>
              <span className="text-[11px] text-brand-muted">تأكيد الشكل قبل التنفيذ</span>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-brand-border shadow-[0_4px_0_0_#E2E8F5]">
              <Package className="w-5 h-5 text-brand-mint-dark mb-2" />
              <span className="text-xs font-bold text-brand-navy block">باقات مجمعة مخفضة</span>
              <span className="text-[11px] text-brand-muted">خصم شامل للشركات</span>
            </div>
          </div>

        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 space-y-32">
        
        {/* Section 1: Comprehensive Product Pricing & Catalog */}
        <ProductCatalogSection />

        {/* Section 2: Interactive Design Studio */}
        <DesignStudio />

        {/* Section 3: Branding Bundles */}
        <section id="bundles" className="scroll-mt-28 bg-white rounded-[36px] p-8 sm:p-14 border border-brand-border shadow-[0_8px_0_0_#E2E8F5]">
          <div className="max-w-3xl mb-14">
            <span className="text-brand-pink-dark font-black text-xs uppercase tracking-widest bg-brand-pink/40 px-3 py-1 rounded-full border border-brand-pink">
              باقات المشروعات
            </span>
            <h2 className="text-3xl sm:text-5xl font-black text-brand-navy mt-3">باقات البراندينج الشاملة للمشاريع الناشئة</h2>
            <p className="text-brand-body text-sm sm:text-base mt-2">
              حزمة واحدة متكاملة تجمع كل مطبوعات هويتك وتغليفك بسعر موحد وخصم شامل.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-brand-surface-alt border border-brand-border rounded-3xl p-7 flex flex-col justify-between hover:border-brand-blue-dark/40 transition">
              <div>
                <span className="text-xs font-bold text-brand-blue-dark bg-brand-blue/50 px-3 py-1 rounded-full border border-brand-blue">
                  باقة الانطلاق
                </span>
                <h3 className="text-2xl font-black mt-4 text-brand-navy">Starter Pack</h3>
                <p className="text-xs text-brand-muted mt-2 mb-6">للمتاجر المنزلية والمشروعات الفردية.</p>
                <ul className="space-y-3.5 text-xs text-brand-body">
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-blue-dark" /> 300 كارت شخصي ديجيتال فاخر</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-blue-dark" /> 200 ستيكر / ليبل دائري للمنتجات</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-blue-dark" /> 1 ختم بوكيت ترودات رسمي</li>
                </ul>
              </div>
              <Button3D
                onClick={() => handleOrderBundle("باقة الانطلاق (Starter Pack)", "800 ج.م", "300 كارت + 200 ستيكر + 1 ختم بوكيت")}
                variant="blue"
                className="mt-8 w-full py-3.5 text-xs"
              >
                طلب باقة الانطلاق
              </Button3D>
            </div>

            <div className="bg-gradient-to-b from-brand-pink via-white to-brand-blue border-2 border-brand-gold rounded-3xl p-7 flex flex-col justify-between shadow-[0_8px_0_0_#E2E8F5] relative">
              <div className="absolute -top-3.5 right-8 bg-brand-gold text-white font-black text-xs px-4 py-1 rounded-full shadow-lg">
                الأكثر طلباً للمشاريع ⭐
              </div>
              <div>
                <span className="text-xs font-bold bg-white/70 text-brand-navy px-3 py-1 rounded-full">
                  باقة النمو المتكاملة
                </span>
                <h3 className="text-2xl font-black mt-4 text-brand-navy">Brand Growth Pack</h3>
                <p className="text-xs text-brand-body mt-2 mb-6">المجموعة الشاملة لهوية المتجر والتغليف والانتشار.</p>
                <ul className="space-y-3.5 text-xs text-brand-navy">
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-gold-dark" /> 500 كارت شخصي ديجيتال وجهين</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-gold-dark" /> 500 ليبل واستيكر تغليف لاصق</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-gold-dark" /> 100 شنطة تسويقية مطبوعة</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-gold-dark" /> 1000 فلاير إعلاني نص A4</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-gold-dark" /> 1 ختم ماكينة / بوكيت كبير رسمي</li>
                </ul>
              </div>
              <Button3D
                onClick={() => handleOrderBundle("باقة النمو المتكاملة (Growth Pack)", "1950 ج.م", "500 كارت + 500 استيكر + 100 شنطة + 1000 فلاير + 1 ختم ماكينة")}
                variant="gold"
                className="mt-8 w-full py-3.5 text-xs"
              >
                طلب باقة النمو الآن
              </Button3D>
            </div>

            <div className="bg-brand-surface-alt border border-brand-border rounded-3xl p-7 flex flex-col justify-between hover:border-brand-pink-dark/40 transition">
              <div>
                <span className="text-xs font-bold text-brand-pink-dark bg-brand-pink/50 px-3 py-1 rounded-full border border-brand-pink">
                  باقة الشركات الكبرى
                </span>
                <h3 className="text-2xl font-black mt-4 text-brand-navy">Corporate VIP</h3>
                <p className="text-xs text-brand-muted mt-2 mb-6">تجهيز كامل للمكاتب والمؤسسات والشركات.</p>
                <ul className="space-y-3.5 text-xs text-brand-body">
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-pink-dark" /> 1000 كارت شخصي + دفاتر فواتير وسندات</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-pink-dark" /> يافطة مكتبية فاخرة + طقم مكتب جلد</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-pink-dark" /> نيم تاج معدني مذهب للموظفين</li>
                  <li className="flex items-center gap-2.5"><CheckCircle2 className="w-4 h-4 text-brand-pink-dark" /> دروع تكريم وهدايا ترويجية للعملاء</li>
                </ul>
              </div>
              <Button3D
                onClick={() => handleOrderBundle("باقة الشركات (Corporate VIP)", "عقد مخصص", "1000 كارت + دفاتر فواتير + يافطة + طقم مكتب + نيم تاج + دروع")}
                variant="pink"
                className="mt-8 w-full py-3.5 text-xs"
              >
                طلب عرض باقة الشركات
              </Button3D>
            </div>
          </div>
        </section>

        {/* Section 4: Shipping & Locations Info */}
        <section id="shipping" className="bg-white rounded-3xl border border-brand-border shadow-[0_6px_0_0_#E2E8F5] p-8 sm:p-12 grid md:grid-cols-2 gap-10 scroll-mt-28">
          <div>
            <h4 className="text-lg font-black text-brand-navy flex items-center gap-2.5 mb-5">
              <Truck className="w-5 h-5 text-brand-blue-dark" />
              سياسات وخيارات الشحن والتسليم
            </h4>
            <div className="space-y-3 text-xs">
              <div className="p-4 bg-brand-surface-alt rounded-2xl border border-brand-border">
                <span className="font-bold text-brand-pink-dark block">شحن فوري (خلال ساعتين من الطلب)</span>
                <span className="text-brand-muted">داخل نطاق القاهرة والجيزة للطلبات المستعجلة.</span>
              </div>
              <div className="p-4 bg-brand-surface-alt rounded-2xl border border-brand-border">
                <span className="font-bold text-brand-blue-dark block">شحن سريع (خلال 24 ساعة)</span>
                <span className="text-brand-muted">تسليم مباشر لكافة المحافظات.</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-black text-brand-navy flex items-center gap-2.5 mb-5">
              <MapPin className="w-5 h-5 text-brand-pink-dark" />
              الفروع والتواصل
            </h4>
            <div className="space-y-3 text-xs text-brand-body">
              <div className="p-4 bg-brand-surface-alt rounded-2xl border border-brand-border">
                <span className="font-bold text-brand-navy block">المقر والورشة (العتبة):</span>
                <span className="text-brand-muted">{brandKit.contacts.headquarters}</span>
              </div>
              <div className="p-4 bg-brand-surface-alt rounded-2xl border border-brand-border">
                <span className="font-bold text-brand-navy block">المعرض (الجيزة):</span>
                <span className="text-brand-muted">{brandKit.contacts.showroom}</span>
              </div>
            </div>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="bg-brand-navy border-t border-brand-gold/20 py-16 text-center text-xs text-white/60">
        <div className="max-w-7xl mx-auto px-4 space-y-4">
          <div className="flex justify-center mb-4">
            <Logo size="lg" />
          </div>
          <p className="text-white text-sm font-bold">{brandKit.signature}</p>
          <p className="text-white/60">{brandKit.contacts.headquarters}</p>
          <Button3D as="a" href={`https://wa.me/2${brandKit.contacts.phone1}`} target="_blank" rel="noreferrer" variant="whatsapp" className="px-5 py-2.5 text-xs mt-1">
            <MessageCircle className="w-4 h-4" />
            <span>تواصل معنا على واتساب</span>
          </Button3D>
          <p className="text-white/40 pt-4 text-[11px]">© {new Date().getFullYear()} YouAdv Platform. جميع الحقوق محفوظة.</p>
        </div>
      </footer>

      {/* Order Modal for Bundles */}
      <OrderModal
        isOpen={isBundleModalOpen}
        onClose={() => setIsBundleModalOpen(false)}
        order={selectedBundle}
      />
    </div>
  );
}
