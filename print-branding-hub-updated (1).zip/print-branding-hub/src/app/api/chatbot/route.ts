import { NextResponse } from "next/server";
import { brandKit } from "@/data/brandKit";
import { finalCatalog } from "@/data/catalog";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

const SYSTEM_CONTEXT = `أنت "مساعد YouAdv" — شات بوت خدمة عملاء ذكي لمنصة "${brandKit.brandName} (${brandKit.englishName})" المتخصصة في الطباعة والبراندينج (أختام، كروت شخصية، دروع تكريم، دفاتر فواتير، فلايرات، نيم تاج، وباقات براندينج شاملة).

معلومات مهمة عن المنصة:
- اسم النشاط: ${brandKit.calligraphyName} (${brandKit.englishName})
- الشعار: ${brandKit.slogan}
- المقر الرئيسي: ${brandKit.contacts.headquarters}
- المعرض: ${brandKit.contacts.showroom}
- رقم الهاتف / الواتساب: ${brandKit.contacts.phone1}
- البريد الإلكتروني: ${brandKit.contacts.email}

قائمة أهم المنتجات والأسعار التقريبية (بالجنيه المصري):
${finalCatalog.map((p) => `- ${p.title} | الفئة: ${p.category} | السعر: ${p.price} | المقاس: ${p.size}`).join("\n")}

سياسات مهمة يجب توضيحها دائمًا عند سؤال العميل عن التصميم أو الطلب:
- المعاينة/التصميم الظاهر في استوديو التصميم على الموقع هو تصميم أولي (تقريبي) لتوضيح الشكل العام فقط.
- بمجرد تأكيد حجز الطلب، يقوم فريق التصميم بإعداد وإرسال التصميم النهائي الجاهز للطباعة للعميل لاعتماده قبل بدء التنفيذ الفعلي.
- خيارات الشحن: شحن فوري (خلال ساعتين، داخل القاهرة والجيزة)، شحن سريع (خلال 24 ساعة لكل المحافظات)، شحن عادي (1-3 أيام).

تعليمات الأسلوب:
- رد دائمًا باللغة العربية المصرية العامية المهذبة، بأسلوب ودود ومختصر ومباشر.
- لو السؤال عن منتج أو سعر غير موجود في القائمة أعلاه، اعتذر بلطف واقترح التواصل المباشر عبر واتساب على ${brandKit.contacts.phone1}.
- لو العميل عايز يأكد طلب فعليًا، وجّهه لاستخدام زر "إضافة للسلة" أو "طلب الآن" في الموقع، أو التواصل مباشرة عبر واتساب.
- لا تخترع أسعارًا أو مواصفات غير مذكورة أعلاه.
- خلي الردود قصيرة (2-4 جمل) إلا لو العميل طلب تفاصيل أكتر.`;

export async function POST(req: Request) {
  try {
    const { messages } = (await req.json()) as { messages: ChatMessage[] };

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ success: false, error: "لا توجد رسائل" }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY || "";

    if (!apiKey) {
      return NextResponse.json({
        success: true,
        reply:
          "أهلاً بيك في YouAdv! 👋 خدمة الشات الذكي محتاجة إعداد مفتاح API من الإدارة حاليًا. للمساعدة الفورية، تقدر تتواصل معانا مباشرة على واتساب: " +
          brandKit.contacts.phone1,
      });
    }

    const contents = [
      { role: "user", parts: [{ text: SYSTEM_CONTEXT }] },
      { role: "model", parts: [{ text: "تمام، هساعد عملاء YouAdv بالمعلومات دي بالظبط." }] },
      ...messages.map((m) => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.content }],
      })),
    ];

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents,
            generationConfig: { temperature: 0.6, maxOutputTokens: 400 },
          }),
        }
      );

      const data = await response.json();
      const reply =
        data?.candidates?.[0]?.content?.parts?.[0]?.text ||
        "معلش، حصل خطأ بسيط. ممكن تجرب تسأل تاني أو تتواصل معانا على واتساب: " + brandKit.contacts.phone1;

      return NextResponse.json({ success: true, reply });
    } catch (fetchError) {
      console.error("Gemini fetch failed:", fetchError);
      return NextResponse.json({
        success: true,
        reply:
          "معلش، خدمة الشات الذكي مش متاحة دلوقتي. تقدر تتواصل معانا مباشرة على واتساب وهنرد عليك فورًا: " +
          brandKit.contacts.phone1,
      });
    }
  } catch (error) {
    console.error("Chatbot API Error:", error);
    return NextResponse.json(
      { success: false, error: "حدث خطأ أثناء المعالجة" },
      { status: 500 }
    );
  }
}
