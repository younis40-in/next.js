import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { companyName, field, personName, city } = await req.json();

    const name = companyName?.trim() || "يونس للإعلان YouAdv";
    const profession = field?.trim() || "دعاية وإعلان وطباعة";
    const person = personName?.trim() || "محمد حسني";
    const location = city?.trim() || "القاهرة - العتبة";
    const randCR = Math.floor(100000 + Math.random() * 900000);
    const randTax = `${Math.floor(100 + Math.random() * 900)}-${Math.floor(100 + Math.random() * 900)}-${Math.floor(100 + Math.random() * 900)}`;

    const fallbackData = {
      slogan: `الريادة والإبداع في عالم ${profession}`,
      stampLine1: name,
      stampLine2: `${profession} • ${location}`,
      stampLine3: `س.ت: ${randCR} • ب.ض: ${randTax}`,
      jobTitle: "المدير العام",
      trophyText: `شكر وتقدير لمجهودات الأستاذ / ${person} المتميزة في قيادة وتطوير الأعمال لعام 2026`,
      colorTheme: "executive_navy",
      source: "youadv_smart_engine"
    };

    const apiKey = process.env.GEMINI_API_KEY || "";
    if (apiKey) {
      try {
        const prompt = `أنت خبير الهوية والتسويق لمنصة "يونس للإعلان YouAdv". بناءً على هذه البيانات:
- المنشأة: "${name}"
- التخصص: "${profession}"
- الاسم: "${person}"
- المدينة: "${location}"
أرجع استجابة بتنسيق JSON حصراً:
{
  "slogan": "شعار إعلاني جذاب من 4-6 كلمات",
  "stampLine1": "${name}",
  "stampLine2": "${profession} • ${location}",
  "stampLine3": "س.ت: ${randCR} • ب.ض: ${randTax}",
  "jobTitle": "اللقب والصفة الوظيفية",
  "trophyText": "نص درع تكريم بليغ وموجز"
}`;
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: { responseMimeType: "application/json" }
            })
          }
        );
        const data = await response.json();
        const parsed = JSON.parse(data?.candidates?.[0]?.content?.parts?.[0]?.text || "{}");
        return NextResponse.json({ ...fallbackData, ...parsed, source: "gemini_ai" });
      } catch (err) {}
    }

    return NextResponse.json(fallbackData);
  } catch (error) {
    return NextResponse.json({ success: false, error: "Identity API error" }, { status: 500 });
  }
}
