import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { productType, shape, rawText, inkColor, hasLogo } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY || "";
    let aiSummary = "";

    if (apiKey) {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `أنت مصمم مطبوعات وأختام محترف في YouAdv. لخص ونسق هذه البيانات باللغة العربية بدقة للطباعة لمنتج (${productType} - شكل ${shape}): "${rawText}". أرجع فقط الأسطر منسقة بدون مقدمات.`
                  }
                ]
              }
            ]
          })
        }
      );
      const data = await response.json();
      aiSummary = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    }

    const lines = (rawText || "").split("\n").filter((l: string) => l.trim().length > 0);
    const mainTitle = lines[0] || "يونس للإعلان والطباعة";
    const subtitle = lines || "دعاية وإعلان • هويات بصرية";
    const contactInfo = lines.slice(2).join(" • ") || "العتبة - القاهرة • 01141350759";

    return NextResponse.json({
      success: true,
      mainTitle,
      subtitle,
      contactInfo,
      productType,
      shape,
      inkColor,
      hasLogo,
      aiSummary,
    });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to generate design" }, { status: 500 });
  }
}
