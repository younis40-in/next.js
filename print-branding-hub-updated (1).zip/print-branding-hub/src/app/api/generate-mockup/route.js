import { GoogleGenAI } from "@google/genai";
import { NextResponse } from "next/server";
import { PRODUCT_TEMPLATES } from "@/lib/productsConfig";

export async function POST(req) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ success: false, error: "مفتاح GEMINI_API_KEY غير موجود في .env.local" }, { status: 400 });
    }

    const ai = new GoogleGenAI({ apiKey });
    const { category, subType, textLines, mainColor } = await req.json();

    const template = PRODUCT_TEMPLATES[category] || {
      material: "High-end commercial printed product",
      printType: "Professional custom branding",
      setting: "Studio lighting, 3D realistic mockup"
    };

    // 1. محاولة توليد صورة إذا كان الحساب يدعم Imagen
    try {
      const response = await ai.models.generateImages({
        model: "imagen-3.0-generate-002",
        prompt: `3D commercial product mockup photography for: ${category} (${subType}). Spec: ${template.material}. Text: "${textLines}". Theme: ${mainColor}.`,
        config: { numberOfImages: 1, aspectRatio: "1:1", outputMimeType: "image/jpeg" }
      });
      if (response?.generatedImages?.[0]?.image?.imageBytes) {
        const imageUrl = `data:image/jpeg;base64,${response.generatedImages[0].image.imageBytes}`;
        return NextResponse.json({ success: true, type: "image", result: imageUrl });
      }
    } catch (e) {
      console.warn("Imagen requires billing, switching seamlessly to Gemini 2.5 3D Engine...");
    }

    // 2. البديل المجاني التلقائي: توليد مجسم ثلاثي الأبعاد 3D SVG واقعي عبر gemini-2.5-flash
    const prompt = `أنت مصمم 3D خبير. قم برسم كود SVG نقي لمجسم موك آب ثلاثي الأبعاد (3D Realistic Mockup) لمنتج: ${category} (${subType || ""}).
- خامة ومواصفات المنتج: ${template.material}
- لون الحبر/الطباعة الرئيسي: ${mainColor || "#2563eb"}
- النصوص المطبوعة على المجسم:
${textLines}

شروط التصميم ثلاثي الأبعاد:
1. استخدم التدرجات والظلال (Gradients & DropShadows) ليبدو المنتج مجسماً وواقعياً بوضعية 3D أنيقة.
2. النصوص العربية مكتوبة بخط واضح ومتناسقة مع مكان الطباعة على المنتج.
3. اجعل كود الـ SVG متجاوباً بـ viewBox="0 0 600 600".
4. أرجع كود SVG نقي فقط يبدأ بـ <svg ويغلق بـ </svg> بدون أي ماركداون.`;

    const geminiRes = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt
    });

    let svgCode = geminiRes.text.trim();
    svgCode = svgCode.replace(/^\`\`\`(xml|svg)?/i, "").replace(/\`\`\`$/i, "").trim();

    return NextResponse.json({ success: true, type: "svg", result: svgCode });
  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json({ success: false, error: error.message || "حدث خطأ أثناء التوليد" }, { status: 500 });
  }
}