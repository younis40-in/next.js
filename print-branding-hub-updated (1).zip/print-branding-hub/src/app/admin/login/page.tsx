"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Logo from "@/components/Logo";
import { createClient } from "@/lib/supabase/client";
import { Lock, Mail, Loader2, AlertCircle } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    const supabase = createClient();
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    setIsLoading(false);

    if (signInError) {
      setError("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
      return;
    }

    router.push("/admin");
    router.refresh();
  };

  return (
    <div className="min-h-screen bg-[#0c0a1d] text-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-[#140e30] border-2 border-rose-500/20 rounded-3xl p-8 shadow-2xl">
        <div className="flex justify-center mb-6">
          <Logo size="md" />
        </div>

        <h1 className="text-xl font-black text-white text-center mb-1">تسجيل دخول لوحة التحكم</h1>
        <p className="text-slate-400 text-xs text-center mb-6">مخصص لفريق إدارة YouAdv فقط</p>

        {error && (
          <div className="flex items-center gap-2 bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs px-3.5 py-2.5 rounded-xl mb-4">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4 text-right">
          <div>
            <label className="block text-slate-300 mb-1.5 text-xs font-bold">البريد الإلكتروني</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                dir="ltr"
                className="w-full bg-[#0c0a1d] border border-rose-500/30 rounded-xl pr-10 pl-3.5 py-2.5 text-sm text-white outline-none focus:border-sky-400 transition text-left"
                placeholder="admin@youadv.com"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 mb-1.5 text-xs font-bold">كلمة المرور</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                dir="ltr"
                className="w-full bg-[#0c0a1d] border border-rose-500/30 rounded-xl pr-10 pl-3.5 py-2.5 text-sm text-white outline-none focus:border-sky-400 transition text-left"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 disabled:opacity-60 text-white font-black text-sm py-3 rounded-xl shadow-xl transition flex items-center justify-center gap-2 mt-2"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            <span>{isLoading ? "جاري الدخول..." : "دخول"}</span>
          </button>
        </form>
      </div>
    </div>
  );
}
