import React from "react";
import { redirect } from "next/navigation";
import Link from "next/link";
import Logo from "@/components/Logo";
import AdminLogoutButton from "@/components/AdminLogoutButton";
import { AdminOrdersDashboard } from "@/components/AdminOrdersDashboard";
import { createClient } from "@/lib/supabase/server";
import { ArrowRight } from "lucide-react";

export default async function AdminPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Safety net: middleware already protects /admin, this covers direct server-side access too.
  if (!user) {
    redirect("/admin/login");
  }

  return (
    <div className="min-h-screen bg-[#0c0a1d] text-slate-100 font-sans antialiased pb-20">
      <header className="bg-[#100d27]/90 border-b border-rose-500/20 sticky top-0 z-40 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Logo size="sm" />
            <span className="hidden sm:inline-block bg-rose-500/10 text-rose-400 text-xs font-black px-3 py-1 rounded-full border border-rose-500/30">
              لوحة التحكم والإدارة (Admin Portal)
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden md:inline-block text-[11px] text-slate-400 font-mono" dir="ltr">
              {user.email}
            </span>
            <Link
              href="/"
              className="text-xs font-bold text-slate-300 hover:text-white bg-[#1a143d] hover:bg-[#251d54] px-4 py-2.5 rounded-xl border border-rose-500/20 transition flex items-center gap-1.5"
            >
              <span>معاينة المتجر المباشر</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
            <AdminLogoutButton />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 space-y-8">
        <div>
          <h1 className="text-3xl font-black text-white">إدارة ومتابعة طلبات الطباعة</h1>
          <p className="text-slate-400 text-xs mt-1">تحديث حالات التنفيذ، مراجعة تصاميم العملاء، والتواصل المباشر</p>
        </div>

        <AdminOrdersDashboard />
      </main>
    </div>
  );
}
