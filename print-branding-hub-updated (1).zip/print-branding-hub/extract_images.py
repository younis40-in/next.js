import os
import glob
from pypdf import PdfReader

# إنشاء مجلد الصور
out_dir = os.path.expanduser("~/print-branding-hub/public/products")
os.makedirs(out_dir, exist_ok=True)

# البحث عن ملف الكتالوج في التنزيلات، سطح المكتب، أو مسار المشروع
search_paths = [
    os.path.expanduser("~/Downloads/*.pdf"),
    os.path.expanduser("~/Downloads/*/*.pdf"),
    os.path.expanduser("~/Desktop/*.pdf"),
    os.path.expanduser("~/Documents/*.pdf"),
    os.path.expanduser("~/print-branding-hub/*.pdf"),
]

pdf_files = []
for p in search_paths:
    pdf_files.extend(glob.glob(p))

# تصفية الكتالوج المطلوب
target_pdf = None
for f in pdf_files:
    if "CUSTOMIZE" in f or "Youadv" in f or "نهائي" in f or "catalog" in f.lower():
        target_pdf = f
        break

if not target_pdf and pdf_files:
    target_pdf = pdf_files[0]

if not target_pdf:
    print("❌ لم يتم العثور على ملف الكتالوج PDF تلقائياً.")
    print("يرجى التأكد من وجود ملف الكتالوج في مجلد Downloads (التنزيلات) أو Desktop.")
    exit(1)

print(f"📖 جاري استخراج الصور من: {target_pdf}")

reader = PdfReader(target_pdf)
img_count = 0

# أسماء الأقسام لربط الصور تلقائياً
category_names = ["stamp", "card", "invoice", "flyer", "tag", "bag", "award", "medal", "sign", "flag", "stand"]

for page_idx, page in enumerate(reader.pages):
    for img_idx, img_obj in enumerate(page.images):
        # حفظ الصورة الأصلية برقمها
        raw_name = f"catalog_img_{img_count + 1}.png"
        raw_path = os.path.join(out_dir, raw_name)
        with open(raw_path, "wb") as fp:
            fp.write(img_obj.data)
        
        # حفظ نسخة باسم القسم لتظهر في المعرض مباشرة
        if img_count < len(category_names):
            cat_alias = f"{category_names[img_count]}.jpg"
            cat_path = os.path.join(out_dir, cat_alias)
            with open(cat_path, "wb") as fp:
                fp.write(img_obj.data)
        
        img_count += 1
        print(f"✅ تم استخراج الصورة {img_count}: {img_obj.name}")

print(f"\n🎉 تم استخراج {img_count} صورة بنجاح داخل مجلد public/products/")
